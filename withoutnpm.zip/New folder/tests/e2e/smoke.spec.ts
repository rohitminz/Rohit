import { test, expect, type Page } from "@playwright/test";

const PROPERTY_SLUGS = ["cyber-city", "cyber-hub", "mg-road", "lajpat-nagar"];

/** Distinct per-property contact details — each page must show its OWN, never another's. */
const PROPERTY_CONTACTS: Record<string, { phone: string; addressFragment: string }> = {
  "cyber-city": { phone: "+91 124 410 2201", addressFragment: "DLF Cyber City" },
  "cyber-hub": { phone: "+91 124 410 2202", addressFragment: "DLF Cyber Hub" },
  "mg-road": { phone: "+91 124 410 2203", addressFragment: "MG Road, Sector 28" },
  "lajpat-nagar": { phone: "+91 11 4100 2204", addressFragment: "Central Market" },
};

const AVAILABILITY_QUERY =
  "/availability?property=cyber-city&checkIn=2026-11-05&checkOut=2026-11-07&rooms=1&adults=2&children=0";

// The old demo rooms that used to leak across every Gurugram/Delhi property.
const DEMO_ROOMS = ["Presidential Royal Suite", "Executive Luxury Suite", "Deluxe Comfort Chamber"];

/** Fails if the document scrolls horizontally (the core responsive-layout regression). */
async function expectNoHorizontalScroll(page: Page) {
  const overflow = await page.evaluate(() => {
    const el = document.documentElement;
    return el.scrollWidth - el.clientWidth;
  });
  expect(overflow, "horizontal overflow in pixels").toBeLessThanOrEqual(1);
}

test.describe("Public website", () => {
  test("homepage renders without uncaught errors or horizontal overflow", async ({ page }) => {
    const pageErrors: string[] = [];
    page.on("pageerror", (err) => pageErrors.push(err.message));
    const response = await page.goto("/");
    expect(response?.status()).toBeLessThan(400);
    // Header and footer are nested inside <main>, so matched by tag not landmark role.
    await expect(page.locator("header").first()).toBeVisible();
    await expect(page.locator("footer").first()).toBeVisible();
    await expectNoHorizontalScroll(page);
    expect(pageErrors, pageErrors.join("\n")).toHaveLength(0);
  });

  for (const slug of PROPERTY_SLUGS) {
    test(`property page /locations/${slug} shows its OWN contact and no overflow`, async ({ page }) => {
      const response = await page.goto(`/locations/${slug}`);
      expect(response?.status()).toBeLessThan(400);
      const footer = page.locator("footer");
      const own = PROPERTY_CONTACTS[slug];
      // Footer shows this property's own phone + address.
      await expect(footer.getByText(own.phone, { exact: false }).first()).toBeVisible();
      await expect(footer.getByText(own.addressFragment, { exact: false }).first()).toBeVisible();
      // And must NOT show any OTHER property's phone (the "Cyber City shows Lajpat Nagar" bug).
      const footerText = (await footer.innerText()).replace(/\s+/g, " ");
      for (const [otherSlug, other] of Object.entries(PROPERTY_CONTACTS)) {
        if (otherSlug === slug) continue;
        expect(footerText, `${slug} footer leaked ${otherSlug} phone`).not.toContain(other.phone);
      }
      await expectNoHorizontalScroll(page);
    });
  }

  test("switching properties fully replaces the previous property's contact", async ({ page }) => {
    await page.goto("/locations/cyber-city");
    let footer = (await page.locator("footer").innerText()).replace(/\s+/g, " ");
    expect(footer).toContain(PROPERTY_CONTACTS["cyber-city"].phone);
    expect(footer).not.toContain(PROPERTY_CONTACTS["lajpat-nagar"].phone);

    await page.goto("/locations/lajpat-nagar");
    footer = (await page.locator("footer").innerText()).replace(/\s+/g, " ");
    expect(footer).toContain(PROPERTY_CONTACTS["lajpat-nagar"].phone);
    expect(footer).not.toContain(PROPERTY_CONTACTS["cyber-city"].phone);

    await page.goto("/locations/cyber-city");
    footer = (await page.locator("footer").innerText()).replace(/\s+/g, " ");
    expect(footer, "Lajpat Nagar contact must not remain on Cyber City").not.toContain(
      PROPERTY_CONTACTS["lajpat-nagar"].phone,
    );
  });

  test("View Room opens a modal with the correct property and room details", async ({ page }) => {
    await page.goto("/locations/cyber-city");
    await page.locator(".hc-room-actions button.hc-btn-outline").first().click();
    const dialog = page.getByRole("dialog");
    await expect(dialog).toBeVisible();
    // The modal is scoped to this property and shows a real room + rate + booking CTA.
    await expect(dialog.getByText(/Cyber City/).first()).toBeVisible();
    await expect(dialog.getByRole("heading", { level: 3 })).toBeVisible();
    await expect(dialog.getByRole("link", { name: /check availability/i })).toBeVisible();
  });

  test("room modal close button stays on top of the fixed header and closes the modal", async ({ page }) => {
    // Property pages use a fixed header; the modal is portaled to <body> so nothing can cover its close button.
    await page.goto("/locations/mg-road");
    await page.locator(".hc-room-actions button.hc-btn-outline").first().click();
    const dialog = page.getByRole("dialog");
    await expect(dialog).toBeVisible();
    const close = page.getByRole("button", { name: /close room details/i });
    const onTop = await close.evaluate((el) => {
      const r = el.getBoundingClientRect();
      const hit = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
      return !!hit && (el === hit || el.contains(hit));
    });
    expect(onTop, "close button must be the top-most element at its position").toBe(true);
    await close.click();
    await expect(dialog).toBeHidden();
  });

  test("clicking Contacts activates Contacts, not Banquets", async ({ page, viewport }) => {
    // The desktop nav links sit behind a hamburger drawer on mobile widths.
    test.skip((viewport?.width ?? 0) < 768, "Primary nav is a drawer on mobile");
    await page.goto("/");
    await page.locator(".hc-nav a[href='/#contact']").click();
    await expect(page.locator(".hc-nav a[href='/#contact']")).toHaveAttribute("aria-current", "true");
    await expect(page.locator(".hc-nav a[href='/#banquets']")).not.toHaveAttribute("aria-current", "true");
  });

  test("room cards never use the brand logo and show a placeholder when imageless", async ({ page }) => {
    await page.goto("/locations/cyber-city");
    const imgs = page.locator(".hc-room-media img");
    const count = await imgs.count();
    for (let i = 0; i < count; i++) {
      const src = (await imgs.nth(i).getAttribute("src")) ?? "";
      expect(src.toLowerCase()).not.toContain("logo");
    }
    // A room with no photo of its own must show the neutral placeholder, not a borrowed image.
    await page.goto("/locations/golf-corce").catch(() => {});
    const media = page.locator(".hc-room-media").first();
    if (await media.count()) {
      const hasImg = await media.locator("img").count();
      if (hasImg === 0) await expect(media.getByText(/photo coming soon/i)).toBeVisible();
    }
  });

  test("availability page carries the selected property and dates", async ({ page }) => {
    const response = await page.goto(AVAILABILITY_QUERY);
    expect(response?.status()).toBeLessThan(400);
    // Dates from the query appear on the results page.
    await expect(page.getByText(/Nov/).first()).toBeVisible();
    await expectNoHorizontalScroll(page);
  });

  test("availability shows the selected property's OWN rooms, never cross-property demo rooms", async ({ page }) => {
    const expected: Record<string, string> = {
      "cyber-city": "Cyber City",
      "cyber-hub": "Cyber Hub",
      "mg-road": "MG Road",
      "lajpat-nagar": "Lajpat Nagar",
    };
    for (const [slug, area] of Object.entries(expected)) {
      await page.goto(`/availability?property=${slug}&checkIn=2026-11-05&checkOut=2026-11-07&rooms=1&adults=2&children=0`);
      await expect(page.locator(".prop-line")).toContainText(area);
      await expect(page.locator(".result-card").first()).toBeVisible();
      const body = (await page.locator("section").first().innerText()).replace(/\s+/g, " ");
      for (const demo of DEMO_ROOMS) expect(body, `${slug} leaked demo room ${demo}`).not.toContain(demo);
    }
  });

  test("Golf Course availability shows only its own room, not Cyber City", async ({ page }) => {
    await page.goto("/availability?property=golf-corce&checkIn=2026-11-05&checkOut=2026-11-07&rooms=1&adults=2&children=0");
    await page.locator(".result-card, .empty-note").first().waitFor();
    const body = (await page.locator("section").first().innerText()).replace(/\s+/g, " ");
    expect(body).not.toContain("Cyber City");
    for (const demo of DEMO_ROOMS) expect(body).not.toContain(demo);
  });

  test("invalid property shows an error and does not default to another property", async ({ page }) => {
    await page.goto("/availability?property=__no_such_property__&checkIn=2026-11-05&checkOut=2026-11-07&rooms=1&adults=2&children=0");
    await expect(page.getByText(/couldn.t find the selected property/i)).toBeVisible();
    const body = (await page.locator("section").first().innerText()).replace(/\s+/g, " ");
    expect(body).not.toContain("Cyber City");
    for (const demo of DEMO_ROOMS) expect(body).not.toContain(demo);
  });

  test("refresh preserves the selected property on the results page", async ({ page }) => {
    await page.goto("/availability?property=cyber-hub&checkIn=2026-11-05&checkOut=2026-11-07&rooms=1&adults=2&children=0");
    await expect(page.locator(".prop-line")).toContainText("Cyber Hub");
    await page.reload();
    await expect(page.locator(".prop-line")).toContainText("Cyber Hub");
  });

  test("booking page resolves the property by slug (MG Road), never defaulting to Cyber City", async ({ page }) => {
    await page.goto("/booking?roomId=mg-road-superior&name=Superior+Room&rate=4500&property=gurugram&propertySlug=mg-road&checkIn=2026-11-05&checkOut=2026-11-07&adults=2&children=0&rooms=1");
    await expect(page.locator(".bk-prop")).toContainText("MG Road");
    await expect(page.locator(".bk-prop")).not.toContainText("Cyber City");
  });

  test("booking page shows Cyber City for a Cyber City room", async ({ page }) => {
    await page.goto("/booking?roomId=cyber-city-superior&name=Superior+Room&rate=4800&property=gurugram&propertySlug=cyber-city&checkIn=2026-11-05&checkOut=2026-11-07&adults=2&children=0&rooms=1");
    await expect(page.locator(".bk-prop")).toContainText("Cyber City");
  });

  test("booking page with an invalid property shows an error and no default", async ({ page }) => {
    await page.goto("/booking?roomId=x&name=x&rate=1000&property=gurugram&propertySlug=__no_such_property__&checkIn=2026-11-05&checkOut=2026-11-07&adults=2&children=0&rooms=1");
    await expect(page.getByText(/couldn.t find the selected property/i)).toBeVisible();
    await expect(page.locator(".bk-prop")).not.toContainText("Cyber City");
  });

  test("booking 'Available Rooms' breadcrumb returns to the availability results, not the homepage", async ({ page }) => {
    await page.goto("/booking?roomId=cyber-city-superior&name=Superior+Room&rate=4800&property=gurugram&propertySlug=cyber-city&checkIn=2026-11-05&checkOut=2026-11-07&adults=2&children=0&rooms=1");
    const crumb = page.getByRole("link", { name: "Available Rooms" });
    await expect(crumb).toHaveAttribute("href", /\/availability\?.*property=cyber-city/);
    await crumb.click();
    await expect(page).toHaveURL(/\/availability\?.*property=cyber-city/);
    await expect(page.locator(".prop-line")).toContainText("Cyber City");
  });

  test("/search redirects to /availability preserving params", async ({ page }) => {
    await page.goto(
      "/search?property=gurugram&checkIn=2026-11-05&checkOut=2026-11-07&rooms=1&adults=2&children=0",
    );
    await expect(page).toHaveURL(/\/availability\?/);
    expect(page.url()).toContain("property=gurugram");
  });

  test("/booking/availability redirects to /availability", async ({ page }) => {
    await page.goto("/booking/availability?property=delhi&checkIn=2026-11-05&checkOut=2026-11-07");
    await expect(page).toHaveURL(/\/availability\?/);
    expect(page.url()).toContain("property=delhi");
  });

  test("a property card links through to a property page", async ({ page }) => {
    await page.goto("/");
    const propertyLink = page.locator('a[href^="/locations/"]').first();
    await propertyLink.waitFor({ state: "attached" });
    const href = await propertyLink.getAttribute("href");
    expect(href).toMatch(/\/locations\//);
    await page.goto(href!);
    await expect(page).toHaveURL(/\/locations\//);
    await expect(page.locator("footer").first()).toBeVisible();
  });
});

test.describe("Admin dashboard", () => {
  // The sidebar navigation is hidden behind a hamburger drawer on small screens.
  test.skip(({ viewport }) => (viewport?.width ?? 0) < 768, "Dashboard nav is a drawer on mobile");

  test("dashboard preview renders the sidebar navigation", async ({ page }) => {
    const response = await page.goto("/admin?preview=1");
    expect(response?.status()).toBeLessThan(400);
    await expect(page.getByRole("button", { name: "Website content" })).toBeVisible();
    await expect(page.getByRole("button", { name: "Bookings", exact: true })).toBeVisible();
    await expectNoHorizontalScroll(page);
  });

  test("Website content tab exposes Add and Delete property controls", async ({ page }) => {
    await page.goto("/admin?preview=1");
    await page.getByRole("button", { name: "Website content" }).click();
    await expect(page.getByRole("button", { name: /add property/i })).toBeVisible();
    await expect(page.getByRole("button", { name: /delete property/i })).toBeVisible();
  });
});
