// One-off maintenance: backfill per-property contact details into the published
// content workbook so each property shows its OWN phone/email/address instead of
// falling back to the global (previously "Lajpat Nagar") values.
// Safe + idempotent: only fills contact fields that are empty or still hold the
// old buggy defaults, so any admin-entered values are preserved.
// Usage: node scripts/backfill-contacts.mjs  (dev server must be running on :3000)

const BASE = process.env.PW_BASE_URL || "http://localhost:3000";

const PROPERTY_CONTACTS = {
  "cyber-city": { contactPhone: "+91 124 410 2201", contactEmail: "cybercity@hariscourt.in", contactAddress: "Tower B, DLF Cyber City, Phase 2, Gurugram, Haryana 122002" },
  "cyber-hub": { contactPhone: "+91 124 410 2202", contactEmail: "cyberhub@hariscourt.in", contactAddress: "DLF Cyber Hub, DLF Phase 2, Gurugram, Haryana 122002" },
  "mg-road": { contactPhone: "+91 124 410 2203", contactEmail: "mgroad@hariscourt.in", contactAddress: "MG Road, Sector 28, Gurugram, Haryana 122001" },
  "lajpat-nagar": { contactPhone: "+91 11 4100 2204", contactEmail: "lajpatnagar@hariscourt.in", contactAddress: "Central Market, Lajpat Nagar, New Delhi, Delhi 110024" },
};

const OLD_SETTINGS = {
  contactPhone: "+91 98123 45678",
  contactEmail: "hello@hariscourt.com",
  contactAddress: "Lajpat Nagar, New Delhi, India",
};
const NEW_SETTINGS = {
  contactPhone: "+91 124 410 2200",
  contactEmail: "reservations@hariscourt.in",
  contactAddress: "Hari's Court Hotels & Inns, Gurugram & New Delhi",
};

const fillIf = (current, replacement, old) => (!current || current === old ? replacement : current);

async function main() {
  const res = await fetch(`${BASE}/api/admin/content`, { cache: "no-store" });
  if (!res.ok) throw new Error(`GET /api/admin/content failed: ${res.status} ${await res.text()}`);
  const { published, draft } = await res.json();
  if (draft) throw new Error("A draft already exists. Publish or discard it first, then re-run.");

  const content = {
    ...published,
    settings: {
      ...published.settings,
      contactPhone: fillIf(published.settings.contactPhone, NEW_SETTINGS.contactPhone, OLD_SETTINGS.contactPhone),
      contactEmail: fillIf(published.settings.contactEmail, NEW_SETTINGS.contactEmail, OLD_SETTINGS.contactEmail),
      contactAddress: fillIf(published.settings.contactAddress, NEW_SETTINGS.contactAddress, OLD_SETTINGS.contactAddress),
    },
    properties: published.properties.map((p) => {
      const c = PROPERTY_CONTACTS[p.slug];
      if (!c) return p;
      return {
        ...p,
        contactPhone: p.contactPhone || c.contactPhone,
        contactEmail: p.contactEmail || c.contactEmail,
        contactAddress: p.contactAddress || c.contactAddress,
      };
    }),
  };

  const put = await fetch(`${BASE}/api/admin/content`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ content, expectedVersion: published.version }),
  });
  if (!put.ok) throw new Error(`PUT failed: ${put.status} ${await put.text()}`);

  const pub = await fetch(`${BASE}/api/admin/content/publish`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ expectedVersion: published.version }),
  });
  if (!pub.ok) throw new Error(`Publish failed: ${pub.status} ${await pub.text()}`);

  console.log(`Backfilled contacts and published version ${published.version + 1}.`);
  for (const p of content.properties) {
    console.log(`  ${p.slug}: ${p.contactPhone} | ${p.contactEmail} | ${p.contactAddress}`);
  }
}

main().catch((err) => {
  console.error(err.message || err);
  process.exit(1);
});
