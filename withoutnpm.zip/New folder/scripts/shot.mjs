// Captures full-page screenshots at a given viewport for visual width proof.
import { chromium } from "@playwright/test";
const BASE = process.env.PW_BASE_URL || "http://localhost:3000";
const CHANNEL = process.env.PW_CHANNEL || "msedge";
const W = Number(process.env.SHOT_W || 1920);
const H = Number(process.env.SHOT_H || 1080);

const SHOTS = [
  { name: "home", url: "/" },
  { name: "property-cyber-city", url: "/locations/cyber-city" },
  { name: "availability", url: "/availability?property=gurugram&checkIn=2026-11-05&checkOut=2026-11-07&rooms=1&adults=2&children=0" },
  { name: "admin", url: "/admin?preview=1" },
];

const browser = await chromium.launch({ channel: CHANNEL, headless: true });
const context = await browser.newContext({ viewport: { width: W, height: H } });
const page = await context.newPage();
for (const s of SHOTS) {
  await page.goto(BASE + s.url, { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(1200);
  const path = `screenshots/${W}-${s.name}.png`;
  await page.screenshot({ path, fullPage: false });
  console.log(`saved ${path}`);
}
await browser.close();
