// Width-audit: measures real layout gaps at several viewports using the installed
// Edge browser. Prints viewport width, content width, and left/right gaps per page.
// Usage: node scripts/measure-width.mjs   (dev server must be running on :3000)
import { chromium } from "@playwright/test";

const BASE = process.env.PW_BASE_URL || "http://localhost:3000";
const CHANNEL = process.env.PW_CHANNEL || "msedge";

const VIEWPORTS = [
  { w: 1920, h: 1080 },
  { w: 1440, h: 900 },
  { w: 1366, h: 768 },
  { w: 1024, h: 768 },
  { w: 768, h: 1024 },
  { w: 390, h: 844 },
  { w: 360, h: 800 },
];

const PAGES = [
  { name: "Homepage", url: "/", sel: [".hc-header-bar", ".hc-hero-inner", ".hc-section", ".hc-footer-inner"] },
  { name: "Availability", url: "/availability?property=gurugram&checkIn=2026-11-05&checkOut=2026-11-07&rooms=1&adults=2&children=0", sel: [".subpage"] },
  { name: "Property", url: "/locations/cyber-city", sel: [".hc-section", ".hc-room-grid", ".hc-footer-inner"] },
  { name: "Admin", url: "/admin?preview=1", sel: [".admin-content", ".kpi-overview", ".po-grid"] },
];

function fmt(n) {
  return n === null || n === undefined ? "  -  " : String(Math.round(n)).padStart(5, " ");
}

async function main() {
  const browser = await chromium.launch({ channel: CHANNEL, headless: true });
  for (const vp of VIEWPORTS) {
    const context = await browser.newContext({ viewport: { width: vp.w, height: vp.h } });
    const page = await context.newPage();
    console.log(`\n================  VIEWPORT ${vp.w} x ${vp.h}  ================`);
    for (const p of PAGES) {
      await page.goto(BASE + p.url, { waitUntil: "domcontentloaded" });
      await page.waitForTimeout(600);
      const innerWidth = await page.evaluate(() => window.innerWidth);
      const docOverflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
      console.log(`\n  ${p.name}  (innerWidth=${innerWidth}, horizontalOverflow=${docOverflow}px)`);
      for (const sel of p.sel) {
        const m = await page.evaluate((s) => {
          const el = document.querySelector(s);
          if (!el) return null;
          const r = el.getBoundingClientRect();
          const cs = getComputedStyle(el);
          return { left: r.left, right: r.right, width: r.width, maxWidth: cs.maxWidth };
        }, sel);
        if (!m) {
          console.log(`    ${sel.padEnd(18)}  (not present)`);
          continue;
        }
        const leftGap = m.left;
        const rightGap = innerWidth - m.right;
        console.log(
          `    ${sel.padEnd(18)} width=${fmt(m.width)} leftGap=${fmt(leftGap)} rightGap=${fmt(rightGap)} maxWidth=${m.maxWidth}`,
        );
      }
    }
    await context.close();
  }
  await browser.close();
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
