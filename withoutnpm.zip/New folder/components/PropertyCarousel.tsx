"use client";

import Image from "next/image";
import Link from "next/link";
import { useRef, type KeyboardEvent, type PointerEvent } from "react";
import { ArrowRight, ChevronLeft, ChevronRight } from "lucide-react";
import { useSelectedProperty } from "./SelectedProperty";

// Per-offset layout in card widths / scale / dimming. Cards only translate and scale: they never rotate.
const X = [0, 0.8, 1.32, 1.7];
const SCALE = [1, 0.8, 0.64, 0.5];
const DIM = [0, 0.48, 0.66, 0.8];

function wrapOffset(index: number, active: number, count: number) {
  let offset = index - active;
  if (offset > count / 2) offset -= count;
  if (offset <= -count / 2) offset += count;
  return offset;
}

export default function PropertyCarousel({ exploreLabel = "Explore" }: { exploreLabel?: string }) {
  const selected = useSelectedProperty();
  const pointer = useRef<{ x: number; moved: boolean } | null>(null);
  if (!selected) return null;
  const { properties, slug, setSlug, property } = selected;
  const count = properties.length;
  const active = properties.findIndex((item) => item.slug === slug);

  const go = (delta: number) => setSlug(properties[(active + delta + count) % count].slug);

  function onKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    if (event.key === "ArrowLeft") { event.preventDefault(); go(-1); }
    else if (event.key === "ArrowRight") { event.preventDefault(); go(1); }
    else if (event.key === "Home") { event.preventDefault(); setSlug(properties[0].slug); }
    else if (event.key === "End") { event.preventDefault(); setSlug(properties[count - 1].slug); }
  }

  function onPointerDown(event: PointerEvent<HTMLDivElement>) {
    pointer.current = { x: event.clientX, moved: false };
  }

  function onPointerUp(event: PointerEvent<HTMLDivElement>) {
    const start = pointer.current;
    pointer.current = null;
    if (!start) return;
    const delta = event.clientX - start.x;
    if (Math.abs(delta) > 48) {
      start.moved = true;
      go(delta < 0 ? 1 : -1);
      // Swallow the click that follows a swipe so it does not select a card.
      const swallow = (clickEvent: Event) => { clickEvent.stopPropagation(); clickEvent.preventDefault(); };
      window.addEventListener("click", swallow, { capture: true, once: true });
      setTimeout(() => window.removeEventListener("click", swallow, { capture: true }), 0);
    }
  }

  return (
    <div className="hc-carousel" role="region" aria-roledescription="carousel" aria-label="Hari's Court properties" tabIndex={-1} onKeyDown={onKeyDown}>
      <div className="hc-stage" onPointerDown={onPointerDown} onPointerUp={onPointerUp} onPointerCancel={() => (pointer.current = null)}>
        {properties.map((item, index) => {
          const offset = wrapOffset(index, active, count);
          const distance = Math.min(Math.abs(offset), 3);
          const isActive = offset === 0;
          const style = {
            "--x": `${Math.sign(offset) * X[distance]}`,
            "--s": SCALE[distance],
            "--dim": DIM[distance],
            zIndex: 30 - distance * 10,
            opacity: distance > 2 ? 0 : 1,
          } as React.CSSProperties;
          const body = (
            <>
              <Image src={item.cardImage} alt={isActive ? `${item.name} ${item.location}` : ""} fill priority={isActive} sizes="(max-width: 700px) 62vw, 330px" draggable={false} />
              <span className="hc-card-shade" aria-hidden="true" />
              <span className="hc-card-copy">
                <strong>{item.area}</strong>
                <small>{item.city}</small>
                {isActive && (
                  <span className="hc-card-cta">
                    {exploreLabel} <ArrowRight size={14} />
                  </span>
                )}
              </span>
            </>
          );
          return isActive ? (
            <Link key={item.slug} href={`/locations/${item.slug}`} className="hc-card is-active" style={style} aria-current="true" aria-label={`${item.name} ${item.location}: open property page`} draggable={false}>
              {body}
            </Link>
          ) : (
            <button key={item.slug} type="button" className="hc-card" style={style} aria-label={`Select ${item.name} ${item.location}`} tabIndex={distance > 2 ? -1 : 0} onClick={() => setSlug(item.slug)}>
              {body}
            </button>
          );
        })}
      </div>
      <div className="hc-carousel-controls">
        <button type="button" className="hc-carousel-arrow hc-carousel-prev" aria-label="Previous property" onClick={() => go(-1)}>
          <ChevronLeft size={18} strokeWidth={2.2} />
        </button>
        <div className="hc-dots" role="group" aria-label="Choose property">
          {properties.map((item) => (
            <button key={item.slug} type="button" className={`hc-dot${item.slug === slug ? " is-active" : ""}`} aria-label={`Show ${item.location}`} aria-current={item.slug === slug ? "true" : undefined} onClick={() => setSlug(item.slug)} />
          ))}
        </div>
        <button type="button" className="hc-carousel-arrow hc-carousel-next" aria-label="Next property" onClick={() => go(1)}>
          <ChevronRight size={18} strokeWidth={2.2} />
        </button>
      </div>
      <p className="hc-sr-only" aria-live="polite">
        Selected: {property.name} {property.location}
      </p>
    </div>
  );
}
