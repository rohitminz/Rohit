import Image from "next/image";
import Link from "next/link";

type BrandLogoProps = {
  href?: string;
  size?: "header" | "footer" | "admin" | "hero";
  showName?: boolean;
  priority?: boolean;
  className?: string;
};

export const LOGO_SRC = "/images/hari-court-logo-transparent.png";

export default function BrandLogo({ href, size = "header", showName = true, priority = false, className = "" }: BrandLogoProps) {
  const content = (
    <>
      <Image
        className="brand-lockup-img"
        src={LOGO_SRC}
        alt="Hari’s Court Hotel Logo"
        width={672}
        height={326}
        priority={priority}
        sizes="(max-width: 640px) 120px, 200px"
        unoptimized
      />
      {showName && <span className="brand-lockup-name">Hari’s Court Hotel</span>}
    </>
  );
  const classes = `brand-lockup brand-lockup-${size} ${className}`.trim();
  return href ? (
    <Link href={href} className={classes} aria-label="Hari’s Court Hotel home">
      {content}
    </Link>
  ) : (
    <div className={classes}>{content}</div>
  );
}
