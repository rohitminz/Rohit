"use client";

import { FormEvent, useState } from "react";
import { ArrowRight } from "lucide-react";

export default function EnquiryForm({ defaultKind = "general" }: { defaultKind?: "general" | "event" }) {
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    setBusy(true);
    setStatus("");
    const form = new FormData(formElement);
    try {
      const response = await fetch("/api/enquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          kind: form.get("kind"),
          name: form.get("name"),
          email: form.get("email"),
          phone: form.get("phone"),
          message: form.get("message"),
          website: form.get("website"),
        }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "We could not send your enquiry.");
      formElement.reset();
      setStatus("Thank you. Your enquiry has been sent to our team.");
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "We could not send your enquiry.");
    } finally {
      setBusy(false);
    }
  }

  return <form className="enquiry-form hc-enquiry" onSubmit={submit}>
    <div className="form-grid">
      <label>Enquiry type<select name="kind" defaultValue={defaultKind}><option value="general">A stay or general enquiry</option><option value="event">A celebration or event</option></select></label>
      <label>Your name<input name="name" required maxLength={100} autoComplete="name" /></label>
      <label>Email address<input name="email" type="email" required maxLength={254} autoComplete="email" /></label>
      <label>Phone number<input name="phone" type="tel" required maxLength={30} autoComplete="tel" /></label>
      <label className="full">How can we help?<textarea name="message" required maxLength={2000} rows={3} /></label>
      <label className="honeypot" aria-hidden="true">Website<input name="website" tabIndex={-1} autoComplete="off" /></label>
    </div>
    <button className="hc-btn hc-btn-gold" type="submit" disabled={busy}>{busy ? "Sending..." : "Send enquiry"}<ArrowRight size={14} /></button>
    {status && <p className="enquiry-status" role="status">{status}</p>}
  </form>;
}