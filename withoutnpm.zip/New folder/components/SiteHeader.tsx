"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import BrandLogo from "./BrandLogo";

const navItems = [
  { label: "Home", href: "/", id: "home" },
  { label: "Rooms", href: "/#rooms", id: "rooms" },
  { label: "Our Locations", href: "/#locations", id: "locations" },
  { label: "Banquets", href: "/#banquets", id: "banquets" },
  { label: "Contacts", href: "/#contact", id: "contact" },
];

export default function SiteHeader({ bookHref = "/#booking", bookLabel = "Book Now" }: { bookHref?: string; bookLabel?: string }) {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [activeId, setActiveId] = useState("home");
  const onHome = pathname === "/";

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setOpen(false), [pathname]);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => event.key === "Escape" && setOpen(false);
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open]);

  // Scroll-spy for the homepage sections: deterministic, position-based so the last
  // section (Contacts/footer) activates even though it is short.
  useEffect(() => {
    if (!onHome) return;
    const spy = () => {
      const marker = window.scrollY + window.innerHeight * 0.38;
      let current = navItems[0].id;
      for (const item of navItems) {
        const el = document.getElementById(item.id);
        if (!el) continue;
        const top = el.getBoundingClientRect().top + window.scrollY;
        if (top <= marker) current = item.id;
      }
      if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 120) current = "contact";
      setActiveId(current);
    };
    spy();
    window.addEventListener("scroll", spy, { passive: true });
    window.addEventListener("resize", spy);
    return () => {
      window.removeEventListener("scroll", spy);
      window.removeEventListener("resize", spy);
    };
  }, [onHome]);

  const currentId = onHome ? activeId : pathname.startsWith("/locations") ? "locations" : "";

  return (
    <header className={`hc-header${scrolled ? " is-scrolled" : ""}${open ? " is-open" : ""}`}>
      <div className="hc-header-bar">
        <BrandLogo href="/" size="header" showName={false} priority className="hc-header-logo" />
        <nav className="hc-nav" id="hc-nav" aria-label="Main navigation">
          {navItems.map((item) => (
            <Link key={item.id} href={item.href} className={`hc-nav-link${currentId === item.id ? " is-active" : ""}`} aria-current={currentId === item.id ? "true" : undefined} onClick={() => { setOpen(false); if (onHome) setActiveId(item.id); }}>
              {item.label}
            </Link>
          ))}
          <Link href={bookHref} className="hc-btn hc-btn-gold hc-nav-book-mobile" onClick={() => setOpen(false)}>
            {bookLabel}
          </Link>
        </nav>
        <Link href={bookHref} className="hc-btn hc-btn-gold hc-header-book">
          {bookLabel}
        </Link>
        <button type="button" className="hc-menu-toggle" aria-expanded={open} aria-controls="hc-nav" aria-label={open ? "Close menu" : "Open menu"} onClick={() => setOpen((value) => !value)}>
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>
    </header>
  );
}
