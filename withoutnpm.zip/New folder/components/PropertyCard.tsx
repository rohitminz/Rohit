import Image from "next/image";
import Link from "next/link";
import { ArrowUpRight, MapPin } from "lucide-react";
import type { Property } from "@/lib/properties";

export default function PropertyCard({ property, priority = false, ctaLabel = "Explore Property" }: { property: Property; priority?: boolean; ctaLabel?: string }) {
  return (
    <Link href={`/locations/${property.slug}`} className="hc-property-card" aria-label={`Explore ${property.name} ${property.location}`}>
      <div className="hc-property-media">
        <Image src={property.cardImage} alt={`Hari's Court ${property.location}`} fill priority={priority} sizes="(max-width: 700px) 100vw, (max-width: 1100px) 50vw, 300px" />
        <span className="hc-property-go" aria-hidden="true">
          <ArrowUpRight size={20} />
        </span>
      </div>
      <div className="hc-property-body">
        <p className="hc-property-place">
          <MapPin size={14} /> {property.city}
        </p>
        <h3>
          {property.name} <em>{property.area}</em>
        </h3>
        <p className="hc-property-text">{property.summary}</p>
        <span className="hc-property-cta">
          {ctaLabel} <ArrowUpRight size={15} />
        </span>
      </div>
    </Link>
  );
}
