"use client";

import { useEffect, useRef, useState } from "react";
import type { Property } from "@/lib/properties";

const API_KEY = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;
const MAP_ID = process.env.NEXT_PUBLIC_GOOGLE_MAPS_MAP_ID || "DEMO_MAP_ID";

let mapsReady: Promise<void> | undefined;

function loadGoogleMaps(key: string): Promise<void> {
  mapsReady ??= new Promise<void>((resolve, reject) => {
    const callback = "__onGoogleMapsReady";
    (window as unknown as Record<string, unknown>)[callback] = resolve;
    const script = document.createElement("script");
    script.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(key)}&v=weekly&loading=async&callback=${callback}`;
    script.async = true;
    script.onerror = () => {
      mapsReady = undefined;
      reject(new Error("Google Maps failed to load"));
    };
    document.head.appendChild(script);
  });
  return mapsReady;
}

async function locate(query: string): Promise<google.maps.LatLngLiteral | null> {
  try {
    const { Place } = (await google.maps.importLibrary("places")) as google.maps.PlacesLibrary;
    const { places } = await Place.searchByText({ textQuery: query, fields: ["location"], maxResultCount: 1 });
    const found = places[0]?.location;
    if (found) return found.toJSON();
  } catch {
    // Fall back to the Geocoding API below.
  }
  try {
    const { Geocoder } = (await google.maps.importLibrary("geocoding")) as google.maps.GeocodingLibrary;
    const { results } = await new Geocoder().geocode({ address: query });
    return results[0]?.geometry.location.toJSON() ?? null;
  } catch {
    return null;
  }
}

function hotelPin(): HTMLElement {
  const pin = document.createElement("div");
  pin.className = "hc-map-pin hc-map-pin-hotel";
  pin.innerHTML =
    '<svg viewBox="0 0 24 24" width="40" height="40" aria-hidden="true"><path fill="#AE8037" stroke="#fff" stroke-width="1.5" d="M12 22s7-6.2 7-12a7 7 0 1 0-14 0c0 5.8 7 12 7 12z"/><circle cx="12" cy="10" r="2.8" fill="#fff"/></svg>';
  return pin;
}

function landmarkPin(label: string): HTMLElement {
  const pin = document.createElement("div");
  pin.className = "hc-map-pin hc-map-pin-landmark";
  const dot = document.createElement("span");
  dot.className = "hc-map-pin-dot";
  const text = document.createElement("span");
  text.textContent = label;
  pin.append(dot, text);
  return pin;
}

export default function PropertyMap({ property }: { property: Property }) {
  const container = useRef<HTMLDivElement>(null);
  const [useEmbed, setUseEmbed] = useState(!API_KEY);

  useEffect(() => {
    if (!API_KEY) return;
    let cancelled = false;
    const markers: google.maps.marker.AdvancedMarkerElement[] = [];

    async function render(key: string) {
      try {
        await loadGoogleMaps(key);
        const { Map } = (await google.maps.importLibrary("maps")) as google.maps.MapsLibrary;
        const { AdvancedMarkerElement } = (await google.maps.importLibrary("marker")) as google.maps.MarkerLibrary;
        const [hotel, ...landmarks] = await Promise.all([locate(property.mapQuery), ...property.nearby.map((place) => locate(place.query))]);
        if (cancelled || !container.current) return;
        if (!hotel) throw new Error(`No location found for ${property.mapQuery}`);

        const map = new Map(container.current, {
          center: hotel,
          zoom: 15,
          mapId: MAP_ID,
          zoomControl: true,
          fullscreenControl: false,
          streetViewControl: false,
          mapTypeControl: false,
          gestureHandling: "greedy",
        });
        const bounds = new google.maps.LatLngBounds(hotel);
        markers.push(new AdvancedMarkerElement({ map, position: hotel, title: property.mapQuery, content: hotelPin(), zIndex: 10 }));
        landmarks.forEach((position, index) => {
          if (!position) return;
          const place = property.nearby[index];
          bounds.extend(position);
          markers.push(new AdvancedMarkerElement({ map, position, title: place.label, content: landmarkPin(place.label) }));
        });
        if (landmarks.some(Boolean)) map.fitBounds(bounds, 48);
      } catch (error) {
        console.error("Interactive map unavailable, using embedded Google Map instead.", error);
        if (!cancelled) setUseEmbed(true);
      }
    }

    void render(API_KEY);
    return () => {
      cancelled = true;
      markers.forEach((marker) => {
        marker.map = null;
      });
    };
  }, [property]);

  if (useEmbed) {
    return (
      <iframe
        className="hc-map"
        title={`Map of Hari's Court ${property.location}`}
        src={`https://www.google.com/maps?q=${encodeURIComponent(property.mapQuery)}&z=15&output=embed`}
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
        allowFullScreen
      />
    );
  }
  return <div className="hc-map" ref={container} role="region" aria-label={`Map of ${property.location}`} />;
}
