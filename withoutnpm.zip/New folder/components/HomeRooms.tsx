"use client";

import Link from "next/link";
import PropertyTabs from "./PropertyTabs";
import RoomShowcase from "./RoomShowcase";
import { useSelectedProperty } from "./SelectedProperty";

/** Homepage rooms section; follows the active property card. */
export default function HomeRooms({ availabilityLabel }: { availabilityLabel?: string }) {
  const selected = useSelectedProperty();
  if (!selected) return null;
  const { property } = selected;

  return (
    <>
      <div className="hc-rooms-head">
        <PropertyTabs label="Show rooms for" />
        <p>
          Rooms at <strong>Hari&apos;s Court {property.location}</strong> ·{" "}
          <Link href={`/locations/${property.slug}`} className="hc-inline-link">View property page</Link>
        </p>
      </div>
      <div key={property.slug} className="hc-fade-swap">
        <RoomShowcase property={property} availabilityLabel={availabilityLabel} />
      </div>
    </>
  );
}
