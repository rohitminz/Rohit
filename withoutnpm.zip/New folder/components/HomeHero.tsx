"use client";

import Image from "next/image";
import type { HomeContent } from "@/lib/content/schema";
import HeroBookingBar from "./HeroBookingBar";
import PropertyCarousel from "./PropertyCarousel";
import { useSelectedProperty } from "./SelectedProperty";

export default function HomeHero({ home, maxGuests, phone, availabilityLabel, exploreLabel }: { home: HomeContent; maxGuests: number; phone: string; availabilityLabel?: string; exploreLabel?: string }) {
  const selected = useSelectedProperty();
  if (!selected) return null;
  const { properties, slug } = selected;

  return (
    <section className="hc-hero hc-hero--cards" id="home" aria-label="Hari's Court">
      <div className="hc-hero-media" aria-hidden="true">
        {properties.map((item) => (
          <Image
            key={item.slug}
            src={item.backgroundImage || item.cardImage}
            alt=""
            fill
            priority={item.slug === slug}
            sizes="100vw"
            className={`hc-hero-img${item.backgroundBlur ? " is-blur" : ""}${item.slug === slug ? " is-active" : ""}`}
          />
        ))}
        <div className="hc-hero-overlay" />
      </div>

      <div className="hc-hero-stack">
        <div className="hc-hero-heading">
          {home.heroEyebrow && <p className="hc-eyebrow hc-rise">{home.heroEyebrow}</p>}
          <h1 className="hc-hero-title hc-rise" style={{ animationDelay: "0.1s" }}>
            {home.heroTitle}
          </h1>
          <p className="hc-hero-text hc-rise" style={{ animationDelay: "0.2s" }}>
            {home.heroSubtitle}
          </p>
        </div>
        <div className="hc-rise" style={{ animationDelay: "0.3s" }}>
          <PropertyCarousel exploreLabel={exploreLabel} />
        </div>
      </div>

      <div className="hc-hero-booking">
        <HeroBookingBar maxGuests={maxGuests} phone={phone} availabilityLabel={availabilityLabel} />
      </div>
    </section>
  );
}
