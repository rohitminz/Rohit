"use client";

import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

export default function RoomGallery({ images, name }: { images: string[]; name: string }) {
  const [index, setIndex] = useState(0);
  const count = images.length;

  return (
    <div>
      <div className="gallery-main" style={{ backgroundImage: `url(${images[index]})` }} role="img" aria-label={`${name} photo ${index + 1}`}>
        <button type="button" className="gallery-btn gallery-prev" aria-label="Previous photo" onClick={() => setIndex((index - 1 + count) % count)}>
          <ChevronLeft size={20} />
        </button>
        <button type="button" className="gallery-btn gallery-next" aria-label="Next photo" onClick={() => setIndex((index + 1) % count)}>
          <ChevronRight size={20} />
        </button>
        <span className="gallery-count">{index + 1}/{count}</span>
      </div>
      <div className="gallery-thumbs">
        {images.map((image, i) => (
          <button
            key={image}
            type="button"
            className={`thumb${i === index ? " active" : ""}`}
            style={{ backgroundImage: `url(${image})` }}
            aria-label={`Show photo ${i + 1}`}
            aria-pressed={i === index}
            onClick={() => setIndex(i)}
          />
        ))}
      </div>
    </div>
  );
}
