import { AirVent, Car, ConciergeBell, Clock, Sparkles, Tv, UtensilsCrossed, Wifi, type LucideIcon } from "lucide-react";
import type { AmenityRecord } from "@/lib/content/schema";

const icons: Record<AmenityRecord["icon"], LucideIcon> = {
  ac: AirVent,
  wifi: Wifi,
  dining: UtensilsCrossed,
  housekeeping: Sparkles,
  service: ConciergeBell,
  desk: Clock,
  parking: Car,
  tv: Tv,
};

export default function AmenityIcon({ name, size = 22 }: { name: AmenityRecord["icon"]; size?: number }) {
  const Icon = icons[name] ?? Sparkles;
  return <Icon size={size} aria-hidden="true" />;
}
