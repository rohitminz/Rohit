"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { BedDouble, Check, ImageOff, Maximize, Users, X } from "lucide-react";
import { formatHotelDate, todayInIndia } from "@/lib/booking-dates";
import { inr, roomPolicies } from "@/lib/room-details";
import { searchHref, type Property, type PropertyRoom } from "@/lib/properties";

function price(room: PropertyRoom) {
  if (room.priceStatus === "on-request" || room.rate <= 0) return { lead: "", value: "Rate on request", unit: "" };
  return { lead: room.priceStatus === "placeholder" ? "Starting from" : "", value: inr(room.rate), unit: "/ night" };
}

function RoomDialog({ room, property, onClose }: { room: PropertyRoom; property: Property; onClose: () => void }) {
  const closeRef = useRef<HTMLButtonElement>(null);
  const [imageIndex, setImageIndex] = useState(0);
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [minDate, setMinDate] = useState("");
  const amount = price(room);
  const images = room.images;
  const hasImages = images.length > 0;

  useEffect(() => {
    const today = todayInIndia();
    setMinDate(today);
    setCheckIn(today);
    setCheckOut(formatHotelDate(new Date(Date.now() + 86400000)));
  }, []);

  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    closeRef.current?.focus();
    const onKey = (event: KeyboardEvent) => event.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = overflow;
      previous?.focus();
    };
  }, [onClose]);

  const valid = Boolean(checkIn && checkOut && checkOut > checkIn && checkIn >= minDate);

  return (
    <div className="hc-dialog-backdrop" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <div className="hc-dialog" role="dialog" aria-modal="true" aria-labelledby="room-dialog-title">
        <button ref={closeRef} type="button" className="hc-dialog-close" aria-label="Close room details" onClick={onClose}>
          <X size={20} />
        </button>
        <div className="hc-dialog-gallery">
          <div className="hc-dialog-media">
            {hasImages ? (
              <Image key={images[imageIndex]} src={images[imageIndex]} alt={`${room.name} at Hari's Court ${property.location}, photo ${imageIndex + 1}`} fill sizes="(max-width: 800px) 100vw, 520px" />
            ) : (
              <div className="hc-img-fallback"><ImageOff size={30} aria-hidden /><span>Photo coming soon</span></div>
            )}
          </div>
          {images.length > 1 && (
            <ul className="hc-thumbs" aria-label="Room photos">
              {images.map((src, index) => (
                <li key={src}>
                  <button type="button" className={index === imageIndex ? "is-active" : ""} aria-label={`Show photo ${index + 1}`} aria-current={index === imageIndex} onClick={() => setImageIndex(index)}>
                    <Image src={src} alt="" fill sizes="72px" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="hc-dialog-body">
          <p className="hc-eyebrow">{property.location}</p>
          <h3 id="room-dialog-title">{room.name}</h3>
          <p>{room.description}</p>
          <ul className="hc-specs">
            <li><Users size={16} /> Sleeps {room.guests}</li>
            <li><BedDouble size={16} /> {room.bed}</li>
            {room.sqft > 0 && <li><Maximize size={16} /> {room.sqft} sq. ft.</li>}
          </ul>
          <h4>Amenities</h4>
          <ul className="hc-check-list">
            {room.amenities.map((amenity) => (
              <li key={amenity}><Check size={14} /> {amenity}</li>
            ))}
          </ul>
          <h4>Stay information</h4>
          <ul className="hc-policies">
            {roomPolicies.map((policy) => (
              <li key={policy.label}><strong>{policy.label}:</strong> {policy.text}</li>
            ))}
          </ul>
          <h4>Availability</h4>
          <p className="hc-dialog-note">Live availability and the final rate are confirmed for your dates in the search results.</p>
          <div className="hc-dialog-dates">
            <label>Check in<input type="date" min={minDate || undefined} value={checkIn} onChange={(event) => setCheckIn(event.target.value)} /></label>
            <label>Check out<input type="date" min={checkIn || minDate || undefined} value={checkOut} onChange={(event) => setCheckOut(event.target.value)} /></label>
          </div>
          <div className="hc-dialog-foot">
            <p className="hc-price">
              {amount.lead && <small>{amount.lead}</small>} {amount.value} {amount.unit && <span>{amount.unit}</span>}
            </p>
            {valid ? (
              <Link href={searchHref(property, checkIn, checkOut)} className="hc-btn hc-btn-gold">Check availability &amp; book</Link>
            ) : (
              <button type="button" className="hc-btn hc-btn-gold" disabled>Choose valid dates</button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function RoomShowcase({ property, availabilityLabel = "Check Availability" }: { property: Property; availabilityLabel?: string }) {
  const [openId, setOpenId] = useState<string | null>(null);
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const openRoom = property.rooms.find((room) => room.id === openId);
  // Default stay for the "Check availability" shortcut: tonight to tomorrow.
  const defaultCheckIn = todayInIndia();
  const defaultCheckOut = formatHotelDate(new Date(Date.now() + 86400000));

  if (!property.rooms.length) {
    return <p className="hc-empty">Rooms for this property will be listed soon. Please contact us to enquire.</p>;
  }

  return (
    <>
      <div className="hc-room-grid">
        {property.rooms.map((room) => {
          const amount = price(room);
          return (
            <article key={room.id} className="hc-room-card">
              <div className="hc-room-media">
                {room.images[0] ? (
                  <Image src={room.images[0]} alt={`${room.name} at Hari's Court ${property.location}`} fill sizes="(max-width: 700px) 100vw, (max-width: 1100px) 50vw, 380px" />
                ) : (
                  <div className="hc-img-fallback"><ImageOff size={26} aria-hidden /><span>Photo coming soon</span></div>
                )}
                <span className="hc-room-badge">{amount.value} {amount.unit}</span>
              </div>
              <div className="hc-room-body">
                <h3>{room.name}</h3>
                <p>{room.description}</p>
                <ul className="hc-specs">
                  <li><Users size={15} /> {room.guests} Guests</li>
                  <li><BedDouble size={15} /> {room.bed}</li>
                  {room.sqft > 0 && <li><Maximize size={15} /> {room.sqft} sq. ft.</li>}
                </ul>
                <ul className="hc-chips">
                  {room.amenities.map((amenity) => <li key={amenity}>{amenity}</li>)}
                </ul>
                <p className="hc-price">
                  {amount.lead && <small>{amount.lead}</small>} {amount.value} {amount.unit && <span>{amount.unit}</span>}
                </p>
                <div className="hc-room-actions">
                  <button type="button" className="hc-btn hc-btn-outline" onClick={() => setOpenId(room.id)}>View Room</button>
                  <Link href={searchHref(property, defaultCheckIn, defaultCheckOut)} className="hc-btn hc-btn-gold">{availabilityLabel}</Link>
                </div>
              </div>
            </article>
          );
        })}
      </div>
      {openRoom && mounted && createPortal(<RoomDialog room={openRoom} property={property} onClose={() => setOpenId(null)} />, document.body)}
    </>
  );
}
