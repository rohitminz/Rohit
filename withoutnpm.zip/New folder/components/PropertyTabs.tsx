"use client";

import { useSelectedProperty } from "./SelectedProperty";

/** Pill selector for the properties; stays in sync with the hero cards and booking bar. */
export default function PropertyTabs({ label }: { label: string }) {
  const selected = useSelectedProperty();
  if (!selected) return null;

  return (
    <div className="hc-tabs hc-tabs-light" role="group" aria-label={label}>
      {selected.properties.map((property) => (
        <button key={property.slug} type="button" className={`hc-tab${selected.slug === property.slug ? " is-active" : ""}`} aria-pressed={selected.slug === property.slug} onClick={() => selected.setSlug(property.slug)}>
          {property.area}
          <span>{property.city}</span>
        </button>
      ))}
    </div>
  );
}
