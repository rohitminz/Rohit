"use client";

import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from "react";
import type { Property } from "@/lib/properties";

type SelectedPropertyValue = {
  properties: Property[];
  slug: string;
  property: Property;
  setSlug: (slug: string) => void;
};

const SelectedPropertyContext = createContext<SelectedPropertyValue | null>(null);

/** Keeps the hero cards, background, booking bar, rooms and map on the same property. */
export function SelectedPropertyProvider({ properties, initialSlug, children }: { properties: Property[]; initialSlug: string; children: ReactNode }) {
  const [slug, setSlugState] = useState(properties.some((item) => item.slug === initialSlug) ? initialSlug : properties[0]?.slug ?? "");
  const setSlug = useCallback((next: string) => setSlugState((current) => (properties.some((item) => item.slug === next) ? next : current)), [properties]);
  const value = useMemo<SelectedPropertyValue>(() => ({ properties, slug, property: properties.find((item) => item.slug === slug) ?? properties[0], setSlug }), [properties, slug, setSlug]);
  return <SelectedPropertyContext.Provider value={value}>{children}</SelectedPropertyContext.Provider>;
}

export function useSelectedProperty(): SelectedPropertyValue | null {
  return useContext(SelectedPropertyContext);
}
