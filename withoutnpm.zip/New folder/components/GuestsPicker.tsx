"use client";

import { useEffect, useRef, useState } from "react";
import { BedDouble, ChevronDown, Minus, Plus } from "lucide-react";

export type RoomParty = { adults: number; children: number };

export function totalAdultsOf(rooms: RoomParty[]) {
  return rooms.reduce((sum, room) => sum + room.adults, 0);
}

export function totalChildrenOf(rooms: RoomParty[]) {
  return rooms.reduce((sum, room) => sum + room.children, 0);
}

export default function GuestsPicker({ value, onChange, labelledBy }: { value: RoomParty[]; onChange: (rooms: RoomParty[]) => void; labelledBy: string }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const totalGuests = value.reduce((sum, room) => sum + room.adults + room.children, 0);

  useEffect(() => {
    if (!open) return;
    function onPointerDown(event: MouseEvent) {
      if (ref.current && !ref.current.contains(event.target as Node)) setOpen(false);
    }
    function onKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") setOpen(false);
    }
    document.addEventListener("mousedown", onPointerDown);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("mousedown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [open]);

  function updateRoom(index: number, patch: Partial<RoomParty>) {
    onChange(value.map((room, i) => (i === index ? { ...room, ...patch } : room)));
  }

  return (
    <div className="guests-root" ref={ref}>
      <div className="booking-picker">
        <BedDouble size={18} />
        <button type="button" className="guests-trigger" aria-labelledby={labelledBy} aria-expanded={open} onClick={() => setOpen((current) => !current)}>
          {value.length} Room{value.length > 1 ? "s" : ""}, {totalGuests} Guest{totalGuests > 1 ? "s" : ""}
          <ChevronDown size={14} />
        </button>
      </div>
      {open && (
        <div className="guests-popover" role="dialog" aria-label="Rooms and guests">
          {value.map((room, index) => (
            <div className="guest-room" key={index}>
              <div className="guest-room-head">
                <span>Room {index + 1}</span>
                {value.length > 1 && (
                  <button type="button" className="guest-room-remove" onClick={() => onChange(value.filter((_, i) => i !== index))}>
                    Remove
                  </button>
                )}
              </div>
              <div className="guest-counters">
                <div className="guest-counter">
                  <button type="button" className="counter-btn" aria-label="Fewer adults in room" disabled={room.adults <= 1} onClick={() => updateRoom(index, { adults: room.adults - 1 })}>
                    <Minus size={14} />
                  </button>
                  <span className="guest-counter-label">{room.adults} Adult{room.adults > 1 ? "s" : ""}</span>
                  <button type="button" className="counter-btn" aria-label="More adults in room" disabled={room.adults >= 4} onClick={() => updateRoom(index, { adults: room.adults + 1 })}>
                    <Plus size={14} />
                  </button>
                </div>
                <div className="guest-counter">
                  <button type="button" className="counter-btn" aria-label="Fewer children in room" disabled={room.children <= 0} onClick={() => updateRoom(index, { children: room.children - 1 })}>
                    <Minus size={14} />
                  </button>
                  <span className="guest-counter-label">
                    {room.children} Child{room.children > 1 ? "ren" : ""}
                    <small>(0 - 12 yrs)</small>
                  </span>
                  <button type="button" className="counter-btn" aria-label="More children in room" disabled={room.children >= 4} onClick={() => updateRoom(index, { children: room.children + 1 })}>
                    <Plus size={14} />
                  </button>
                </div>
              </div>
            </div>
          ))}
          <button type="button" className="add-room" disabled={value.length >= 4} onClick={() => onChange([...value, { adults: 1, children: 0 }])}>
            Add more rooms
          </button>
          <button type="button" className="guests-done" onClick={() => setOpen(false)}>
            Done
          </button>
        </div>
      )}
    </div>
  );
}
