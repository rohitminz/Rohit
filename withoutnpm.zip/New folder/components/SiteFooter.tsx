import Link from "next/link";
import { ArrowUpRight, Mail, Phone } from "lucide-react";
import BrandLogo from "./BrandLogo";
import { getSite } from "@/lib/content/service";

export default async function SiteFooter({ propertySlug, preview = false }: { propertySlug?: string; preview?: boolean } = {}) {
  const { settings, properties } = await getSite({ preview });
  const active = propertySlug ? properties.find((item) => item.slug === propertySlug) : undefined;
  const contactPhone = active?.contactPhone || settings.contactPhone;
  const contactEmail = active?.contactEmail || settings.contactEmail;
  const contactAddress = active?.contactAddress || settings.contactAddress;
  // Social links appear only when configured in the admin dashboard.
  const socials = [
    { label: "Instagram", href: settings.instagramUrl },
    { label: "Facebook", href: settings.facebookUrl },
    { label: "LinkedIn", href: settings.linkedinUrl },
  ].filter((item) => item.href);
  const phoneHref = `tel:${contactPhone.replace(/[^\d+]/g, "")}`;

  return (
    <footer className="hc-footer" id="contact">
      <div className="hc-footer-inner">
        <div className="hc-footer-brand">
          <BrandLogo href="/" size="footer" showName={false} className="hc-footer-logo" />
          <p>
            Hari&apos;s Court Hotels and Banquets offers comfortable accommodation and welcoming event spaces across South Delhi and Gurugram.
            Whether you&apos;re visiting for business, leisure, or a special occasion, we look forward to welcoming you.
          </p>
          {socials.length > 0 && (
            <ul className="hc-socials" aria-label="Social media">
              {socials.map((item) => (
                <li key={item.label}>
                  <a href={item.href} target="_blank" rel="noreferrer">
                    {item.label} <ArrowUpRight size={14} />
                  </a>
                </li>
              ))}
            </ul>
          )}
        </div>

        <nav className="hc-footer-col" aria-label="Quick links">
          <h4>Quick Links</h4>
          <Link href="/">Home</Link>
          <Link href="/#rooms">Rooms</Link>
          <Link href="/#locations">Our Locations</Link>
          <Link href="/#about">About Us</Link>
          <Link href="/#faq">FAQ</Link>
        </nav>

        <nav className="hc-footer-col" aria-label="Our properties">
          <h4>Our Properties</h4>
          {properties.map((property) => (
            <Link key={property.slug} href={`/locations/${property.slug}`}>
              {property.location}
            </Link>
          ))}
        </nav>

        <div className="hc-footer-col">
          <h4>Contact &amp; Banquets</h4>
          <a href={phoneHref}>
            <Phone size={14} /> {contactPhone}
          </a>
          <a href={`mailto:${contactEmail}`}>
            <Mail size={14} /> {contactEmail}
          </a>
          <span>{contactAddress}</span>
          <Link href="/#banquets" className="hc-footer-cta">
            Banquet enquiries <ArrowUpRight size={14} />
          </Link>
        </div>
      </div>
      <div className="hc-footer-base">
        <span>&copy; {new Date().getFullYear()} {settings.siteName}. All rights reserved.</span>
        <span>hariscourt.in</span>
      </div>
    </footer>
  );
}
