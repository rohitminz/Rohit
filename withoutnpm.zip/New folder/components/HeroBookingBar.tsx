"use client";

import { FormEvent, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { CalendarDays, Check, ChevronDown, MapPin } from "lucide-react";
import { formatHotelDate, todayInIndia } from "@/lib/booking-dates";
import { formatStayDate } from "@/lib/room-details";
import type { Property } from "@/lib/properties";
import { useSelectedProperty } from "./SelectedProperty";

function openPicker(input: HTMLInputElement) {
  try {
    input.showPicker();
  } catch {
    // Already open or unsupported; the native input still works.
  }
}

const range = (from: number, to: number) => Array.from({ length: to - from + 1 }, (_, index) => from + index);

/** Reservation bar. On the homepage the property follows the active card; on a location page it is fixed. */
export default function HeroBookingBar({ fixedProperty, maxGuests, phone, availabilityLabel = "Check Availability" }: { fixedProperty?: Property; maxGuests: number; phone: string; availabilityLabel?: string }) {
  const router = useRouter();
  const selected = useSelectedProperty();
  const property = fixedProperty ?? selected?.property;

  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const [minDate, setMinDate] = useState("");
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [rooms, setRooms] = useState(1);
  const [adults, setAdults] = useState(2);
  const [children, setChildren] = useState(0);
  const [error, setError] = useState("");

  useEffect(() => {
    const today = todayInIndia();
    setMinDate(today);
    setCheckIn(today);
    setCheckOut(formatHotelDate(new Date(Date.now() + 86400000)));
  }, []);

  useEffect(() => {
    if (!menuOpen) return;
    const onPointer = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) setMenuOpen(false);
    };
    const onKey = (event: KeyboardEvent) => event.key === "Escape" && setMenuOpen(false);
    document.addEventListener("mousedown", onPointer);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onPointer);
      document.removeEventListener("keydown", onKey);
    };
  }, [menuOpen]);

  function changeCheckIn(value: string) {
    setCheckIn(value);
    if (value && checkOut <= value) setCheckOut(formatHotelDate(new Date(new Date(`${value}T00:00:00Z`).getTime() + 86400000)));
  }

  function search(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    if (!property) return setError("Please choose a Hari's Court location.");
    if (!checkIn || !checkOut) return setError("Please select your check-in and check-out dates.");
    if (checkIn < (minDate || checkIn)) return setError("Check in cannot be in the past.");
    if (checkOut <= checkIn) return setError("Check out must be after check in.");
    if (adults < rooms) return setError("Each room needs at least one adult.");
    if (adults + children > maxGuests) return setError(`For more than ${maxGuests} guests, please call ${phone} for a group booking.`);
    router.push(`/availability?${new URLSearchParams({ property: property.slug, checkIn, checkOut, rooms: String(rooms), adults: String(adults), children: String(children) })}`);
  }

  return (
    <div className={`hc-booking${fixedProperty ? " is-fixed" : ""}`} id="booking">
      <form className="hc-booking-bar" aria-label="Reservation form" onSubmit={search} noValidate>
        {!fixedProperty && selected && (
          <div className="booking-field hc-property-field" ref={menuRef}>
            <label id="booking-property-label">Property</label>
            <button type="button" className="hc-property-trigger" aria-haspopup="listbox" aria-expanded={menuOpen} aria-labelledby="booking-property-label" onClick={() => setMenuOpen((open) => !open)}>
              <MapPin size={18} />
              <span>{property ? property.location : "Choose a Location"}</span>
              <ChevronDown size={16} className="hc-chevron" />
            </button>
            <ul className={`hc-property-menu${menuOpen ? " is-open" : ""}`} role="listbox" aria-labelledby="booking-property-label">
              {selected.properties.map((item) => (
                <li key={item.slug} role="option" aria-selected={item.slug === selected.slug}>
                  <button
                    type="button"
                    tabIndex={menuOpen ? 0 : -1}
                    onClick={() => {
                      selected.setSlug(item.slug);
                      setError("");
                      setMenuOpen(false);
                    }}
                  >
                    <span>
                      <strong>{item.location}</strong>
                      <small>{item.name}</small>
                    </span>
                    {item.slug === selected.slug && <Check size={16} />}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}
        <div className="booking-field hc-date-field">
          <label htmlFor="booking-check-in">Check In</label>
          <div className="booking-picker">
            <CalendarDays size={18} />
            <span>{checkIn ? formatStayDate(checkIn) : "Select date"}</span>
          </div>
          <input id="booking-check-in" className="hc-date-input" type="date" required min={minDate || undefined} value={checkIn} onClick={(event) => openPicker(event.currentTarget)} onChange={(event) => changeCheckIn(event.target.value)} />
        </div>
        <div className="booking-field hc-date-field">
          <label htmlFor="booking-check-out">Check Out</label>
          <div className="booking-picker">
            <CalendarDays size={18} />
            <span>{checkOut ? formatStayDate(checkOut) : "Select date"}</span>
          </div>
          <input
            id="booking-check-out"
            className="hc-date-input"
            type="date"
            required
            min={checkIn || minDate || undefined}
            value={checkOut}
            onClick={(event) => openPicker(event.currentTarget)}
            onChange={(event) => {
              if (checkIn && event.target.value <= checkIn) return setError("Check out must be after check in.");
              setError("");
              setCheckOut(event.target.value);
            }}
          />
        </div>
        <div className="booking-field hc-count-field">
          <label htmlFor="booking-rooms">Rooms</label>
          <select id="booking-rooms" value={rooms} onChange={(event) => setRooms(Number(event.target.value))}>
            {range(1, 4).map((n) => <option key={n} value={n}>{n}</option>)}
          </select>
        </div>
        <div className="booking-field hc-count-field">
          <label htmlFor="booking-adults">Adults</label>
          <select id="booking-adults" value={adults} onChange={(event) => setAdults(Number(event.target.value))}>
            {range(1, 8).map((n) => <option key={n} value={n}>{n}</option>)}
          </select>
        </div>
        <div className="booking-field hc-count-field">
          <label htmlFor="booking-children">Children</label>
          <select id="booking-children" value={children} onChange={(event) => setChildren(Number(event.target.value))}>
            {range(0, 6).map((n) => <option key={n} value={n}>{n}</option>)}
          </select>
        </div>
        <button type="submit" className="hc-btn hc-btn-gold hc-booking-submit">
          {availabilityLabel}
        </button>
      </form>
      <p className="hc-booking-error" role="alert" aria-live="polite">
        {error}
      </p>
    </div>
  );
}
