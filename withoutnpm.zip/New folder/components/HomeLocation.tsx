"use client";

import Link from "next/link";
import { Building2, Navigation, ShoppingBag, Train } from "lucide-react";
import { directionsUrl } from "@/lib/properties";
import PropertyMap from "./PropertyMap";
import PropertyTabs from "./PropertyTabs";
import { useSelectedProperty } from "./SelectedProperty";

const nearbyIcons = { metro: Train, hub: Building2, mall: ShoppingBag } as const;

/** Homepage location section: the map, landmarks and directions follow the active property. */
export default function HomeLocation() {
  const selected = useSelectedProperty();
  if (!selected) return null;
  const { property } = selected;

  return (
    <>
      <div className="hc-rooms-head">
        <PropertyTabs label="Show location for" />
      </div>
      <div className="hc-location" key={property.slug}>
        <div className="hc-location-copy hc-fade-swap">
          <h3 className="hc-location-title">
            {property.name} {property.location}
          </h3>
          <ul className="hc-nearby">
            {property.nearby.map((place) => {
              const Icon = nearbyIcons[place.icon];
              return (
                <li key={place.label}>
                  <span className="hc-nearby-icon"><Icon size={18} /></span>
                  <span>
                    <strong>{place.label}</strong>
                    <small>{place.time}</small>
                  </span>
                </li>
              );
            })}
          </ul>
          <div className="hc-location-actions">
            <a className="hc-btn hc-btn-gold" href={directionsUrl(property)} target="_blank" rel="noreferrer">
              <Navigation size={18} /> Get Directions
            </a>
            <Link className="hc-btn hc-btn-outline" href={`/locations/${property.slug}`}>
              Property page
            </Link>
          </div>
        </div>
        <div className="hc-location-map">
          <PropertyMap property={property} />
        </div>
      </div>
    </>
  );
}
