import "server-only";
import fs from "node:fs/promises";
import path from "node:path";
import { randomBytes } from "node:crypto";

/**
 * Local fallback store for reservations taken while the live booking backend (Supabase) and the
 * payment provider are not connected. Records are kept in data/reservations.json so they persist
 * across restarts and can be shown in the admin dashboard. This is NOT a substitute for the real
 * database — on read-only hosting the write is skipped and the caller is told it was not saved.
 *
 * The shape matches AdminData["reservations"] so the dashboard can render these directly.
 */
export type StoredReservation = {
  reference: string;
  guest_name: string;
  guest_email: string;
  guest_phone: string;
  guests: number;
  special_requests: string;
  check_in: string;
  check_out: string;
  total_amount_inr: number;
  amount_paid: number;
  charges?: { id: string; label: string; amount: number; at: string; image?: string }[];
  payments?: { id: string; amount: number; note: string; at: string }[];
  status: string;
  created_at: string;
  room_types: { name: string; property_name: string };
  property_slug: string;
  emailed: boolean;
};

const FILE = path.join(process.cwd(), "data", "reservations.json");

export function makeReference(): string {
  return `HC-${Date.now().toString(36).toUpperCase()}-${randomBytes(2).toString("hex").toUpperCase()}`;
}

export async function listReservations(): Promise<StoredReservation[]> {
  try {
    const raw = await fs.readFile(FILE, "utf8");
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as StoredReservation[]) : [];
  } catch {
    return [];
  }
}

/** Appends a reservation. Returns true if it was persisted to disk. */
export async function saveReservation(record: StoredReservation): Promise<boolean> {
  try {
    const all = await listReservations();
    all.unshift(record);
    await fs.mkdir(path.dirname(FILE), { recursive: true });
    await fs.writeFile(FILE, JSON.stringify(all.slice(0, 500), null, 2), "utf8");
    return true;
  } catch (error) {
    console.error("Could not persist reservation to local store", error instanceof Error ? error.message : error);
    return false;
  }
}

/** Updates a stored reservation's status. Returns true if a matching reservation was found and saved. */
export async function updateReservationStatus(reference: string, status: string): Promise<boolean> {
  return updateReservation(reference, { status });
}

/** Updates a stored reservation's status and/or amount paid. Returns true if a match was found. */
export async function updateReservation(reference: string, patch: { status?: string; amount_paid?: number; charges?: StoredReservation["charges"]; payments?: StoredReservation["payments"] }): Promise<boolean> {
  try {
    const all = await listReservations();
    const index = all.findIndex((item) => item.reference === reference);
    if (index === -1) return false;
    const next = { ...all[index] };
    if (patch.status !== undefined) next.status = patch.status;
    if (patch.amount_paid !== undefined) next.amount_paid = Math.max(0, Math.round(patch.amount_paid));
    if (patch.charges !== undefined) next.charges = patch.charges;
    if (patch.payments !== undefined) next.payments = patch.payments;
    all[index] = next;
    await fs.mkdir(path.dirname(FILE), { recursive: true });
    await fs.writeFile(FILE, JSON.stringify(all.slice(0, 500), null, 2), "utf8");
    return true;
  } catch (error) {
    console.error("Could not update reservation", error instanceof Error ? error.message : error);
    return false;
  }
}
