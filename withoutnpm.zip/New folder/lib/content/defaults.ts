import { roomPolicies } from "@/lib/room-details";
import type { SiteContent } from "./schema";

const timing = (label: string) => roomPolicies.find((policy) => policy.label === label)?.text ?? "";

type Seed = { slug: string; backendKey: "gurugram" | "delhi"; order: number; area: string; city: string; location: string; summary: string; description: string; image: string; mapQuery: string; nearby: SiteContent["properties"][number]["nearby"]; rates: [number, number, number]; place: string; contactPhone: string; contactEmail: string; contactAddress: string };

const seeds: Seed[] = [
  {
    slug: "cyber-city", backendKey: "gurugram", order: 0, area: "Cyber City", city: "Gurugram", location: "Cyber City, Gurugram", place: "Cyber City", rates: [4800, 6600, 9400],
    summary: "Built for business travellers who want a calm room close to DLF Cyber City.",
    description: "Built for business travellers who want a calm room close to DLF Cyber City.",
    image: "/images/properties/cyber-city.jpg", mapQuery: "Hari's Court, Cyber City, Gurugram",
    contactPhone: "+91 124 410 2201", contactEmail: "cybercity@hariscourt.in", contactAddress: "Tower B, DLF Cyber City, Phase 2, Gurugram, Haryana 122002",
    nearby: [
      { label: "Cyber City Metro", time: "8 mins", icon: "metro", query: "Cyber City Metro Station, Gurugram" },
      { label: "DLF Cyber Hub", time: "6 mins", icon: "hub", query: "DLF Cyber Hub, Gurugram" },
      { label: "Worldmark", time: "10 mins", icon: "mall", query: "Worldmark Gurugram" },
    ],
  },
  {
    slug: "cyber-hub", backendKey: "gurugram", order: 1, area: "Cyber Hub", city: "Gurugram", location: "Cyber Hub, Gurugram", place: "Cyber Hub", rates: [4600, 6400, 9100],
    summary: "Steps from Cyber Hub's restaurants and offices, a compact contemporary inn for short stays.",
    description: "Steps from Cyber Hub's restaurants and offices. A compact, contemporary inn for short stays, dinners out, and early meetings.",
    image: "/images/properties/cyber-hub.png", mapQuery: "Hari's Court, Cyber Hub, Gurugram",
    contactPhone: "+91 124 410 2202", contactEmail: "cyberhub@hariscourt.in", contactAddress: "DLF Cyber Hub, DLF Phase 2, Gurugram, Haryana 122002",
    nearby: [
      { label: "Gateway Tower", time: "3 mins", icon: "hub", query: "Gateway Tower, Cyber Hub, Gurugram" },
      { label: "Cyber Hub Metro", time: "7 mins", icon: "metro", query: "Cyber Hub Metro Station, Gurugram" },
      { label: "Ambience Mall", time: "12 mins", icon: "mall", query: "Ambience Mall, Gurugram" },
    ],
  },
  {
    slug: "mg-road", backendKey: "gurugram", order: 2, area: "MG Road", city: "Gurugram", location: "MG Road, Gurugram", place: "Gurugram", rates: [4500, 6200, 8900],
    summary: "A refined stay in the heart of Gurugram, close to the city's business and lifestyle destinations.",
    description: "Experience a comfortable and refined stay in the heart of Gurugram. Enjoy thoughtfully designed rooms, modern amenities and convenient access to the city's key business and lifestyle destinations.",
    image: "/images/properties/mg-road.jpg", mapQuery: "Hari's Court, MG Road, Gurugram",
    contactPhone: "+91 124 410 2203", contactEmail: "mgroad@hariscourt.in", contactAddress: "MG Road, Sector 28, Gurugram, Haryana 122001",
    nearby: [
      { label: "MG Road Metro Station", time: "5 mins", icon: "metro", query: "MG Road Metro Station, Gurugram" },
      { label: "Cyber Hub", time: "10 mins", icon: "hub", query: "DLF Cyber Hub, Gurugram" },
      { label: "Ambience Mall", time: "15 mins", icon: "mall", query: "Ambience Mall, Gurugram" },
    ],
  },
  {
    slug: "lajpat-nagar", backendKey: "delhi", order: 3, area: "Lajpat Nagar", city: "Delhi", location: "Lajpat Nagar, Delhi", place: "South Delhi", rates: [4200, 5800, 8200],
    summary: "A leafy South Delhi address beside Central Market, with cafes, boutiques and the metro on foot.",
    description: "A leafy South Delhi address beside Central Market. Walk to cafes, boutiques and the metro, then return to quiet, well-appointed rooms.",
    image: "/images/properties/lajpat.png", mapQuery: "Hari's Court, Lajpat Nagar, New Delhi",
    contactPhone: "+91 11 4100 2204", contactEmail: "lajpatnagar@hariscourt.in", contactAddress: "Central Market, Lajpat Nagar, New Delhi, Delhi 110024",
    nearby: [
      { label: "Lajpat Nagar Metro", time: "6 mins", icon: "metro", query: "Lajpat Nagar Metro Station, New Delhi" },
      { label: "Central Market", time: "4 mins", icon: "mall", query: "Central Market, Lajpat Nagar, New Delhi" },
      { label: "Defence Colony", time: "12 mins", icon: "hub", query: "Defence Colony, New Delhi" },
    ],
  },
];

export function buildDefaultContent(): SiteContent {
  const properties = seeds.map<SiteContent["properties"][number]>((seed) => ({
    slug: seed.slug, backendKey: seed.backendKey, order: seed.order, active: true,
    name: "Hari's Court", area: seed.area, city: seed.city, location: seed.location,
    summary: seed.summary, description: seed.description,
    cardImage: seed.image, backgroundImage: seed.image, backgroundBlur: true,
    mapQuery: seed.mapQuery, nearby: seed.nearby,
    contactPhone: seed.contactPhone, contactEmail: seed.contactEmail, contactAddress: seed.contactAddress,
  }));

  const rooms = seeds.flatMap<SiteContent["rooms"][number]>((seed) => [
    { id: `${seed.slug}-superior`, propertySlug: seed.slug, order: 0, active: true, name: "Superior Room", description: `A comfortable retreat in the heart of ${seed.place}.`, guests: 2, bed: "1 King Bed", sqft: 220, amenities: ["Free Wi-Fi", "Air Conditioning", "Smart TV"], images: ["/images/haris/room-alt-1.jpg", "/images/haris/room-alt-2.jpg", "/images/haris/room-deluxe.jpg"], rate: seed.rates[0], priceStatus: "placeholder" },
    { id: `${seed.slug}-deluxe`, propertySlug: seed.slug, order: 1, active: true, name: "Deluxe Room", description: `A quieter stay with extra space overlooking ${seed.place}.`, guests: 3, bed: "1 King Bed", sqft: 280, amenities: ["Free Wi-Fi", "Mini Bar", "City View"], images: ["/images/haris/room-deluxe.jpg", "/images/haris/room-alt-3.jpg", "/images/haris/room-alt-1.jpg"], rate: seed.rates[1], priceStatus: "placeholder" },
    { id: `${seed.slug}-suite`, propertySlug: seed.slug, order: 2, active: true, name: "Executive Suite", description: `A refined suite for longer stays and small gatherings in ${seed.place}.`, guests: 4, bed: "1 King + Sofa", sqft: 420, amenities: ["Free Wi-Fi", "Living Area", "Work Desk"], images: ["/images/haris/room-executive.jpg", "/images/haris/room-presidential.jpg", "/images/haris/room-alt-3.jpg"], rate: seed.rates[2], priceStatus: "placeholder" },
  ]);

  const gallery = [
    ...seeds.map<SiteContent["gallery"][number]>((seed, index) => ({ id: `${seed.slug}-exterior`, scope: seed.slug, url: seed.image, alt: `Hari's Court ${seed.location}`, order: index })),
    ...[1, 2, 3, 4, 5].map<SiteContent["gallery"][number]>((n) => ({ id: `site-gallery-${n}`, scope: "site", url: `/images/haris/gallery-${n}.jpg`, alt: "Hari's Court", order: n })),
    { id: "site-dining", scope: "site", url: "/images/haris/facility-dining.jpg", alt: "Dining at Hari's Court", order: 6 },
  ];

  return {
    version: 1,
    publishedAt: new Date(0).toISOString(),
    settings: {
      siteName: "Hari's Court Hotels & Inns",
      contactPhone: "+91 124 410 2200",
      contactEmail: "reservations@hariscourt.in",
      contactAddress: "Hari's Court Hotels & Inns, Gurugram & New Delhi",
      reservationEmails: "",
      instagramUrl: "", facebookUrl: "", linkedinUrl: "",
      bookCtaLabel: "Book Now",
      availabilityCtaLabel: "Check Availability",
      exploreCtaLabel: "Explore Property",
      maxOnlineGuests: 6,
    },
    home: {
      heroEyebrow: "Hari's Court Hotels & Inns",
      heroTitle: "Stay • Celebrate • Host",
      heroSubtitle: "Premium Hotels & Banquets Across Gurugram & Delhi",
      highlightsHeading: "Everything you need for a comfortable stay",
      aboutEyebrow: "About Hari's Court",
      aboutHeading: "Hospitality that feels like home",
      aboutParagraphs: [
        "Since 2011, Hari's Court Hotels and Banquets has welcomed business travellers, leisure guests, couples, and families to comfortable accommodation across South Delhi and Gurugram.",
        "Our properties combine convenient locations with thoughtfully appointed rooms and attentive hospitality, providing a welcoming base for work, relaxation, and city exploration.",
        "From a business trip to a family visit or a special celebration, we strive to make every guest's experience comfortable, convenient, and memorable.",
      ],
      aboutImage: "/images/haris/about-signage.jpg",
      aboutImageSecondary: "/images/haris/facility-frontdesk.jpg",
      roomsHeading: "Featured rooms",
      roomsIntro: "Choose a property to see its rooms. Rates shown are starting rates; live availability appears once you search your dates.",
      banquetEyebrow: "Banquets & Events",
      banquetHeading: "Celebrate with us",
      banquetText: "Hari's Court offers welcoming event spaces for the occasions that matter. Tell us about your event and our team will get in touch with the details.",
      banquetImage: "/images/haris/facility-banquet.jpg",
      eventTypes: [
        { title: "Weddings & celebrations", text: "Receptions, engagements and family milestones." },
        { title: "Corporate events", text: "Meetings, offsites and business gatherings." },
        { title: "Private functions", text: "Intimate dinners and get-togethers." },
      ],
      offersHeading: "Offers",
      offersIntro: "Placeholder offers: replace these in the admin dashboard with your current packages.",
      offers: [
        { id: "stay-offers", title: "Stay offers", text: "Contact our team to hear about current offers for your stay.", cta: "Enquire now", href: "#banquets", enabled: true },
        { id: "event-packages", title: "Celebration & banquet packages", text: "Tell us about your event and we will share the packages available.", cta: "Plan your event", href: "#banquets", enabled: true },
      ],
      testimonialsHeading: "What our guests say",
      // Carried over from the previous homepage. Replace with verified guest reviews before launch.
      testimonials: [
        { name: "Priya Sharma", location: "India", quote: "An absolutely breathtaking experience. The room service, ambience, and wellness offerings were exceptional." },
        { name: "Rahul Mehta", location: "India", quote: "Hari's Court is the perfect blend of luxury and comfort. Highly recommended for a serene stay and exceptional service." },
        { name: "Ayesha Khan", location: "Dubai", quote: "From check-in to check-out, everything was seamless. The property is beautifully designed and incredibly calming." },
      ],
      locationHeading: "Find your Hari's Court",
      locationIntro: "Four locations across Gurugram and Delhi. Select a property to see it on the map.",
      faqs: [
        { question: "How can I book a room?", answer: "Choose a Hari's Court location, your check-in and check-out dates and your guests in the booking bar, then select Check Availability. Pick a room from the results and complete the reservation form." },
        { question: "How can I check room availability?", answer: "Use the booking bar on the homepage or on any property page. Available room types and rates for your dates are shown after you search." },
        { question: "What are the check-in and check-out timings?", answer: `Check-in is at ${timing("Check-in")} and check-out is at ${timing("Check-out")}.` },
        { question: "What is the cancellation policy?", answer: `${timing("Cancellation")}. Payment: ${timing("Payment")}.` },
        { question: "How can I contact a property?", answer: "Call +91 98123 45678 or write to hello@hariscourt.com. You can also use the enquiry form in the Banquets section." },
        { question: "How do I enquire about banquet bookings?", answer: "Send an enquiry from the Banquets section, choosing \"A celebration or event\". Our team will get back to you with details." },
      ],
    },
    properties,
    rooms,
    amenities: [
      { id: "air-conditioning", icon: "ac", title: "Air Conditioning", text: "Comfortable rooms for every season", order: 0 },
      { id: "wifi", icon: "wifi", title: "High-Speed Wi-Fi", text: "Stay connected for work and leisure", order: 1 },
      { id: "dining", icon: "dining", title: "In-House Dining", text: "Dining options vary by property", order: 2 },
      { id: "housekeeping", icon: "housekeeping", title: "Daily Housekeeping", text: "Clean, well-kept rooms throughout your stay", order: 3 },
      { id: "room-service", icon: "service", title: "Room Service", text: "Available as per property", order: 4 },
      { id: "front-desk", icon: "desk", title: "24-Hour Front Desk", text: "Assistance whenever you need it", order: 5 },
    ],
    gallery,
    seo: [
      { page: "home", title: "Hari's Court Hotels & Inns | Stay, Celebrate, Host", description: "Premium hotels and banquets across Gurugram and Delhi. Choose from four Hari's Court locations.", ogImage: "/images/properties/mg-road.jpg" },
      ...seeds.map((seed) => ({ page: `locations/${seed.slug}`, title: `Hari's Court ${seed.location}`, description: seed.summary, ogImage: seed.image })),
    ],
    users: [],
  };
}
