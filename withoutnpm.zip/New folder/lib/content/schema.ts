import { z } from "zod";

const imageRef = z
  .string()
  .trim()
  .max(500)
  .refine((value) => value === "" || (value.startsWith("/") && !value.startsWith("//")) || /^https:\/\/\S+$/.test(value), "Use a site path such as /images/room.jpg or an https URL.");
const short = (max = 160) => z.string().trim().max(max);
const long = (max = 2000) => z.string().trim().max(max);
const slug = z.string().trim().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "Use lowercase letters, numbers and hyphens.").max(40);

export const nearbySchema = z.object({
  label: short(80),
  time: short(30),
  icon: z.enum(["metro", "hub", "mall"]),
  query: short(160),
});

export const propertySchema = z.object({
  slug,
  /** The reservation backend (Supabase) only knows these keys until more properties are added there. */
  backendKey: z.enum(["gurugram", "delhi"]),
  order: z.number().int().min(0).max(99),
  active: z.boolean(),
  name: short(80),
  area: short(60),
  city: short(60),
  location: short(120),
  summary: long(300),
  description: long(1200),
  cardImage: imageRef,
  backgroundImage: imageRef,
  backgroundBlur: z.boolean(),
  mapQuery: short(200),
  nearby: z.array(nearbySchema).max(8),
  contactPhone: short(40),
  contactEmail: short(120),
  contactAddress: long(300),
});

export const roomSchema = z.object({
  id: slug,
  propertySlug: slug,
  order: z.number().int().min(0).max(99),
  active: z.boolean(),
  name: short(80),
  description: long(600),
  guests: z.number().int().min(1).max(12),
  bed: short(60),
  sqft: z.number().int().min(0).max(5000),
  amenities: z.array(short(60)).max(20),
  images: z.array(imageRef).max(12),
  rate: z.number().int().min(0).max(1_000_000),
  priceStatus: z.enum(["configured", "placeholder", "on-request"]),
});

export const amenitySchema = z.object({
  id: slug,
  icon: z.enum(["ac", "wifi", "dining", "housekeeping", "service", "desk", "parking", "tv"]),
  title: short(60),
  text: short(160),
  order: z.number().int().min(0).max(99),
});

export const gallerySchema = z.object({
  id: slug,
  /** "site" or a property slug. */
  scope: slug,
  url: imageRef,
  alt: short(160),
  order: z.number().int().min(0).max(99),
});

export const seoSchema = z.object({
  page: short(80),
  title: short(120),
  description: short(300),
  ogImage: imageRef,
});

export const userSchema = z.object({
  email: z.string().trim().email().max(160),
  name: short(80),
  role: z.enum(["admin", "editor", "viewer"]),
  status: z.enum(["active", "disabled"]),
});

export const homeSchema = z.object({
  heroEyebrow: short(80),
  heroTitle: short(80),
  heroSubtitle: short(200),
  highlightsHeading: short(120),
  aboutEyebrow: short(60),
  aboutHeading: short(120),
  aboutParagraphs: z.array(long(900)).max(6),
  aboutImage: imageRef,
  aboutImageSecondary: imageRef,
  roomsHeading: short(120),
  roomsIntro: long(400),
  banquetEyebrow: short(60),
  banquetHeading: short(120),
  banquetText: long(600),
  banquetImage: imageRef,
  eventTypes: z.array(z.object({ title: short(80), text: short(200) })).max(8),
  offersHeading: short(120),
  offersIntro: long(300),
  offers: z.array(z.object({ id: slug, title: short(100), text: long(400), cta: short(40), href: short(200), enabled: z.boolean() })).max(8),
  testimonialsHeading: short(120),
  testimonials: z.array(z.object({ name: short(80), location: short(80), quote: long(600) })).max(12),
  locationHeading: short(120),
  locationIntro: long(400),
  faqs: z.array(z.object({ question: short(200), answer: long(1200) })).max(20),
});

export const settingsSchema = z.object({
  siteName: short(80),
  contactPhone: short(40),
  contactEmail: short(120),
  contactAddress: long(300),
  reservationEmails: short(400),
  instagramUrl: short(300),
  facebookUrl: short(300),
  linkedinUrl: short(300),
  bookCtaLabel: short(40),
  availabilityCtaLabel: short(40),
  exploreCtaLabel: short(40),
  maxOnlineGuests: z.number().int().min(1).max(30),
});

export const contentSchema = z
  .object({
    version: z.number().int().min(0),
    publishedAt: z.string(),
    settings: settingsSchema,
    home: homeSchema,
    properties: z.array(propertySchema).min(1).max(12),
    rooms: z.array(roomSchema).max(200),
    amenities: z.array(amenitySchema).max(40),
    gallery: z.array(gallerySchema).max(300),
    seo: z.array(seoSchema).max(60),
    users: z.array(userSchema).max(100),
  })
  .superRefine((content, ctx) => {
    const slugs = new Set<string>();
    content.properties.forEach((property, index) => {
      if (slugs.has(property.slug)) ctx.addIssue({ code: "custom", path: ["properties", index, "slug"], message: "Duplicate property slug." });
      slugs.add(property.slug);
    });
    const roomIds = new Set<string>();
    content.rooms.forEach((room, index) => {
      if (roomIds.has(room.id)) ctx.addIssue({ code: "custom", path: ["rooms", index, "id"], message: "Duplicate room id." });
      roomIds.add(room.id);
      if (!slugs.has(room.propertySlug)) ctx.addIssue({ code: "custom", path: ["rooms", index, "propertySlug"], message: "Room points to an unknown property." });
    });
  });

export type PropertyRecord = z.infer<typeof propertySchema>;
export type RoomRecord = z.infer<typeof roomSchema>;
export type AmenityRecord = z.infer<typeof amenitySchema>;
export type GalleryRecord = z.infer<typeof gallerySchema>;
export type SeoRecord = z.infer<typeof seoSchema>;
export type UserRecord = z.infer<typeof userSchema>;
export type HomeContent = z.infer<typeof homeSchema>;
export type SiteSettings = z.infer<typeof settingsSchema>;
export type SiteContent = z.infer<typeof contentSchema>;
export type NearbyPlace = z.infer<typeof nearbySchema>;
