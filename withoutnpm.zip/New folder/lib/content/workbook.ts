import "server-only";
import ExcelJS from "exceljs";
import { buildDefaultContent } from "./defaults";
import { contentSchema, type SiteContent } from "./schema";

export const SHEETS = {
  properties: ["slug", "backendKey", "order", "active", "name", "area", "city", "location", "summary", "description", "cardImage", "backgroundImage", "backgroundBlur", "mapQuery", "nearby", "contactPhone", "contactEmail", "contactAddress"],
  rooms: ["id", "propertySlug", "order", "active", "name", "description", "guests", "bed", "sqft", "amenities", "images"],
  pricing: ["roomId", "rateInr", "currency", "priceStatus", "note"],
  availability: ["roomId", "date", "available", "note"],
  bookings: ["reference", "guestName", "guestEmail", "property", "room", "checkIn", "checkOut", "totalInr", "status", "createdAt"],
  guests: ["email", "name", "phone", "lastStay"],
  enquiries: ["id", "name", "email", "phone", "kind", "message", "status", "createdAt"],
  amenities: ["id", "icon", "title", "text", "order"],
  gallery: ["id", "scope", "url", "alt", "order"],
  websiteContent: ["key", "value"],
  seo: ["page", "title", "description", "ogImage"],
  users: ["email", "name", "role", "status"],
  meta: ["key", "value"],
  drafts: ["key", "value"],
} as const;

export const SHEET_NAMES: Record<keyof typeof SHEETS, string> = {
  properties: "Properties",
  rooms: "Rooms",
  pricing: "Pricing",
  availability: "Availability",
  bookings: "Bookings",
  guests: "Guests",
  enquiries: "Enquiries",
  amenities: "Amenities",
  gallery: "Gallery",
  websiteContent: "WebsiteContent",
  seo: "SEO",
  users: "Users",
  meta: "Meta",
  drafts: "Drafts",
};

// Excel cells hold at most 32,767 characters, so draft JSON is split across rows.
const CHUNK = 30000;

export type DraftRecord = { content: SiteContent; savedAt: string; savedBy: string };

type Row = Record<string, string | number | boolean>;

function sheet(workbook: ExcelJS.Workbook, key: keyof typeof SHEETS): ExcelJS.Worksheet {
  return workbook.getWorksheet(SHEET_NAMES[key]) ?? workbook.addWorksheet(SHEET_NAMES[key]);
}

/** Rewrites one sheet in place so rows on other sheets (bookings, guests, enquiries, availability) are never touched. */
function writeSheet(workbook: ExcelJS.Workbook, key: keyof typeof SHEETS, rows: Row[]) {
  const ws = sheet(workbook, key);
  const headers = SHEETS[key];
  const previousRows = ws.rowCount;
  // Rows are overwritten by position; spliceRows(1, rowCount) leaves the old rows in place and addRow then appends duplicates.
  [[...headers], ...rows.map((row) => headers.map((header) => row[header] ?? ""))].forEach((values, index) => {
    ws.getRow(index + 1).values = values;
  });
  for (let index = rows.length + 2; index <= previousRows; index += 1) ws.getRow(index).values = [];
  ws.getRow(1).font = { bold: true };
  ws.views = [{ state: "frozen", ySplit: 1 }];
  ws.columns = headers.map((header) => ({ key: header, width: Math.min(48, Math.max(14, header.length + 6)) }));
}

function ensureSheet(workbook: ExcelJS.Workbook, key: keyof typeof SHEETS) {
  const ws = sheet(workbook, key);
  if (ws.rowCount === 0) {
    ws.addRow([...SHEETS[key]]).font = { bold: true };
    ws.views = [{ state: "frozen", ySplit: 1 }];
  }
}

function cellText(value: ExcelJS.CellValue): string {
  if (value === null || value === undefined) return "";
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "object") {
    if ("richText" in value) return value.richText.map((part) => part.text).join("");
    if ("result" in value) return String(value.result ?? "");
    if ("text" in value) return String(value.text);
    return "";
  }
  return String(value);
}

function readRows(workbook: ExcelJS.Workbook, key: keyof typeof SHEETS): Record<string, string>[] {
  const ws = workbook.getWorksheet(SHEET_NAMES[key]);
  if (!ws || ws.rowCount < 2) return [];
  const headers = SHEETS[key];
  const rows: Record<string, string>[] = [];
  ws.eachRow((row, index) => {
    if (index === 1) return;
    const record: Record<string, string> = {};
    headers.forEach((header, column) => {
      record[header] = cellText(row.getCell(column + 1).value).trim();
    });
    if (Object.values(record).some(Boolean)) rows.push(record);
  });
  return rows;
}

const bool = (value: string) => ["true", "1", "yes", "y"].includes(value.toLowerCase());
const int = (value: string, fallback = 0) => (Number.isFinite(Number(value)) && value !== "" ? Math.round(Number(value)) : fallback);

function json<T>(value: string, fallback: T): T {
  if (!value) return fallback;
  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
}

export function applyContent(workbook: ExcelJS.Workbook, content: SiteContent) {
  writeSheet(workbook, "properties", content.properties.map((p) => ({ ...p, nearby: JSON.stringify(p.nearby) })));
  writeSheet(workbook, "rooms", content.rooms.map((r) => ({ id: r.id, propertySlug: r.propertySlug, order: r.order, active: r.active, name: r.name, description: r.description, guests: r.guests, bed: r.bed, sqft: r.sqft, amenities: r.amenities.join(", "), images: JSON.stringify(r.images) })));
  writeSheet(workbook, "pricing", content.rooms.map((r) => ({ roomId: r.id, rateInr: r.rate, currency: "INR", priceStatus: r.priceStatus, note: r.priceStatus === "placeholder" ? "Indicative starting rate. Confirm before publishing." : "" })));
  writeSheet(workbook, "amenities", content.amenities);
  writeSheet(workbook, "gallery", content.gallery);
  writeSheet(workbook, "seo", content.seo);
  writeSheet(workbook, "users", content.users);
  const websiteRows: Row[] = [
    ...Object.entries(content.settings).map(([key, value]) => ({ key: `settings.${key}`, value: typeof value === "string" ? value : JSON.stringify(value) })),
    ...Object.entries(content.home).map(([key, value]) => ({ key: `home.${key}`, value: typeof value === "string" ? value : JSON.stringify(value) })),
  ];
  writeSheet(workbook, "websiteContent", websiteRows);
  writeSheet(workbook, "meta", [
    { key: "version", value: content.version },
    { key: "publishedAt", value: content.publishedAt },
  ]);
  (["availability", "bookings", "guests", "enquiries"] as const).forEach((key) => ensureSheet(workbook, key));
}

export function applyDraft(workbook: ExcelJS.Workbook, draft: DraftRecord | null) {
  if (!draft) {
    writeSheet(workbook, "drafts", []);
    return;
  }
  const serialized = JSON.stringify(draft.content);
  const rows: Row[] = [
    { key: "savedAt", value: draft.savedAt },
    { key: "savedBy", value: draft.savedBy },
  ];
  for (let index = 0; index * CHUNK < serialized.length; index += 1) {
    rows.push({ key: `snapshot.${index}`, value: serialized.slice(index * CHUNK, (index + 1) * CHUNK) });
  }
  writeSheet(workbook, "drafts", rows);
}

export function readContent(workbook: ExcelJS.Workbook): SiteContent {
  const defaults = buildDefaultContent();
  const meta = Object.fromEntries(readRows(workbook, "meta").map((row) => [row.key, row.value]));
  const web = Object.fromEntries(readRows(workbook, "websiteContent").map((row) => [row.key, row.value]));

  const settings = { ...defaults.settings } as Record<string, unknown>;
  for (const key of Object.keys(defaults.settings)) {
    const stored = web[`settings.${key}`];
    if (stored === undefined) continue;
    settings[key] = typeof (defaults.settings as Record<string, unknown>)[key] === "number" ? int(stored, 0) : stored;
  }
  const home = { ...defaults.home } as Record<string, unknown>;
  for (const key of Object.keys(defaults.home)) {
    const stored = web[`home.${key}`];
    if (stored === undefined) continue;
    home[key] = typeof (defaults.home as Record<string, unknown>)[key] === "string" ? stored : json(stored, (defaults.home as Record<string, unknown>)[key]);
  }

  const pricing = new Map(readRows(workbook, "pricing").map((row) => [row.roomId, row]));
  const candidate = {
    version: int(meta.version ?? "", defaults.version),
    publishedAt: meta.publishedAt || defaults.publishedAt,
    settings,
    home,
    properties: readRows(workbook, "properties").map((row) => ({
      slug: row.slug, backendKey: row.backendKey, order: int(row.order), active: bool(row.active), name: row.name, area: row.area, city: row.city, location: row.location,
      summary: row.summary, description: row.description, cardImage: row.cardImage, backgroundImage: row.backgroundImage, backgroundBlur: bool(row.backgroundBlur),
      mapQuery: row.mapQuery, nearby: json(row.nearby, []), contactPhone: row.contactPhone, contactEmail: row.contactEmail, contactAddress: row.contactAddress,
    })),
    rooms: readRows(workbook, "rooms").map((row) => {
      const price = pricing.get(row.id);
      return {
        id: row.id, propertySlug: row.propertySlug, order: int(row.order), active: bool(row.active), name: row.name, description: row.description,
        guests: int(row.guests, 2), bed: row.bed, sqft: int(row.sqft), amenities: row.amenities ? row.amenities.split(",").map((item) => item.trim()).filter(Boolean) : [],
        images: json(row.images, []), rate: int(price?.rateInr ?? "", 0), priceStatus: price?.priceStatus || "on-request",
      };
    }),
    amenities: readRows(workbook, "amenities").map((row) => ({ id: row.id, icon: row.icon, title: row.title, text: row.text, order: int(row.order) })),
    gallery: readRows(workbook, "gallery").map((row) => ({ id: row.id, scope: row.scope, url: row.url, alt: row.alt, order: int(row.order) })),
    seo: readRows(workbook, "seo").map((row) => ({ page: row.page, title: row.title, description: row.description, ogImage: row.ogImage })),
    users: readRows(workbook, "users").map((row) => ({ email: row.email, name: row.name, role: row.role, status: row.status })),
  };
  return contentSchema.parse(candidate);
}

export function readDraft(workbook: ExcelJS.Workbook): DraftRecord | null {
  const rows = readRows(workbook, "drafts");
  if (!rows.length) return null;
  const values = Object.fromEntries(rows.map((row) => [row.key, row.value]));
  const serialized = rows
    .filter((row) => row.key.startsWith("snapshot."))
    .sort((a, b) => Number(a.key.split(".")[1]) - Number(b.key.split(".")[1]))
    .map((row) => row.value)
    .join("");
  if (!serialized) return null;
  const parsed = contentSchema.safeParse(json(serialized, null));
  if (!parsed.success) return null;
  return { content: parsed.data, savedAt: values.savedAt ?? "", savedBy: values.savedBy ?? "" };
}

export function createSeedWorkbook(): ExcelJS.Workbook {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = "Hari's Court website";
  (Object.keys(SHEETS) as (keyof typeof SHEETS)[]).forEach((key) => sheet(workbook, key));
  applyContent(workbook, { ...buildDefaultContent(), version: 1, publishedAt: new Date().toISOString() });
  applyDraft(workbook, null);
  return workbook;
}

export async function workbookFromBuffer(buffer: Buffer): Promise<ExcelJS.Workbook> {
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(buffer as unknown as ExcelJS.Buffer);
  return workbook;
}

export async function workbookToBuffer(workbook: ExcelJS.Workbook): Promise<Buffer> {
  return Buffer.from(await workbook.xlsx.writeBuffer());
}
