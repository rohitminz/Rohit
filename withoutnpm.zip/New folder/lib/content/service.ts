import "server-only";
import { requireAdmin } from "@/lib/admin-auth";
import { buildDefaultContent } from "./defaults";
import type { AmenityRecord, GalleryRecord, HomeContent, SeoRecord, SiteSettings } from "./schema";
import { readState, defaultsState, type ContentState } from "./store";
import type { Property } from "@/lib/properties";

export type SiteView = {
  settings: SiteSettings;
  home: HomeContent;
  properties: Property[];
  amenities: AmenityRecord[];
  siteGallery: GalleryRecord[];
  seo: SeoRecord[];
  isPreview: boolean;
};

const byOrder = <T extends { order: number }>(a: T, b: T) => a.order - b.order;

/** Whether the request may see the unpublished draft: `?preview=1` and a signed-in administrator. */
export async function wantsPreview(flag: string | undefined): Promise<boolean> {
  return flag === "1" && (await requireAdmin()).ok;
}

async function stateOrDefaults(): Promise<ContentState> {
  try {
    return await readState();
  } catch (error) {
    console.error("Content workbook unavailable; serving built-in defaults.", error instanceof Error ? error.message : error);
    return defaultsState();
  }
}

/** Single entry point the public pages use to read website content (published, or the draft when previewing). */
export async function getSite({ preview = false }: { preview?: boolean } = {}): Promise<SiteView> {
  const state = await stateOrDefaults();
  const useDraft = preview && state.draft !== null;
  const content = useDraft ? state.draft!.content : state.published ?? buildDefaultContent();
  const properties = content.properties
    .filter((property) => property.active)
    .sort(byOrder)
    .map<Property>((property) => ({
      ...property,
      rooms: content.rooms.filter((room) => room.propertySlug === property.slug && room.active).sort(byOrder),
      gallery: content.gallery.filter((image) => image.scope === property.slug).sort(byOrder),
    }));
  return {
    settings: content.settings,
    home: content.home,
    properties,
    amenities: [...content.amenities].sort(byOrder),
    siteGallery: content.gallery.filter((image) => image.scope === "site").sort(byOrder),
    seo: content.seo,
    isPreview: useDraft,
  };
}

export async function getPropertyBySlug(slug: string, options: { preview?: boolean } = {}) {
  const site = await getSite(options);
  return { site, property: site.properties.find((property) => property.slug === slug) };
}

export function seoFor(site: SiteView, page: string, fallback: { title: string; description: string }) {
  const entry = site.seo.find((item) => item.page === page);
  return { title: entry?.title || fallback.title, description: entry?.description || fallback.description, ogImage: entry?.ogImage || "" };
}
