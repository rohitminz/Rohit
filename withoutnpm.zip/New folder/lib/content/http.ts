import "server-only";
import { NextRequest, NextResponse } from "next/server";
import { ConflictError, ContentConfigError } from "./store";

export function sameOrigin(request: NextRequest) {
  const origin = request.headers.get("origin");
  return !origin || origin === request.nextUrl.origin;
}

export function failure(error: unknown) {
  if (error instanceof ConflictError) return NextResponse.json({ error: error.message }, { status: 409 });
  if (error instanceof ContentConfigError) return NextResponse.json({ error: error.message }, { status: 503 });
  console.error("Content request failed", error instanceof Error ? error.message : error);
  const detail = process.env.NODE_ENV === "development" && error instanceof Error ? ` (${error.message})` : "";
  return NextResponse.json({ error: `Could not read or write the website content workbook.${detail}` }, { status: 503 });
}
