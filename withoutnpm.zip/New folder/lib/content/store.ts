import "server-only";
import fs from "node:fs/promises";
import path from "node:path";
import type ExcelJS from "exceljs";
import { buildDefaultContent } from "./defaults";
import type { SiteContent } from "./schema";
import { SHEETS, SHEET_NAMES, applyContent, applyDraft, createSeedWorkbook, readContent, readDraft, workbookFromBuffer, workbookToBuffer, type DraftRecord } from "./workbook";

/*
 * Content repository over a master Excel workbook.
 * Excel is used for editorial content only. Booking, inventory and payment records stay in Supabase/PostgreSQL:
 * the Bookings / Guests / Enquiries / Availability sheets are reporting copies, never the source of truth.
 */

export class ConflictError extends Error {}
export class ContentConfigError extends Error {}

type Loaded = { buffer: Buffer | null; etag: string | null };
interface WorkbookStore {
  name: "local" | "graph";
  load(): Promise<Loaded>;
  save(buffer: Buffer, etag: string | null): Promise<void>;
}

function localStore(): WorkbookStore {
  const file = path.resolve(process.cwd(), process.env.CONTENT_WORKBOOK_PATH || "data/haris_court_management.xlsx");
  const load = async (): Promise<Loaded> => {
    try {
      const [buffer, stat] = await Promise.all([fs.readFile(file), fs.stat(file)]);
      return { buffer, etag: `${stat.mtimeMs}-${stat.size}` };
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return { buffer: null, etag: null };
      throw error;
    }
  };
  return {
    name: "local",
    load,
    async save(buffer, etag) {
      const current = await load();
      if (current.etag !== etag) throw new ConflictError("The workbook was changed by someone else. Reload and try again.");
      await fs.mkdir(path.dirname(file), { recursive: true });
      const temp = `${file}.${process.pid}.tmp`;
      await fs.writeFile(temp, buffer);
      await fs.rename(temp, file);
    },
  };
}

let graphToken: { value: string; expires: number } | null = null;

function graphStore(): WorkbookStore {
  const { MS_TENANT_ID: tenant, MS_CLIENT_ID: clientId, MS_CLIENT_SECRET: secret, MS_GRAPH_DRIVE_ID: driveId, MS_GRAPH_ITEM_ID: itemId, MS_GRAPH_FILE_PATH: filePath } = process.env;
  if (!tenant || !clientId || !secret || !driveId || !(itemId || filePath)) {
    throw new ContentConfigError("Microsoft Graph storage needs MS_TENANT_ID, MS_CLIENT_ID, MS_CLIENT_SECRET, MS_GRAPH_DRIVE_ID and MS_GRAPH_ITEM_ID or MS_GRAPH_FILE_PATH.");
  }
  const itemBase = itemId
    ? `https://graph.microsoft.com/v1.0/drives/${encodeURIComponent(driveId)}/items/${encodeURIComponent(itemId)}`
    : `https://graph.microsoft.com/v1.0/drives/${encodeURIComponent(driveId)}/root:/${filePath!.split("/").map(encodeURIComponent).join("/")}:`;

  async function token() {
    if (graphToken && graphToken.expires > Date.now() + 60_000) return graphToken.value;
    const response = await fetch(`https://login.microsoftonline.com/${encodeURIComponent(tenant!)}/oauth2/v2.0/token`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ client_id: clientId!, client_secret: secret!, scope: "https://graph.microsoft.com/.default", grant_type: "client_credentials" }),
    });
    if (!response.ok) throw new ContentConfigError("Microsoft Graph sign-in failed. Check the app registration credentials.");
    const body = (await response.json()) as { access_token: string; expires_in: number };
    graphToken = { value: body.access_token, expires: Date.now() + body.expires_in * 1000 };
    return graphToken.value;
  }

  return {
    name: "graph",
    async load() {
      const headers = { Authorization: `Bearer ${await token()}` };
      const meta = await fetch(itemBase, { headers, cache: "no-store" });
      if (meta.status === 404) return { buffer: null, etag: null };
      if (!meta.ok) throw new Error(`Microsoft Graph returned ${meta.status} for the workbook.`);
      const { eTag } = (await meta.json()) as { eTag?: string };
      const content = await fetch(`${itemBase}/content`, { headers, cache: "no-store" });
      if (!content.ok) throw new Error(`Microsoft Graph returned ${content.status} for the workbook content.`);
      return { buffer: Buffer.from(await content.arrayBuffer()), etag: eTag ?? null };
    },
    async save(buffer, etag) {
      const headers: Record<string, string> = {
        Authorization: `Bearer ${await token()}`,
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      };
      if (etag) headers["If-Match"] = etag;
      const response = await fetch(`${itemBase}/content`, { method: "PUT", headers, body: new Uint8Array(buffer) });
      if (response.status === 412) throw new ConflictError("The workbook was changed by someone else. Reload and try again.");
      if (!response.ok) throw new Error(`Microsoft Graph returned ${response.status} while saving the workbook.`);
    },
  };
}

function store(): WorkbookStore {
  return process.env.CONTENT_STORE === "graph" ? graphStore() : localStore();
}

export type ContentState = { published: SiteContent; draft: DraftRecord | null; source: "workbook" | "defaults"; storage: "local" | "graph" };

let cache: { at: number; state: ContentState } | null = null;
const CACHE_MS = 4000;
let queue: Promise<unknown> = Promise.resolve();

function exclusive<T>(task: () => Promise<T>): Promise<T> {
  const run = queue.then(task, task);
  queue = run.catch(() => undefined);
  return run;
}

async function loadWorkbook(adapter: WorkbookStore): Promise<{ workbook: ExcelJS.Workbook; etag: string | null; seeded: boolean }> {
  const { buffer, etag } = await adapter.load();
  if (!buffer) return { workbook: createSeedWorkbook(), etag: null, seeded: true };
  return { workbook: await workbookFromBuffer(buffer), etag, seeded: false };
}

export async function readState(): Promise<ContentState> {
  if (cache && Date.now() - cache.at < CACHE_MS) return cache.state;
  const adapter = store();
  const { workbook, etag, seeded } = await loadWorkbook(adapter);
  if (seeded) {
    try {
      await adapter.save(await workbookToBuffer(workbook), etag);
    } catch (error) {
      console.warn("Could not create the master workbook; serving built-in defaults.", error instanceof Error ? error.message : error);
    }
  }
  const state: ContentState = { published: readContent(workbook), draft: readDraft(workbook), source: seeded ? "defaults" : "workbook", storage: adapter.name };
  cache = { at: Date.now(), state };
  return state;
}

async function mutate(change: (workbook: ExcelJS.Workbook) => void) {
  return exclusive(async () => {
    const adapter = store();
    const { workbook, etag } = await loadWorkbook(adapter);
    change(workbook);
    await adapter.save(await workbookToBuffer(workbook), etag);
    cache = null;
  });
}

export async function saveDraft(content: SiteContent, expectedVersion: number, savedBy: string) {
  await mutate((workbook) => {
    if (readContent(workbook).version !== expectedVersion) throw new ConflictError("Content was published by someone else. Reload before saving.");
    applyDraft(workbook, { content, savedAt: new Date().toISOString(), savedBy });
  });
}

export async function discardDraft() {
  await mutate((workbook) => applyDraft(workbook, null));
}

export async function publishDraft(expectedVersion: number) {
  await mutate((workbook) => {
    const published = readContent(workbook);
    const draft = readDraft(workbook);
    if (!draft) throw new ConflictError("There is no draft to publish.");
    if (published.version !== expectedVersion) throw new ConflictError("Content was published by someone else. Reload before publishing.");
    applyContent(workbook, { ...draft.content, version: published.version + 1, publishedAt: new Date().toISOString() });
    applyDraft(workbook, null);
  });
}

/** Replaces a reporting sheet (Bookings, Guests, Enquiries) with a fresh export from the live database. */
export async function replaceReportingSheet(key: "bookings" | "guests" | "enquiries", rows: Record<string, string | number>[]) {
  await mutate((workbook) => {
    const ws = workbook.getWorksheet(SHEET_NAMES[key]) ?? workbook.addWorksheet(SHEET_NAMES[key]);
    if (ws.rowCount > 0) ws.spliceRows(1, ws.rowCount);
    const headers = SHEETS[key];
    ws.addRow([...headers]).font = { bold: true };
    rows.forEach((row) => ws.addRow(headers.map((header) => row[header] ?? "")));
  });
}

/** Raw .xlsx bytes of the master workbook (seeded in memory if it does not exist yet), for admin download. */
export async function readWorkbookBuffer(): Promise<Buffer> {
  const { buffer } = await store().load();
  return buffer ?? workbookToBuffer(createSeedWorkbook());
}

export function defaultsState(): ContentState {
  return { published: buildDefaultContent(), draft: null, source: "defaults", storage: "local" };
}
