import "server-only";
import nodemailer from "nodemailer";
import { Resend } from "resend";

type ReservationEmail = {
  reference: string;
  guestName: string;
  guestEmail: string;
  propertyName: string;
  roomName: string;
  checkIn: string;
  checkOut: string;
  amount: number;
  specialRequests: string;
};

export async function sendReservationEmail(reservation: ReservationEmail, confirmed: boolean, notifyEmails: string[] = []): Promise<boolean> {
  const subject = confirmed ? `Stay confirmed · ${reservation.reference}` : `Reservation request · ${reservation.reference}`;
  const status = confirmed
    ? "Your payment has been verified and your stay is confirmed."
    : "We have received your reservation request. Your stay is not confirmed until payment is completed.";
  const html = `<div style="font-family:Arial,sans-serif;color:#20211f;line-height:1.6"><h1 style="font-weight:400">Hari's Court</h1><p>Dear ${escapeHtml(reservation.guestName)},</p><p>${status}</p><p><strong>${escapeHtml(reservation.roomName)}</strong><br>${escapeHtml(reservation.propertyName)}<br>${escapeHtml(reservation.checkIn)} to ${escapeHtml(reservation.checkOut)}<br>Reference: ${escapeHtml(reservation.reference)}<br>Room total: ₹${reservation.amount.toLocaleString("en-IN")}</p>${reservation.specialRequests ? `<p><strong>Special requests:</strong> ${escapeHtml(reservation.specialRequests)}</p>` : ""}<p>Our reservations team is available at reservations@hariscourt.in.</p></div>`;
  // Hotel copies: the property + dashboard-configured recipients, plus the optional env address.
  const recipients = [...new Set([...notifyEmails, process.env.HOTEL_RESERVATIONS_EMAIL ?? ""]
    .map((address) => address.trim().toLowerCase())
    .filter((address) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(address)))];

  // Preferred: send from a Gmail account using an App Password over Gmail SMTP.
  const gmailUser = process.env.GMAIL_USER;
  const gmailPass = (process.env.GMAIL_APP_PASSWORD ?? "").replace(/\s+/g, "");
  if (gmailUser && gmailPass) {
    const transport = nodemailer.createTransport({
      service: "gmail",
      auth: { user: gmailUser, pass: gmailPass },
      connectionTimeout: 8000,
      greetingTimeout: 6000,
      socketTimeout: 8000,
    });
    const from = `Hari's Court <${gmailUser}>`;
    const send = async () => {
      await transport.sendMail({ from, to: reservation.guestEmail, subject, html });
      for (const to of recipients) {
        await transport.sendMail({ from, to, subject: `${subject} · ${reservation.guestName}`, html });
      }
      return true;
    };
    // Hard cap so a blocked/unreachable SMTP never stalls booking creation beyond this.
    return withTimeout(send(), 9000);
  }

  // Fallback: Resend API if configured.
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.RESEND_FROM_EMAIL;
  if (!apiKey || !from) return false;
  const resend = new Resend(apiKey);
  const result = await resend.emails.send({ from, to: reservation.guestEmail, subject, html });
  if (result.error) throw new Error(result.error.message);
  for (const to of recipients) {
    const ops = await resend.emails.send({ from, to, subject: `${subject} · ${reservation.guestName}`, html });
    if (ops.error) throw new Error(ops.error.message);
  }
  return true;
}

function escapeHtml(value: string) {
  return value.replace(/[&<>"']/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]!);
}

// Resolves false if the send does not finish within `ms` (or errors), so a blocked SMTP can't stall callers.
function withTimeout(promise: Promise<boolean>, ms: number): Promise<boolean> {
  return new Promise((resolve) => {
    const timer = setTimeout(() => resolve(false), ms);
    promise.then((value) => { clearTimeout(timer); resolve(value); }).catch(() => { clearTimeout(timer); resolve(false); });
  });
}