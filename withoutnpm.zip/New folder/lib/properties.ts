import type { GalleryRecord, NearbyPlace, PropertyRecord, RoomRecord } from "./content/schema";

export type { NearbyPlace };
export type PropertyRoom = RoomRecord;
export type GalleryImage = GalleryRecord;

/** Active property with its active rooms and gallery, as served to the public site. */
export type Property = PropertyRecord & { rooms: RoomRecord[]; gallery: GalleryRecord[] };

export function directionsUrl(property: Pick<Property, "mapQuery">): string {
  return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(property.mapQuery)}`;
}

export function propertyTitle(property: Pick<Property, "name" | "location">): string {
  return `${property.name} ${property.location}`;
}

/** Availability search for a property using today/tomorrow-style default dates supplied by the caller. */
export function searchHref(property: Pick<Property, "slug">, checkIn: string, checkOut: string): string {
  return `/availability?${new URLSearchParams({ property: property.slug, checkIn, checkOut, rooms: "1", adults: "2", children: "0" })}`;
}
