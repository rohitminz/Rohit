import "server-only";
import { createHmac, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { getUserById, getUserByUsername, verifyPassword, type StoredUser } from "./users-store";
import { superPermissions, type Permissions, type Role } from "./permissions";
import { getAuthSecret } from "./secret";

export const SESSION_COOKIE = "hc_session";
const MAX_AGE_SECONDS = 60 * 60 * 12; // 12 hours

export type CurrentUser = {
  id: string;
  username: string;
  name: string;
  role: Role | "super";
  isSuper: boolean;
  permissions: Permissions;
  status: "active" | "disabled";
};

function sign(payloadB64: string): string {
  return createHmac("sha256", getAuthSecret()).update(payloadB64).digest("base64url");
}

function createToken(payload: Record<string, unknown>): string {
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  return `${body}.${sign(body)}`;
}

function readToken(token: string): Record<string, unknown> | null {
  const [body, signature] = token.split(".");
  if (!body || !signature) return null;
  const expected = sign(body);
  const a = Buffer.from(signature);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  try {
    return JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
  } catch {
    return null;
  }
}

function superUsername(): string {
  return (process.env.SUPERADMIN_USERNAME || "superadmin").trim();
}

function superUser(): CurrentUser {
  return { id: "super", username: superUsername(), name: "Super Admin", role: "super", isSuper: true, permissions: superPermissions(), status: "active" };
}

function toCurrent(user: StoredUser): CurrentUser {
  return { id: user.id, username: user.username, name: user.name, role: user.role, isSuper: false, permissions: user.permissions, status: user.status };
}

/** Validates a username/password against the super admin env credentials, then the officials store. */
export async function authenticate(username: string, password: string): Promise<CurrentUser | null> {
  const superPass = process.env.SUPERADMIN_PASSWORD || "";
  if (superPass && username.trim().toLowerCase() === superUsername().toLowerCase() && password === superPass) {
    return superUser();
  }
  const user = await getUserByUsername(username);
  if (!user || user.status !== "active") return null;
  if (!verifyPassword(password, user.passwordHash)) return null;
  return toCurrent(user);
}

export async function startSession(user: CurrentUser): Promise<void> {
  const token = createToken({ sub: user.id, super: user.isSuper, exp: Math.floor(Date.now() / 1000) + MAX_AGE_SECONDS });
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: MAX_AGE_SECONDS,
  });
}

export async function endSession(): Promise<void> {
  const store = await cookies();
  store.delete(SESSION_COOKIE);
}

/** Resolves the signed-in user from the session cookie, or null if absent/expired/disabled. */
export async function getCurrentUser(): Promise<CurrentUser | null> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const payload = readToken(token);
  if (!payload) return null;
  if (typeof payload.exp === "number" && payload.exp * 1000 < Date.now()) return null;
  if (payload.super === true) {
    if (!process.env.SUPERADMIN_PASSWORD) return null;
    return superUser();
  }
  const user = await getUserById(String(payload.sub));
  if (!user || user.status !== "active") return null;
  return toCurrent(user);
}
