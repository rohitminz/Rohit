// Shared access-control model for the admin dashboard. Sections mirror the dashboard nav tabs.

export const SECTIONS = [
  "Overview", "Reports", "Bookings", "Calendar", "Rooms", "Pricing", "Guests", "Payments", "Enquiries",
  "Website content", "Offers", "SEO", "Users", "Notifications", "Login history", "Audit log", "Settings",
] as const;

export type Section = (typeof SECTIONS)[number];
export type Access = "none" | "view" | "edit";
export type Permissions = Record<string, Access>;
export type Role = "manager" | "editor" | "viewer";

export const ROLES: Role[] = ["manager", "editor", "viewer"];

// Section access each preset grants; everything not listed defaults to "none".
const PRESET_GRANTS: Record<Role, Partial<Record<Section, Access>>> = {
  manager: {
    Overview: "edit", Reports: "view", Bookings: "edit", Calendar: "edit", Rooms: "edit",
    Pricing: "edit", Guests: "edit", Payments: "edit", Enquiries: "edit", Notifications: "view",
  },
  editor: {
    Overview: "view", Reports: "view", Bookings: "edit", "Website content": "edit", Offers: "edit", SEO: "edit",
    Rooms: "view", Pricing: "view",
  },
  viewer: {
    Overview: "view", Reports: "view", Bookings: "view", Calendar: "view", Rooms: "view",
    Payments: "view", Enquiries: "view",
  },
};

/** Full permissions object (every section present) for a role preset. */
export function presetFor(role: Role): Permissions {
  const grants = PRESET_GRANTS[role] ?? {};
  const result: Permissions = {};
  for (const section of SECTIONS) result[section] = grants[section] ?? "none";
  return result;
}

/** The super admin can view and edit everything. */
export function superPermissions(): Permissions {
  const result: Permissions = {};
  for (const section of SECTIONS) result[section] = "edit";
  return result;
}

/** Normalises arbitrary input into a valid permissions object (defaults missing sections to "none"). */
export function normalisePermissions(input: unknown): Permissions {
  const source = (input && typeof input === "object" ? input : {}) as Record<string, unknown>;
  const result: Permissions = {};
  for (const section of SECTIONS) {
    const value = source[section];
    result[section] = value === "view" || value === "edit" ? value : "none";
  }
  return result;
}

export function canView(permissions: Permissions, section: string): boolean {
  return permissions[section] === "view" || permissions[section] === "edit";
}

export function canEdit(permissions: Permissions, section: string): boolean {
  return permissions[section] === "edit";
}
