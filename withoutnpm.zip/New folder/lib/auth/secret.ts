import "server-only";
import fs from "node:fs";
import path from "node:path";
import { randomBytes } from "node:crypto";

// Shared HMAC/encryption secret: from AUTH_SECRET, else a generated value persisted locally.
export function getAuthSecret(): string {
  if (process.env.AUTH_SECRET && process.env.AUTH_SECRET.length >= 16) return process.env.AUTH_SECRET;
  const file = path.join(process.cwd(), "data", ".auth-secret");
  try {
    return fs.readFileSync(file, "utf8").trim();
  } catch {
    const secret = randomBytes(32).toString("hex");
    try {
      fs.mkdirSync(path.dirname(file), { recursive: true });
      fs.writeFileSync(file, secret, { flag: "wx" });
    } catch {
      /* best effort; falls back to the in-memory value for this process */
    }
    return secret;
  }
}
