import "server-only";
import fs from "node:fs/promises";
import path from "node:path";
import { createCipheriv, createDecipheriv, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { normalisePermissions, presetFor, type Permissions, type Role } from "./permissions";
import { getAuthSecret } from "./secret";

/**
 * Local store for dashboard officials created by the super admin. Records live in data/users.json so
 * they persist across restarts. Passwords are stored as a scrypt hash (for login) and, so officials can
 * view their own and the super admin can view any, a reversibly AES-encrypted copy (not clear text).
 * The super admin itself is NOT stored here — it is validated against environment variables.
 */
export type StoredUser = {
  id: string;
  username: string;
  name: string;
  passwordHash: string;
  passwordEnc?: string;
  role: Role;
  permissions: Permissions;
  status: "active" | "disabled";
  createdAt: string;
  lastActive?: string;
};

export type PublicUser = Omit<StoredUser, "passwordHash" | "passwordEnc">;

const FILE = path.join(process.cwd(), "data", "users.json");

function encKey() {
  return scryptSync(getAuthSecret(), "hc-password-enc", 32);
}

/** Reversibly encrypts a password so an authorised user can view it later (AES-256-GCM). */
export function encryptText(text: string): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", encKey(), iv);
  const encrypted = Buffer.concat([cipher.update(text, "utf8"), cipher.final()]);
  return `${iv.toString("hex")}:${cipher.getAuthTag().toString("hex")}:${encrypted.toString("hex")}`;
}

export function decryptText(payload: string | undefined): string {
  if (!payload) return "";
  try {
    const [ivHex, tagHex, dataHex] = payload.split(":");
    const decipher = createDecipheriv("aes-256-gcm", encKey(), Buffer.from(ivHex, "hex"));
    decipher.setAuthTag(Buffer.from(tagHex, "hex"));
    return Buffer.concat([decipher.update(Buffer.from(dataHex, "hex")), decipher.final()]).toString("utf8");
  } catch {
    return "";
  }
}

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = (stored || "").split(":");
  if (!salt || !hash) return false;
  const expected = Buffer.from(hash, "hex");
  const actual = scryptSync(password, salt, 64);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

export function toPublic(user: StoredUser): PublicUser {
  const { passwordHash: _passwordHash, passwordEnc: _passwordEnc, ...rest } = user;
  return rest;
}

/** Returns the stored (decrypted) password for a user, or "" if not recoverable. */
export async function getUserPassword(id: string): Promise<string> {
  const user = await getUserById(id);
  return user ? decryptText(user.passwordEnc) : "";
}

export async function listUsers(): Promise<StoredUser[]> {
  try {
    const raw = await fs.readFile(FILE, "utf8");
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as StoredUser[]) : [];
  } catch {
    return [];
  }
}

async function writeUsers(users: StoredUser[]): Promise<boolean> {
  try {
    await fs.mkdir(path.dirname(FILE), { recursive: true });
    // Atomic write: a concurrent reader never sees a half-written file.
    const temp = `${FILE}.${randomBytes(4).toString("hex")}.tmp`;
    await fs.writeFile(temp, JSON.stringify(users, null, 2), "utf8");
    await fs.rename(temp, FILE);
    return true;
  } catch (error) {
    console.error("Could not persist users", error instanceof Error ? error.message : error);
    return false;
  }
}

export async function getUserById(id: string): Promise<StoredUser | null> {
  return (await listUsers()).find((user) => user.id === id) ?? null;
}

export async function getUserByUsername(username: string): Promise<StoredUser | null> {
  const key = username.trim().toLowerCase();
  return (await listUsers()).find((user) => user.username.toLowerCase() === key) ?? null;
}

export async function createUser(input: { username: string; name: string; password: string; role: Role; permissions?: Permissions }): Promise<{ ok: true; user: PublicUser } | { ok: false; error: string }> {
  const username = input.username.trim();
  if (!/^[a-zA-Z0-9._-]{3,40}$/.test(username)) return { ok: false, error: "Username must be 3-40 letters, numbers, dot, dash or underscore." };
  if (input.password.length < 6) return { ok: false, error: "Password must be at least 6 characters." };
  if (await getUserByUsername(username)) return { ok: false, error: "That username is already taken." };
  const user: StoredUser = {
    id: `usr-${Date.now().toString(36)}-${randomBytes(2).toString("hex")}`,
    username,
    name: input.name.trim() || username,
    passwordHash: hashPassword(input.password),
    passwordEnc: encryptText(input.password),
    role: input.role,
    permissions: input.permissions ? normalisePermissions(input.permissions) : presetFor(input.role),
    status: "active",
    createdAt: new Date().toISOString(),
  };
  const users = await listUsers();
  users.unshift(user);
  if (!(await writeUsers(users))) return { ok: false, error: "Could not save the user on this server." };
  return { ok: true, user: toPublic(user) };
}

export async function updateUser(id: string, changes: { name?: string; role?: Role; permissions?: Permissions; status?: "active" | "disabled"; password?: string }): Promise<{ ok: true; user: PublicUser } | { ok: false; error: string }> {
  const users = await listUsers();
  const index = users.findIndex((user) => user.id === id);
  if (index === -1) return { ok: false, error: "User not found." };
  const next = { ...users[index] };
  if (changes.name !== undefined) next.name = changes.name.trim() || next.username;
  if (changes.role !== undefined) next.role = changes.role;
  if (changes.permissions !== undefined) next.permissions = normalisePermissions(changes.permissions);
  if (changes.status !== undefined) next.status = changes.status;
  if (changes.password) {
    if (changes.password.length < 6) return { ok: false, error: "Password must be at least 6 characters." };
    next.passwordHash = hashPassword(changes.password);
    next.passwordEnc = encryptText(changes.password);
  }
  users[index] = next;
  if (!(await writeUsers(users))) return { ok: false, error: "Could not save the change on this server." };
  return { ok: true, user: toPublic(next) };
}

export async function deleteUser(id: string): Promise<boolean> {
  const users = await listUsers();
  const next = users.filter((user) => user.id !== id);
  if (next.length === users.length) return false;
  return writeUsers(next);
}

export async function markActive(id: string): Promise<void> {
  const users = await listUsers();
  const index = users.findIndex((user) => user.id === id);
  if (index === -1) return;
  users[index] = { ...users[index], lastActive: new Date().toISOString() };
  await writeUsers(users);
}
