/*
 * Testing data-access layer for the admin dashboard.
 *
 * Holds the working copy of the sample operations dataset and persists edits to localStorage so
 * changes survive a page refresh during testing. This is the ONLY place that reads/writes the test
 * store, so it can be swapped for real backend API calls later without touching the pages:
 * replace load/persist/applyChange with fetch calls and keep the same shapes.
 */

import { buildTestingData, type AdminData } from "./dummy-data";

const STORAGE_KEY = "hc-admin-testing-data";

export function loadTestingData(today: string): AdminData {
  const fresh = buildTestingData(today);
  if (typeof window !== "undefined") {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<AdminData>;
        // Backfill any keys added after this copy was stored, so older caches don't crash the UI.
        return {
          rooms: Array.isArray(parsed.rooms) ? parsed.rooms : fresh.rooms,
          reservations: Array.isArray(parsed.reservations) ? parsed.reservations : fresh.reservations,
          payments: Array.isArray(parsed.payments) ? parsed.payments : fresh.payments,
          enquiries: Array.isArray(parsed.enquiries) ? parsed.enquiries : fresh.enquiries,
          guests: Array.isArray(parsed.guests) ? parsed.guests : fresh.guests,
        };
      }
    } catch {
      /* ignore corrupt cache and re-seed */
    }
  }
  return fresh;
}

export function persistTestingData(data: AdminData) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    /* storage may be unavailable; edits still live in React state for the session */
  }
}

export function resetTestingData(today: string): AdminData {
  if (typeof window !== "undefined") {
    try {
      window.localStorage.removeItem(STORAGE_KEY);
    } catch {
      /* ignore */
    }
  }
  return buildTestingData(today);
}

function sanitizeRoom(changes: Record<string, unknown>) {
  const next: Record<string, unknown> = { ...changes };
  if ("rate_inr" in next) next.rate_inr = Math.max(0, Math.round(Number(next.rate_inr) || 0));
  if ("inventory" in next) next.inventory = Math.max(0, Math.round(Number(next.inventory) || 0));
  return next;
}

/**
 * Applies a single-record change to the dataset and returns a new object (immutable update).
 * Entities mirror the admin API's PATCH surface, plus frontend-only create/delete used in testing.
 */
export function applyChange(data: AdminData, entity: string, id: string, changes: Record<string, unknown>): AdminData {
  switch (entity) {
    case "room":
      return { ...data, rooms: data.rooms.map(room => (room.id === id ? { ...room, ...sanitizeRoom(changes) } : room)) };
    case "room:add":
      return { ...data, rooms: [changes as unknown as AdminData["rooms"][number], ...data.rooms] };
    case "room:delete":
      return { ...data, rooms: data.rooms.filter(room => room.id !== id) };
    case "reservation":
      return { ...data, reservations: data.reservations.map(row => (row.reference === id ? { ...row, ...changes } : row)) };
    case "reservation:add":
      return { ...data, reservations: [changes as unknown as AdminData["reservations"][number], ...data.reservations] };
    case "enquiry":
      return { ...data, enquiries: data.enquiries.map(row => (row.id === id ? { ...row, ...changes } : row)) };
    case "enquiry:delete":
      return { ...data, enquiries: data.enquiries.filter(row => row.id !== id) };
    case "guest":
      return { ...data, guests: data.guests.map(row => (row.id === id ? { ...row, ...changes } : row)) };
    case "guest:add":
      return { ...data, guests: [changes as unknown as AdminData["guests"][number], ...data.guests] };
    case "guest:delete":
      return { ...data, guests: data.guests.filter(row => row.id !== id) };
    default:
      return data;
  }
}

/** True when a room id is still referenced by any non-cancelled reservation (blocks deletion). */
export function roomHasBookings(data: AdminData, roomName: string, propertyName: string): boolean {
  return data.reservations.some(row => row.status !== "cancelled" && row.room_types?.name === roomName && row.room_types?.property_name === propertyName);
}
