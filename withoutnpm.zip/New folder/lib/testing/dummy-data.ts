/*
 * Centralized, isolated TEST dataset for the Hari's Court admin dashboard.
 *
 * This is NOT production data. It exists so the dashboard and related screens can be built and
 * validated before the live backend (Supabase) is connected.
 *
 * Going live / resetting to a clean production state:
 *  - The dashboard only uses this data in testing mode (the `preview` flag). In live mode it reads
 *    `/api/admin` and renders real records, falling back to empty states when there are none.
 *  - To remove all sample records, stop passing `preview`, or set TESTING_DATA_ENABLED = false below
 *    (the dashboard then renders `emptyAdminData()` and its empty states). No sample values live
 *    anywhere else in the code — this module is the single source.
 */

export const TESTING_DATA_ENABLED = true;
export const TESTING_DATASET_LABEL = "Hari's Court sample operations dataset";

export type AdminData = {
  rooms: { id: string; property_name: string; name: string; rate_inr: number; inventory: number; active: boolean }[];
  reservations: {
    reference: string; guest_name: string; guest_email: string; guest_phone?: string | null; guests?: number | null;
    special_requests: string; check_in: string; check_out: string; total_amount_inr: number; amount_paid?: number | null; status: string; created_at: string;
    charges?: { id: string; label: string; amount: number; at: string; image?: string }[];
    payments?: { id: string; amount: number; note: string; at: string }[];
    room_types: { name: string; property_name: string } | null;
  }[];
  payments: { id: string; reservation_reference: string; amount_inr: number; currency: string; status: string; paid_at: string | null; created_at: string }[];
  enquiries: { id: string; name: string; email: string; phone: string; kind: string; message: string; status: string; created_at: string; property?: string; assigned?: string; notes?: string }[];
  guests: { id: string; name: string; email: string; phone: string; city: string }[];
};
export type GuestRecord = AdminData["guests"][number];

export type Offer = {
  id: string; title: string; description: string; code: string; discountLabel: string;
  scope: "all" | string; active: boolean; validTill: string;
};

export type StaffRole = "admin" | "manager" | "editor" | "viewer";
export type StaffUser = {
  id: string; name: string; email: string; role: StaffRole; status: "active" | "disabled";
  property: "all" | string; lastActive: string;
};

export const TESTING_USERS: StaffUser[] = [
  { id: "usr-1", name: "Rohan Hari", email: "rohan@hariscourt.in", role: "admin", status: "active", property: "all", lastActive: "2026-11-01" },
  { id: "usr-2", name: "Ananya Desai", email: "ananya.desai@hariscourt.in", role: "manager", status: "active", property: "cyber-city", lastActive: "2026-11-01" },
  { id: "usr-3", name: "Vikram Suri", email: "vikram.suri@hariscourt.in", role: "manager", status: "active", property: "lajpat-nagar", lastActive: "2026-10-31" },
  { id: "usr-4", name: "Pooja Nanda", email: "pooja.nanda@hariscourt.in", role: "editor", status: "active", property: "all", lastActive: "2026-10-30" },
  { id: "usr-5", name: "Sameer Qureshi", email: "sameer.q@hariscourt.in", role: "viewer", status: "active", property: "mg-road", lastActive: "2026-10-28" },
  { id: "usr-6", name: "Deepa Raman", email: "deepa.raman@hariscourt.in", role: "editor", status: "disabled", property: "cyber-hub", lastActive: "2026-09-19" },
];

const PROPERTIES = [
  { slug: "cyber-city", location: "Cyber City, Gurugram", rates: [4800, 6600, 9400] },
  { slug: "cyber-hub", location: "Cyber Hub, Gurugram", rates: [4600, 6400, 9100] },
  { slug: "mg-road", location: "MG Road, Gurugram", rates: [4500, 6200, 8900] },
  { slug: "lajpat-nagar", location: "Lajpat Nagar, Delhi", rates: [4200, 5800, 8200] },
] as const;

export type SeoEntry = { id: string; page: string; path: string; title: string; description: string };
export const TESTING_SEO: SeoEntry[] = [
  { id: "seo-home", page: "Homepage", path: "/", title: "Hari's Court Hotels & Banquets | Premium Stays in Gurugram & Delhi", description: "Book premium rooms and banquet venues at Hari's Court across Cyber City, Cyber Hub, MG Road and Lajpat Nagar." },
  { id: "seo-rooms", page: "Rooms & Search", path: "/availability", title: "Rooms & Suites | Hari's Court Hotels", description: "Explore Superior Rooms, Deluxe Rooms and Executive Suites with modern amenities across four Hari's Court properties." },
  { id: "seo-cyber-city", page: "Cyber City", path: "/locations/cyber-city", title: "Hari's Court Cyber City, Gurugram | Business Hotel near DLF", description: "A calm, well-connected stay beside DLF Cyber City, Gurugram. Book Superior, Deluxe and Executive rooms." },
  { id: "seo-cyber-hub", page: "Cyber Hub", path: "/locations/cyber-hub", title: "Hari's Court Cyber Hub, Gurugram | Contemporary Inn", description: "A compact, contemporary inn steps from Cyber Hub's restaurants and offices in Gurugram." },
  { id: "seo-mg-road", page: "MG Road", path: "/locations/mg-road", title: "Hari's Court MG Road, Gurugram | Refined City Hotel", description: "A refined stay on MG Road, Gurugram, close to the city's business and lifestyle destinations." },
  { id: "seo-lajpat-nagar", page: "Lajpat Nagar", path: "/locations/lajpat-nagar", title: "Hari's Court Lajpat Nagar, Delhi | South Delhi Hotel", description: "A leafy South Delhi address beside Central Market, with cafes, boutiques and the metro on foot." },
  { id: "seo-banquets", page: "Banquets", path: "/#banquets", title: "Banquets & Events | Hari's Court Hotels", description: "Welcoming banquet halls and event spaces for weddings, corporate offsites and private functions." },
];

export type NotificationKind = "booking" | "payment" | "enquiry" | "system";
export type NotificationItem = { id: string; kind: NotificationKind; title: string; detail: string; createdAt: string; read: boolean };
export const TESTING_NOTIFICATIONS: NotificationItem[] = [
  { id: "ntf-1", kind: "booking", title: "New booking received", detail: "Arjun Kapoor · Deluxe Room · Cyber City, Gurugram", createdAt: "2026-11-01T11:20:00+05:30", read: false },
  { id: "ntf-2", kind: "payment", title: "Payment received", detail: "₹12,600 · HC24M3B18 · Lajpat Nagar", createdAt: "2026-11-01T10:05:00+05:30", read: false },
  { id: "ntf-3", kind: "enquiry", title: "New banquet enquiry", detail: "Simran Kaur · engagement function · Lajpat Nagar", createdAt: "2026-11-01T09:40:00+05:30", read: false },
  { id: "ntf-4", kind: "system", title: "Room marked out of service", detail: "Cyber Hub · Executive Suite · under renovation", createdAt: "2026-10-31T17:15:00+05:30", read: true },
  { id: "ntf-5", kind: "booking", title: "Booking cancelled", detail: "Rohan Gupta · Superior Room · MG Road", createdAt: "2026-10-31T13:02:00+05:30", read: true },
  { id: "ntf-6", kind: "payment", title: "Refund processed", detail: "₹9,000 · HC24H8C63 · MG Road", createdAt: "2026-10-30T18:30:00+05:30", read: true },
];

export type LoginEvent = { id: string; user: string; email: string; at: string; ip: string; device: string; location: string; status: "success" | "failed" };
export const TESTING_LOGIN_HISTORY: LoginEvent[] = [
  { id: "log-1", user: "Rohan Hari", email: "rohan@hariscourt.in", at: "2026-11-01T09:02:00+05:30", ip: "103.21.58.14", device: "Chrome · Windows", location: "Gurugram, IN", status: "success" },
  { id: "log-2", user: "Ananya Desai", email: "ananya.desai@hariscourt.in", at: "2026-11-01T08:47:00+05:30", ip: "49.36.142.88", device: "Safari · macOS", location: "Gurugram, IN", status: "success" },
  { id: "log-3", user: "Unknown", email: "admin@hariscourt.in", at: "2026-10-31T23:14:00+05:30", ip: "185.220.101.5", device: "Firefox · Linux", location: "Amsterdam, NL", status: "failed" },
  { id: "log-4", user: "Vikram Suri", email: "vikram.suri@hariscourt.in", at: "2026-10-31T19:22:00+05:30", ip: "157.49.20.31", device: "Chrome · Android", location: "New Delhi, IN", status: "success" },
  { id: "log-5", user: "Pooja Nanda", email: "pooja.nanda@hariscourt.in", at: "2026-10-31T11:10:00+05:30", ip: "103.21.58.77", device: "Edge · Windows", location: "Gurugram, IN", status: "success" },
  { id: "log-6", user: "Unknown", email: "rohan@hariscourt.in", at: "2026-10-30T02:41:00+05:30", ip: "45.133.1.90", device: "Chrome · Windows", location: "Kyiv, UA", status: "failed" },
  { id: "log-7", user: "Sameer Qureshi", email: "sameer.q@hariscourt.in", at: "2026-10-29T16:05:00+05:30", ip: "157.49.88.204", device: "Safari · iOS", location: "Gurugram, IN", status: "success" },
];

export type AuditEvent = { id: string; at: string; user: string; action: string; target: string; detail: string };
export const TESTING_AUDIT_LOG: AuditEvent[] = [
  { id: "aud-1", at: "2026-11-01T11:22:00+05:30", user: "Ananya Desai", action: "Updated price", target: "Cyber City · Superior Room", detail: "₹4,800 → ₹5,250" },
  { id: "aud-2", at: "2026-11-01T11:24:00+05:30", user: "Ananya Desai", action: "Published content", target: "Website content", detail: "Version 4 → 5" },
  { id: "aud-3", at: "2026-11-01T10:08:00+05:30", user: "Rohan Hari", action: "Confirmed booking", target: "HC24M3B18", detail: "Status pending → confirmed" },
  { id: "aud-4", at: "2026-10-31T17:16:00+05:30", user: "Rohan Hari", action: "Deactivated room", target: "Cyber Hub · Executive Suite", detail: "Marked out of service" },
  { id: "aud-5", at: "2026-10-31T13:05:00+05:30", user: "Vikram Suri", action: "Cancelled booking", target: "HC24H8C63", detail: "Guest request" },
  { id: "aud-6", at: "2026-10-30T18:31:00+05:30", user: "Rohan Hari", action: "Processed refund", target: "HC24H8C63", detail: "₹9,000 to original method" },
  { id: "aud-7", at: "2026-10-30T09:12:00+05:30", user: "Pooja Nanda", action: "Created offer", target: "Monsoon Escape", detail: "15% off · all properties" },
  { id: "aud-8", at: "2026-10-29T15:40:00+05:30", user: "Rohan Hari", action: "Added team member", target: "Sameer Qureshi", detail: "Role: viewer · MG Road" },
];

const ROOM_TYPES = ["Superior Room", "Deluxe Room", "Executive Suite"] as const;
const INVENTORY = [14, 8, 4];

function addDays(date: string, amount: number) {
  const value = new Date(`${date}T00:00:00Z`);
  value.setUTCDate(value.getUTCDate() + amount);
  return value.toISOString().slice(0, 10);
}

function emailFor(name: string) {
  return `${name.toLowerCase().replace(/[^a-z]+/g, ".")}@example.com`;
}

/** [ref, guest, phone, propertyIdx, roomIdx, status, checkInOffset, nights, guests, createdOffset, createdHour, requests?] */
type ResSeed = [string, string, string, number, number, string, number, number, number, number, number, string?];

const RESERVATION_SEEDS: ResSeed[] = [
  ["HC24A1F92", "Riya Mehta", "+91 98110 23145", 0, 0, "checked_in", -1, 3, 2, -2, 9],
  ["HC24B2C07", "Arjun Kapoor", "+91 98201 55820", 0, 1, "confirmed", 0, 2, 2, -2, 11],
  ["HC24C3D18", "Neha Shah", "+91 99710 41288", 1, 0, "pending_payment", 0, 1, 1, 0, 8, "Late check-in, high floor preferred."],
  ["HC24D4E29", "Kabir Rao", "+91 90011 77640", 2, 2, "confirmed", 1, 2, 3, -1, 14],
  ["HC24E5F30", "Mira Sen", "+91 98735 90011", 3, 1, "checked_in", -2, 2, 2, -3, 10],
  ["HC24F6A41", "Aditya Nair", "+91 97400 31226", 0, 2, "checked_out", -5, 3, 4, -6, 12],
  ["HC24G7B52", "Ananya Iyer", "+91 99620 18473", 1, 1, "confirmed", 2, 4, 2, -1, 15],
  ["HC24H8C63", "Rohan Gupta", "+91 98330 60914", 2, 0, "cancelled", 3, 2, 2, -2, 16],
  ["HC24I9D74", "Sana Khan", "+91 99100 25587", 3, 2, "confirmed", 0, 5, 3, -1, 13],
  ["HC24J0E85", "Vikram Reddy", "+91 90080 44192", 0, 0, "pending_payment", 1, 2, 2, 0, 10],
  ["HC24K1F96", "Priya Sharma", "+91 98914 33028", 2, 1, "checked_in", -1, 2, 2, -2, 9],
  ["HC24L2A07", "Karan Malhotra", "+91 97180 71265", 1, 2, "checked_out", -7, 2, 2, -8, 11],
  ["HC24M3B18", "Ishaan Verma", "+91 99539 80412", 3, 0, "confirmed", 4, 3, 2, 0, 17],
  ["HC24N4C29", "Diya Joshi", "+91 98680 20947", 0, 1, "checked_in", -1, 4, 3, -2, 8],
  ["HC24O5D30", "Aarav Malhotra", "+91 99991 50833", 2, 0, "pending_payment", 2, 1, 1, -1, 12],
  ["HC24P6E41", "Tara Pillai", "+91 97620 34471", 3, 1, "checked_out", -4, 2, 2, -5, 10],
];

export const ENQUIRY_STATUSES = ["new", "contacted", "in_progress", "converted", "closed", "cancelled"] as const;
export const STAFF_NAMES = ["Rohan Hari", "Ananya Desai", "Vikram Suri", "Pooja Nanda"] as const;

type EnquirySeed = [string, string, string, string, string, string, number, number, string, string, string];
const ENQUIRY_SEEDS: EnquirySeed[] = [
  ["enq-1", "Kavya Menon", "+91 98100 77231", "banquet", "Looking for a banquet hall for a 150-guest wedding reception in December. Please share packages.", "in_progress", -1, 16, "lajpat-nagar", "Vikram Suri", "Shared December availability; awaiting menu preferences."],
  ["enq-2", "Dev Sharma", "+91 99710 20384", "room", "Do you offer long-stay corporate rates for a 3-week assignment near Cyber City?", "converted", -3, 11, "cyber-city", "Ananya Desai", "Booked 21 nights at corporate rate."],
  ["enq-3", "Nisha Rao", "+91 90044 61288", "general", "What are the check-in and check-out timings, and is airport pickup available?", "new", -1, 9, "all", "", ""],
  ["enq-4", "Rahul Jain", "+91 98335 41190", "event", "Interested in a corporate offsite for 40 people with conference facilities at MG Road.", "closed", -4, 14, "mg-road", "Pooja Nanda", "Client postponed to next quarter."],
  ["enq-5", "Simran Kaur", "+91 99150 73026", "banquet", "Please share availability and menu options for an engagement function in Lajpat Nagar.", "contacted", 0, 10, "lajpat-nagar", "Vikram Suri", ""],
];

export const TESTING_OFFERS: Offer[] = [
  { id: "offer-monsoon", title: "Monsoon Escape", description: "15% off stays of 2 nights or more across all properties.", code: "MONSOON15", discountLabel: "15% off", scope: "all", active: true, validTill: "2026-12-31" },
  { id: "offer-corporate", title: "Corporate Long Stay", description: "20% off weekly bookings at our Gurugram properties.", code: "CORP20", discountLabel: "20% off", scope: "cyber-city", active: true, validTill: "2027-03-31" },
  { id: "offer-banquet", title: "Festive Banquet Package", description: "Complimentary décor upgrade on banquet bookings in Delhi.", code: "BANQUET", discountLabel: "Free upgrade", scope: "lajpat-nagar", active: true, validTill: "2027-01-15" },
  { id: "offer-earlybird", title: "Early Bird", description: "10% off when you book 30 days in advance.", code: "EARLY10", discountLabel: "10% off", scope: "all", active: false, validTill: "2027-06-30" },
];

export function buildTestingData(today: string): AdminData {
  const rooms: AdminData["rooms"] = PROPERTIES.flatMap(property =>
    ROOM_TYPES.map((name, index) => ({
      id: `${property.slug}-${name.toLowerCase().split(" ")[0]}`,
      property_name: property.location,
      name,
      rate_inr: property.rates[index],
      inventory: INVENTORY[index],
      // One suite under renovation to exercise out-of-service / occupancy math.
      active: !(property.slug === "cyber-hub" && name === "Executive Suite"),
    })),
  );

  const reservations: AdminData["reservations"] = RESERVATION_SEEDS.map(seed => {
    const [reference, guest, phone, propIdx, roomIdx, status, inOffset, nights, guests, createdOffset, createdHour, requests] = seed;
    const property = PROPERTIES[propIdx];
    const rate = property.rates[roomIdx];
    return {
      reference,
      guest_name: guest,
      guest_email: emailFor(guest),
      guest_phone: phone,
      guests,
      special_requests: requests ?? "",
      check_in: addDays(today, inOffset),
      check_out: addDays(today, inOffset + nights),
      total_amount_inr: rate * nights,
      status,
      created_at: `${addDays(today, createdOffset)}T${String(createdHour).padStart(2, "0")}:20:00.000Z`,
      room_types: { name: ROOM_TYPES[roomIdx], property_name: property.location },
    };
  });

  const payments: AdminData["payments"] = reservations.flatMap((reservation, index): AdminData["payments"] => {
    const base = { id: `pay-${index + 1}`, reservation_reference: reservation.reference, amount_inr: reservation.total_amount_inr, currency: "INR", created_at: reservation.created_at };
    if (["confirmed", "checked_in", "checked_out"].includes(reservation.status)) {
      return [{ ...base, status: "paid", paid_at: reservation.created_at }];
    }
    if (reservation.status === "pending_payment") {
      return [{ ...base, status: "created", paid_at: null }];
    }
    if (reservation.status === "cancelled") {
      return [{ ...base, status: "refunded", paid_at: reservation.created_at }];
    }
    return [];
  });

  const enquiries: AdminData["enquiries"] = ENQUIRY_SEEDS.map(seed => {
    const [id, name, phone, kind, message, status, createdOffset, createdHour, property, assigned, notes] = seed;
    return { id, name, email: emailFor(name), phone, kind, message, status, created_at: `${addDays(today, createdOffset)}T${String(createdHour).padStart(2, "0")}:05:00.000Z`, property, assigned, notes };
  });

  // Guest records are derived from reservations (unique by email) so booking history stays consistent,
  // plus two prospects with no bookings yet to exercise empty history.
  const cities = ["Gurugram", "New Delhi", "Mumbai", "Bengaluru", "Pune", "Jaipur", "Chandigarh", "Hyderabad"];
  const guestMap = new Map<string, AdminData["guests"][number]>();
  reservations.forEach(row => {
    if (guestMap.has(row.guest_email)) return;
    guestMap.set(row.guest_email, { id: `gst-${guestMap.size + 1}`, name: row.guest_name, email: row.guest_email, phone: row.guest_phone ?? "", city: cities[guestMap.size % cities.length] });
  });
  const guests: AdminData["guests"] = [
    ...guestMap.values(),
    { id: "gst-prospect-1", name: "Meera Krishnan", email: "meera.krishnan@example.com", phone: "+91 98400 55120", city: "Chennai" },
    { id: "gst-prospect-2", name: "Harsh Vardhan", email: "harsh.vardhan@example.com", phone: "+91 97111 30298", city: "Lucknow" },
  ];

  return { rooms, reservations, payments, enquiries, guests };
}

export function emptyAdminData(): AdminData {
  return { rooms: [], reservations: [], payments: [], enquiries: [], guests: [] };
}
