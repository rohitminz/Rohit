export type RoomContent = {
  tagline: string;
  description: string;
  size: string;
  bed: string;
  maxGuests: number;
  images: string[];
};

export const propertyMeta: Record<string, { name: string; address: string }> = {
  gurugram: { name: "Hari's Court Cyber City", address: "DLF Cyber City, Gurugram" },
  delhi: { name: "Hari's Court Lajpat Nagar", address: "71, Ring Road, Lajpat Nagar, New Delhi" },
};

const pool = [
  "/images/haris/room-deluxe.jpg",
  "/images/haris/room-alt-1.jpg",
  "/images/haris/room-executive.jpg",
  "/images/haris/room-alt-2.jpg",
  "/images/haris/room-presidential.jpg",
  "/images/haris/room-alt-3.jpg",
];

const rotate = (start: number) => pool.map((_, i) => pool[(start + i) % pool.length]);

const content: Record<string, RoomContent> = {
  deluxe: {
    tagline: "Comfortable Stay with Modern Amenities",
    description:
      "Our Deluxe Room offers a comfortable and elegant space with modern amenities, designed for business and leisure travellers. Enjoy a relaxing stay with thoughtful facilities and a welcoming atmosphere.",
    size: "280 sq.ft (approx)",
    bed: "1 King Bed",
    maxGuests: 2,
    images: rotate(0),
  },
  executive: {
    tagline: "Spacious Suite with Premium Amenities",
    description:
      "A spacious suite with premium amenities and a city view — ideal for longer stays, families and guests who appreciate extra room to work and unwind.",
    size: "320 sq.ft (approx)",
    bed: "1 King Bed",
    maxGuests: 2,
    images: rotate(2),
  },
  presidential: {
    tagline: "Unmatched Luxury with a Private Lounge",
    description:
      "Our finest suite. Experience unmatched luxury with a private lounge, premium furnishings and panoramic views — a memorable setting for a special occasion or an indulgent stay.",
    size: "420 sq.ft (approx)",
    bed: "1 King Bed + Private Lounge",
    maxGuests: 3,
    images: rotate(4),
  },
};

export function getRoomContent(id: string, name: string): RoomContent {
  const key = id.replace(/^demo-/, "");
  if (content[key]) return content[key];
  const lower = name.toLowerCase();
  if (lower.includes("presidential")) return content.presidential;
  if (lower.includes("executive")) return content.executive;
  return content.deluxe;
}

export const roomAmenities = [
  "Free Wi-Fi",
  "Air Conditioning",
  "Flat-Screen TV",
  "Room Service",
  "Hot & Cold Water",
  "Wardrobe",
  "Work Desk",
  "In-Room Safety Locker",
  "Laundry Service",
  "Daily Housekeeping",
];

export const roomFeatures = [
  "City View (subject to availability)",
  "Non-Smoking Room",
  "En-suite Bathroom",
  "Complimentary Toiletries",
];

export const roomPolicies = [
  { label: "Cancellation", text: "Free cancellation up to 24 hours before check-in" },
  { label: "Payment", text: "Pay at hotel or online (as per selected plan)" },
  { label: "Check-in", text: "2:00 PM" },
  { label: "Check-out", text: "12:00 PM" },
];

export const TAX_RATE = 0.18;

export function stayNights(checkIn: string, checkOut: string) {
  const nights = Math.round((new Date(`${checkOut}T00:00:00Z`).getTime() - new Date(`${checkIn}T00:00:00Z`).getTime()) / 86400000);
  return Number.isFinite(nights) && nights > 0 ? nights : 1;
}

export function formatStayDate(iso: string) {
  const date = new Date(`${iso}T00:00:00`);
  if (Number.isNaN(date.getTime())) return iso;
  return date.toLocaleDateString("en-IN", { weekday: "short", day: "2-digit", month: "short", year: "numeric" });
}

export function inr(amount: number) {
  return `₹${Math.round(amount).toLocaleString("en-IN")}`;
}
