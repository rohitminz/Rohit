import "server-only";
import { getSupabaseServerClient } from "@/lib/supabase/server";
import { getCurrentUser, type CurrentUser } from "@/lib/auth/session";

export async function isHotelAdmin() {
  const supabase = await getSupabaseServerClient();
  if (!supabase) return false;
  const { data: { user } } = await supabase.auth.getUser();
  return user?.app_metadata?.role === "admin";
}

/** Admin check for the content APIs. The bypass works only in `next dev` with CONTENT_ADMIN_DEV_BYPASS=true. */
export async function requireAdmin(): Promise<{ ok: boolean; user: string }> {
  if (process.env.NODE_ENV === "development" && process.env.CONTENT_ADMIN_DEV_BYPASS === "true") return { ok: true, user: "dev-admin" };
  const current = await getCurrentUser();
  if (current) return { ok: true, user: current.username };
  const supabase = await getSupabaseServerClient();
  if (!supabase) return { ok: false, user: "" };
  const { data: { user } } = await supabase.auth.getUser();
  return { ok: user?.app_metadata?.role === "admin", user: user?.email ?? user?.id ?? "admin" };
}

/** Requires the signed-in user to be the super admin. The dev bypass also counts, for local work. */
export async function requireSuper(): Promise<{ ok: boolean; user: CurrentUser | null }> {
  if (process.env.NODE_ENV === "development" && process.env.CONTENT_ADMIN_DEV_BYPASS === "true") {
    const current = await getCurrentUser();
    return { ok: true, user: current };
  }
  const current = await getCurrentUser();
  return { ok: Boolean(current?.isSuper), user: current };
}