# Hari's Court hotel website

Responsive Next.js App Router site for Hari's Court, with public room search, Supabase-backed reservation holds, Razorpay payment links, Resend email hooks and a Supabase-authenticated operations dashboard.

## Run locally

1. Install Node.js 20.9 or newer.
2. Run `npm install` and copy `.env.example` to `.env.local`.
3. Add Razorpay test keys and create a webhook for `/api/webhooks/razorpay` with the `payment_link.paid` event. Put its signing secret in `RAZORPAY_WEBHOOK_SECRET`.
4. Add a Resend API key, verified sender address and hotel notification address to enable email.
5. Run `npm run dev` and open `http://localhost:3000`.

Without Supabase, the public site runs in preview mode and availability is clearly labelled as sample inventory. Reservation submission is disabled until Supabase is configured. Razorpay and Resend integrations are optional until their credentials are added; payment confirmation is always driven by a verified Razorpay webhook, never by the browser redirect.

## Admin access

Create staff users in Supabase Auth. Grant the hotel dashboard role by setting `app_metadata.role` to `admin` through a trusted server-side Supabase Admin API or the Supabase dashboard. Do not set this role from a browser client. Visit `/admin/login`; all dashboard data access is server-side and requires that role.

The dashboard manages room rates/inventory, reservation lifecycle and enquiry status. Payment status is read-only and reconciled from signed Razorpay webhook events.

## Deployment

Deploy as a Node.js Next.js application (for example, Vercel or a Node host), configure the same environment variables in the deployment, and set `NEXT_PUBLIC_SITE_URL` to the hotel's canonical HTTPS domain. Point the domain's DNS to the deployment and configure the Razorpay webhook URL as `https://your-domain.example/api/webhooks/razorpay`.