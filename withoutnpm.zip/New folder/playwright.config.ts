import { defineConfig } from "@playwright/test";

/**
 * Browser-download of Playwright's bundled Chromium is blocked on this machine's
 * network, so tests run against a locally installed browser via `channel`.
 * Override with PW_CHANNEL=chrome if Edge is unavailable.
 */
const channel = process.env.PW_CHANNEL || "msedge";
const baseURL = process.env.PW_BASE_URL || "http://localhost:3000";

export default defineConfig({
  testDir: "./tests/e2e",
  timeout: 60_000,
  expect: { timeout: 10_000 },
  fullyParallel: false,
  retries: 0,
  reporter: [["list"], ["html", { open: "never", outputFolder: "playwright-report" }]],
  use: {
    baseURL,
    channel,
    headless: true,
    screenshot: "only-on-failure",
    trace: "on-first-retry",
  },
  // Reuse the already-running `npm run dev` server; start one only if none is up.
  webServer: {
    command: "npm run dev",
    url: baseURL,
    reuseExistingServer: true,
    timeout: 120_000,
  },
  projects: [
    { name: "desktop", use: { viewport: { width: 1440, height: 900 } } },
    { name: "mobile", use: { viewport: { width: 390, height: 844 } } },
  ],
});
