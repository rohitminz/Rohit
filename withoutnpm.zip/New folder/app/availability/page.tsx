import { Suspense } from "react";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import SearchResults from "../search/SearchResults";
import { getSite } from "@/lib/content/service";

export const metadata = { title: "Available Rooms | Hari's Court" };
export const dynamic = "force-dynamic";

export default async function AvailabilityPage() {
  const { settings } = await getSite();
  return (
    <main className="luxe-page">
      <SiteHeader bookLabel={settings.bookCtaLabel} />
      <div className="subpage">
        <Suspense fallback={<p className="empty-note">Loading rooms…</p>}>
          <SearchResults />
        </Suspense>
      </div>
      <SiteFooter />
    </main>
  );
}
