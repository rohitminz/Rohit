"use client";

import { FormEvent, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { ChevronRight } from "lucide-react";
import { formatStayDate, inr, stayNights, TAX_RATE } from "@/lib/room-details";

type RoomGuest = { firstName: string; lastName: string; email: string; phone: string };
const emptyGuest: RoomGuest = { firstName: "", lastName: "", email: "", phone: "" };

export default function BookingForm() {
  const sp = useSearchParams();
  const roomId = sp.get("roomId") ?? "";
  const name = sp.get("name") ?? "Deluxe Room";
  const rate = Math.max(0, Number(sp.get("rate")) || 0);
  const property = sp.get("property") ?? "delhi";
  const propertySlug = sp.get("propertySlug") ?? "";
  const checkIn = sp.get("checkIn") ?? "";
  const checkOut = sp.get("checkOut") ?? "";
  const adults = Math.max(1, Number(sp.get("adults")) || 2);
  const children = Math.max(0, Number(sp.get("children")) || 0);
  const rooms = Math.max(1, Number(sp.get("rooms")) || 1);
  const guests = adults + children;

  const nights = stayNights(checkIn, checkOut);
  const roomTotal = rate * nights * rooms;
  const taxes = Math.round(roomTotal * TAX_RATE);
  const total = roomTotal + taxes;

  // Resolve the booking's property + room from the content layer by SLUG — never a hardcoded default.
  const [resolved, setResolved] = useState<{ name: string; address: string; image: string; found: boolean } | null>(null);

  useEffect(() => {
    if (!propertySlug) return;
    let cancelled = false;
    fetch("/api/content", { cache: "no-store" })
      .then((response) => response.json())
      .then((data) => {
        if (cancelled) return;
        const prop = (data.properties ?? []).find((item: { slug: string }) => item.slug === propertySlug);
        if (!prop) {
          setResolved({ name: "", address: "", image: "", found: false });
          return;
        }
        const room = (prop.rooms ?? []).find((item: { id: string }) => item.id === roomId);
        setResolved({
          name: `${prop.name} ${prop.area}`.trim(),
          address: prop.contactAddress || prop.location || "",
          image: room?.images?.[0] ?? "",
          found: true,
        });
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [propertySlug, roomId]);

  const propertyMissing = Boolean(propertySlug) && resolved !== null && !resolved.found;
  // Return to the availability results for this property + search, not the homepage.
  const availabilityHref = `/availability?${new URLSearchParams({ property: propertySlug || "all", checkIn, checkOut, rooms: String(rooms), adults: String(adults), children: String(children) })}`;

  const [submitting, setSubmitting] = useState(false);
  const [notice, setNotice] = useState("");
  const [guestList, setGuestList] = useState<RoomGuest[]>(() => Array.from({ length: rooms }, () => ({ ...emptyGuest })));
  const [activeRoom, setActiveRoom] = useState(0);
  const [savedRooms, setSavedRooms] = useState<boolean[]>(() => Array.from({ length: rooms }, () => false));
  const [formError, setFormError] = useState("");

  function updateGuest(index: number, patch: Partial<RoomGuest>) {
    setGuestList((list) => list.map((g, idx) => (idx === index ? { ...g, ...patch } : g)));
  }

  function saveRoom(index: number) {
    const guest = guestList[index];
    if (!guest.firstName.trim() || !guest.lastName.trim()) {
      setFormError("Enter the guest's first and last name.");
      return false;
    }
    if (index === 0) {
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(guest.email.trim())) {
        setFormError("Enter a valid email for the primary guest.");
        return false;
      }
      if (guest.phone.replace(/\D/g, "").length < 7) {
        setFormError("Enter a valid contact number for the primary guest.");
        return false;
      }
    }
    setFormError("");
    setSavedRooms((saved) => saved.map((v, idx) => (idx === index ? true : v)));
    return true;
  }

  function removeRoom(index: number) {
    setGuestList((list) => list.map((g, idx) => (idx === index ? { ...emptyGuest } : g)));
    setSavedRooms((saved) => saved.map((v, idx) => (idx === index ? false : v)));
    setActiveRoom(index - 1);
    setFormError("");
  }

  async function confirm(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const primary = guestList[0];
    if (!primary.firstName.trim() || !primary.lastName.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(primary.email.trim()) || primary.phone.replace(/\D/g, "").length < 7) {
      setActiveRoom(0);
      setFormError("Please complete the primary guest's first name, last name, email and contact number.");
      return;
    }
    setSubmitting(true);
    setNotice("");
    setFormError("");
    const form = new FormData(event.currentTarget);
    const perRoomGuests = guestList.map((guest) => ({
      name: `${guest.firstName} ${guest.lastName}`.trim() || `${primary.firstName} ${primary.lastName}`.trim(),
      email: guest.email.trim() || primary.email.trim(),
      phone: guest.phone.trim() || primary.phone.trim(),
    }));
    try {
      const guestsPerRoom = Math.max(1, Math.ceil(guests / rooms));
      const references: string[] = [];
      let checkoutUrl: string | undefined;
      let offline = false;
      let emailed = false;
      for (const guest of perRoomGuests) {
        const response = await fetch("/api/reservations", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            property,
            propertySlug,
            roomTypeId: roomId,
            checkIn,
            checkOut,
            guests: guestsPerRoom,
            guestName: guest.name,
            guestEmail: guest.email,
            guestPhone: guest.phone,
            website: form.get("website"),
            specialRequests: form.get("requests"),
          }),
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error ?? "We could not start this reservation.");
        if (data.checkoutUrl) checkoutUrl = checkoutUrl ?? data.checkoutUrl;
        if (data.offline) offline = true;
        if (data.emailed) emailed = true;
        if (data.reference) references.push(data.reference);
      }
      if (checkoutUrl) window.location.assign(checkoutUrl);
      else if (offline)
        setNotice(
          `Booking ${references.join(", ")} received and saved. ${emailed ? `A confirmation has been emailed to ${primary.email.trim()}.` : "Please keep your reference — email confirmations will be sent once our mail service is set up."} Our team will contact you on ${primary.phone.trim()} to arrange payment.`,
        );
      else setNotice(`Request${references.length > 1 ? "s" : ""} ${references.join(", ")} received. Our reservations team will contact you to complete payment.`);
    } catch (cause) {
      setNotice(cause instanceof Error ? cause.message : "We could not start this reservation.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <section>
      <nav className="crumb" aria-label="Breadcrumb">
        <Link href="/">Home</Link> <ChevronRight size={12} /> <Link href={availabilityHref}>Available Rooms</Link> <ChevronRight size={12} /> <span>Guest Details</span>
      </nav>

      <div className="page-head">
        <div>
          <h1>Complete Your Booking</h1>
          <p className="prop-line">Please enter your details to confirm your reservation.</p>
        </div>
      </div>

      {propertyMissing && (
        <p className="demo-note" role="alert">We couldn&apos;t find the selected property. Please go back and choose your room again.</p>
      )}

      <div className="bk-grid">
        <div className="bk-card">
          <h2>Booking Summary</h2>
          <div className="bk-photo" style={resolved?.image ? { backgroundImage: `url(${resolved.image})` } : { background: "repeating-linear-gradient(135deg, #eef1f5, #eef1f5 12px, #e7ebf1 12px, #e7ebf1 24px)" }} role="img" aria-label={name} />
          <p className="bk-room">{name}</p>
          <p className="bk-prop">{resolved?.found ? <>{resolved.name}<br />{resolved.address}</> : propertyMissing ? "Selected property could not be found" : "Hari's Court"}</p>
          <div className="bk-row"><span>Check-in</span><strong>{formatStayDate(checkIn)}</strong></div>
          <div className="bk-row"><span>Check-out</span><strong>{formatStayDate(checkOut)}</strong></div>
          <div className="bk-row"><span>Nights</span><strong>{nights} Night{nights > 1 ? "s" : ""}</strong></div>
          <div className="bk-row"><span>Guests</span><strong>{adults} Adult{adults > 1 ? "s" : ""}, {children} Child{children === 1 ? "" : "ren"}</strong></div>
          <div className="bk-row"><span>Rooms</span><strong>{rooms}</strong></div>
          <Link href={availabilityHref} className="bk-modify">Modify</Link>
        </div>

        <div className="bk-card">
          <h2>Guest Details</h2>
          <p className="bk-hint">{rooms > 1 ? "Add the guest staying in each room — Room 1 is the primary contact." : "Primary guest only — co-guests are registered at check-in."}</p>
          <form id="guest-form" onSubmit={confirm}>
            <div className="guest-steps">
              {guestList.map((guest, i) =>
                i === activeRoom ? (
                  <div className="guest-active" key={i}>
                    <p className="bk-room-legend">Room {i + 1} {i === 0 ? "· Primary Guest" : "Guest"}</p>
                    <div className="form-2col">
                      <div className="bk-field">
                        <label htmlFor={`firstName-${i}`}>First Name *</label>
                        <input id={`firstName-${i}`} value={guest.firstName} onChange={(e) => updateGuest(i, { firstName: e.target.value })} autoComplete={i === 0 ? "given-name" : "off"} placeholder="Enter first name" />
                      </div>
                      <div className="bk-field">
                        <label htmlFor={`lastName-${i}`}>Last Name *</label>
                        <input id={`lastName-${i}`} value={guest.lastName} onChange={(e) => updateGuest(i, { lastName: e.target.value })} autoComplete={i === 0 ? "family-name" : "off"} placeholder="Enter last name" />
                      </div>
                      <div className="bk-field full">
                        <label htmlFor={`email-${i}`}>Email {i === 0 ? "*" : "(optional — defaults to primary)"}</label>
                        <input id={`email-${i}`} type="email" value={guest.email} onChange={(e) => updateGuest(i, { email: e.target.value })} autoComplete={i === 0 ? "email" : "off"} placeholder="Enter email address" />
                      </div>
                      <div className="bk-field full">
                        <label htmlFor={`phone-${i}`}>Contact Number {i === 0 ? "*" : "(optional)"}</label>
                        <div className="phone-wrap">
                          <span className="prefix">+91</span>
                          <input id={`phone-${i}`} type="tel" value={guest.phone} onChange={(e) => updateGuest(i, { phone: e.target.value })} autoComplete={i === 0 ? "tel" : "off"} placeholder="Enter contact number" />
                        </div>
                      </div>
                    </div>
                    {formError && <p className="guest-form-error" role="alert">{formError}</p>}
                    <div className="guest-actions">
                      <button type="button" className="guest-save-btn" onClick={() => saveRoom(i)}>Save Details</button>
                      {i < rooms - 1 && (
                        <button type="button" className="guest-add-btn" onClick={() => { if (saveRoom(i)) setActiveRoom(i + 1); }}>Save &amp; Add Next Room</button>
                      )}
                      {i > 0 && (
                        <button type="button" className="guest-remove-btn" onClick={() => removeRoom(i)}>Remove</button>
                      )}
                    </div>
                  </div>
                ) : (
                  <button type="button" key={i} className={`guest-step${savedRooms[i] ? " done" : ""}`} onClick={() => { setActiveRoom(i); setFormError(""); }}>
                    <span>Room {i + 1} {i === 0 ? "· Primary" : ""}</span>
                    <span className="guest-step-status">{savedRooms[i] && guest.firstName ? `${guest.firstName} ${guest.lastName}` : "Add details"}</span>
                  </button>
                ),
              )}
            </div>
            <div className="bk-field">
              <label htmlFor="requests">Special Requests (Optional)</label>
              <textarea id="requests" name="requests" placeholder="Any special requests for your stay?" />
            </div>
            <label className="honeypot" aria-hidden="true">Website<input name="website" tabIndex={-1} autoComplete="off" /></label>
          </form>
          {notice && <p className="bk-notice" role="status">{notice}</p>}
        </div>

        <div className="bk-card">
          <h2>Price Breakdown</h2>
          <div className="bk-row"><span>Room Price<br /><small>({rooms} room{rooms > 1 ? "s" : ""} × {nights} night{nights > 1 ? "s" : ""} × {inr(rate)})</small></span><strong>{inr(roomTotal)}</strong></div>
          <div className="bk-row"><span>Taxes &amp; Fees</span><strong>{inr(taxes)}</strong></div>
          <div className="bk-total-row"><span>Total Amount</span><strong>{inr(total)}</strong></div>
          <button type="submit" form="guest-form" className="full-gold-btn" disabled={submitting}>
            {submitting ? "Confirming..." : "Confirm Booking"}
          </button>
          <p className="bk-terms">
            By confirming this booking, you agree to our <Link href="/#contact">Terms &amp; Conditions</Link> and <Link href="/#contact">Privacy Policy</Link>.
          </p>
        </div>
      </div>
    </section>
  );
}
