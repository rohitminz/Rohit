import Link from "next/link";
import {
  AirVent,
  BedDouble,
  Briefcase,
  ChevronRight,
  CircleCheck,
  ConciergeBell,
  DoorClosed,
  Droplets,
  Lock,
  Maximize,
  Phone,
  Shirt,
  Sparkles,
  Tv,
  Users,
  Wifi,
} from "lucide-react";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import RoomGallery from "@/components/RoomGallery";
import { getSite } from "@/lib/content/service";
import {
  getRoomContent,
  inr,
  roomAmenities,
  roomFeatures,
  roomPolicies,
  stayNights,
  TAX_RATE,
} from "@/lib/room-details";

const amenityIcons = [Wifi, AirVent, Tv, ConciergeBell, Droplets, DoorClosed, Briefcase, Lock, Shirt, Sparkles];

export const metadata = { title: "Room Details | Hari's Court" };

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

export default async function RoomDetailsPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: SearchParams }) {
  const { id } = await params;
  const sp = await searchParams;
  const get = (key: string) => {
    const value = sp[key];
    return typeof value === "string" ? value : "";
  };

  const property = get("property") || "delhi";
  const propertySlug = get("propertySlug");
  const checkIn = get("checkIn");
  const checkOut = get("checkOut");
  const adults = Math.max(1, Number(get("adults")) || 2);
  const children = Math.max(0, Number(get("children")) || 0);
  const rooms = Math.max(1, Number(get("rooms")) || 1);
  const rate = Math.max(0, Number(get("rate")) || 0);
  const name = get("name") || "Deluxe Room";

  const details = getRoomContent(id, name);
  const { settings } = await getSite();
  const nights = stayNights(checkIn, checkOut);
  const roomTotal = rate * nights;
  const taxes = Math.round(roomTotal * TAX_RATE);
  const total = roomTotal + taxes;

  const bookingHref = `/booking?${new URLSearchParams({
    roomId: id,
    name,
    rate: String(rate),
    property,
    propertySlug,
    checkIn,
    checkOut,
    adults: String(adults),
    children: String(children),
    rooms: String(rooms),
  })}`;

  return (
    <main className="luxe-page">
      <SiteHeader bookLabel={settings.bookCtaLabel} />
      <div className="subpage">
        <nav className="crumb" aria-label="Breadcrumb">
          <Link href="/">Home</Link> <ChevronRight size={12} /> <Link href={`/availability?property=${propertySlug || "all"}&checkIn=${checkIn}&checkOut=${checkOut}&rooms=${rooms}&adults=${adults}&children=${children}`}>Available Rooms</Link> <ChevronRight size={12} /> <span>{name}</span>
        </nav>

        <div className="rd-grid">
          <div>
            <RoomGallery images={details.images} name={name} />

            <h2 className="rd-title">{name}</h2>
            <p className="rd-tagline">{details.tagline}</p>

            <div className="spec-row">
              <span><Users size={15} /> {details.maxGuests} Adults</span>
              <span><BedDouble size={15} /> {details.bed}</span>
              <span><Maximize size={15} /> {details.size}</span>
            </div>

            <p className="rd-desc">{details.description}</p>

            <h3 className="rd-sub">Room Amenities</h3>
            <div className="amen-grid">
              {roomAmenities.map((amenity, i) => {
                const Icon = amenityIcons[i % amenityIcons.length];
                return (
                  <div className="amen-cell" key={amenity}>
                    <Icon size={20} />
                    {amenity}
                  </div>
                );
              })}
            </div>

            <h3 className="rd-sub">Room Features</h3>
            <ul className="feat-grid">
              {roomFeatures.map((feature) => (
                <li key={feature}><CircleCheck size={15} /> {feature}</li>
              ))}
            </ul>

            <h3 className="rd-sub">Policies</h3>
            <ul className="policy-list">
              {roomPolicies.map((policy) => (
                <li key={policy.label}><strong>{policy.label}:</strong> {policy.text}</li>
              ))}
            </ul>
          </div>

          <div className="side-stack">
            <div className="price-card">
              <h3>Price Details</h3>
              <p className="price-big">{inr(rate)} <small>per night</small></p>
              <div className="price-row"><span>{nights} Night{nights > 1 ? "s" : ""} × {inr(rate)}</span><strong>{inr(roomTotal)}</strong></div>
              <div className="price-row"><span>Taxes &amp; Fees (18% GST)</span><strong>{inr(taxes)}</strong></div>
              <div className="price-row total"><span>Total</span><strong>{inr(total)}</strong></div>
              <Link href={bookingHref} className="full-gold-btn">Select This Room</Link>
            </div>

            <div className="help-card">
              <h3>Need Help?</h3>
              <p>Contact us for special requests or group bookings.</p>
              <a href={`tel:${settings.contactPhone.replace(/[^\d+]/g, "")}`}><Phone size={15} /> {settings.contactPhone}</a>
            </div>
          </div>
        </div>
      </div>
      <SiteFooter />
    </main>
  );
}
