import { NextRequest, NextResponse } from "next/server";
import { getAdminSupabase } from "@/lib/supabase/admin";
import { todayInIndia } from "@/lib/booking-dates";

const previewRooms = [
  { id: "demo-presidential", name: "Presidential Royal Suite", rate: 6499, available: 1 },
  { id: "demo-executive", name: "Executive Luxury Suite", rate: 4999, available: 2 },
  { id: "demo-deluxe", name: "Deluxe Comfort Chamber", rate: 3799, available: 3 },
];

export async function GET(request: NextRequest) {
  const params = request.nextUrl.searchParams;
  const property = params.get("property");
  const checkIn = params.get("checkIn");
  const checkOut = params.get("checkOut");
  const guests = Number(params.get("guests"));
  if (!property || !["gurugram", "delhi"].includes(property) || !validDates(checkIn, checkOut) || !Number.isInteger(guests) || guests < 1 || guests > 6) {
    return NextResponse.json({ error: "Choose a valid destination, date range and guest count." }, { status: 400 });
  }
  const supabase = getAdminSupabase();
  if (!supabase) return NextResponse.json({ rooms: guests <= 3 ? previewRooms : [], demo: true });
  const { data, error } = await supabase.rpc("get_available_room_types", {
    p_property_slug: property,
    p_check_in: checkIn,
    p_check_out: checkOut,
    p_guests: guests,
  });
  if (error) {
    console.error("Availability query failed", error.message);
    return NextResponse.json({ error: "We could not check availability just now. Please try again." }, { status: 503 });
  }
  const rooms = (data ?? []).map((room: { id: string; name: string; rate_inr: number; available: number }) => ({
    id: room.id, name: room.name, rate: room.rate_inr, available: room.available,
  }));
  return NextResponse.json({ rooms, demo: false });
}

function validDates(checkIn: string | null, checkOut: string | null) {
  if (!checkIn || !checkOut || !/^\d{4}-\d{2}-\d{2}$/.test(checkIn) || !/^\d{4}-\d{2}-\d{2}$/.test(checkOut)) return false;
  const start = new Date(`${checkIn}T00:00:00Z`);
  const end = new Date(`${checkOut}T00:00:00Z`);
  return checkIn >= todayInIndia() && end > start && end.getTime() - start.getTime() <= 30 * 86400000;
}