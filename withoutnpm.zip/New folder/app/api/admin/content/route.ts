import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin-auth";
import { contentSchema } from "@/lib/content/schema";
import { failure, sameOrigin } from "@/lib/content/http";
import { discardDraft, readState, saveDraft } from "@/lib/content/store";

export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await requireAdmin();
  if (!admin.ok) return NextResponse.json({ error: "Administrator access required." }, { status: 401 });
  try {
    const state = await readState();
    return NextResponse.json({ published: state.published, draft: state.draft, source: state.source, storage: state.storage });
  } catch (error) {
    return failure(error);
  }
}

/** Saves the whole content document as the draft. Nothing public changes until it is published. */
export async function PUT(request: NextRequest) {
  const admin = await requireAdmin();
  if (!admin.ok) return NextResponse.json({ error: "Administrator access required." }, { status: 401 });
  if (!sameOrigin(request)) return NextResponse.json({ error: "Cross-site requests are not allowed." }, { status: 403 });
  let body: { content?: unknown; expectedVersion?: unknown };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const parsed = contentSchema.safeParse(body.content);
  if (!parsed.success || typeof body.expectedVersion !== "number") {
    const issues = parsed.success ? [] : parsed.error.issues.slice(0, 12).map((issue) => `${issue.path.join(".")}: ${issue.message}`);
    return NextResponse.json({ error: "Some fields are not valid.", issues }, { status: 422 });
  }
  try {
    await saveDraft(parsed.data, body.expectedVersion, admin.user);
    return NextResponse.json({ saved: true });
  } catch (error) {
    return failure(error);
  }
}

export async function DELETE(request: NextRequest) {
  const admin = await requireAdmin();
  if (!admin.ok) return NextResponse.json({ error: "Administrator access required." }, { status: 401 });
  if (!sameOrigin(request)) return NextResponse.json({ error: "Cross-site requests are not allowed." }, { status: 403 });
  try {
    await discardDraft();
    return NextResponse.json({ discarded: true });
  } catch (error) {
    return failure(error);
  }
}
