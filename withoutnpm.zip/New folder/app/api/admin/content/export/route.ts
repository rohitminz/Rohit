import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin-auth";
import { failure, sameOrigin } from "@/lib/content/http";
import { replaceReportingSheet } from "@/lib/content/store";
import { getAdminSupabase } from "@/lib/supabase/admin";

type ReservationRow = {
  reference: string;
  guest_name: string;
  guest_email: string;
  guest_phone: string;
  check_in: string;
  check_out: string;
  total_amount_inr: number;
  status: string;
  created_at: string;
  room_types: { name: string; property_name: string } | { name: string; property_name: string }[] | null;
};

/** One-way copy of live Supabase records into the workbook's reporting sheets. The database stays the source of truth. */
export async function POST(request: NextRequest) {
  const admin = await requireAdmin();
  if (!admin.ok) return NextResponse.json({ error: "Administrator access required." }, { status: 401 });
  if (!sameOrigin(request)) return NextResponse.json({ error: "Cross-site requests are not allowed." }, { status: 403 });
  const supabase = getAdminSupabase();
  if (!supabase) return NextResponse.json({ error: "Supabase is not configured, so there are no live records to export." }, { status: 503 });
  const [reservations, enquiries] = await Promise.all([
    supabase.from("reservations").select("reference, guest_name, guest_email, guest_phone, check_in, check_out, total_amount_inr, status, created_at, room_types(name, property_name)").order("created_at", { ascending: false }).limit(5000),
    supabase.from("enquiries").select("id, name, email, phone, kind, message, status, created_at").order("created_at", { ascending: false }).limit(5000),
  ]);
  if (reservations.error || enquiries.error) {
    console.error("Workbook export query failed", reservations.error?.message, enquiries.error?.message);
    return NextResponse.json({ error: "Could not read live records." }, { status: 503 });
  }
  const bookingRows = (reservations.data as ReservationRow[]).map((row) => {
    const room = Array.isArray(row.room_types) ? row.room_types[0] : row.room_types;
    return { reference: row.reference, guestName: row.guest_name, guestEmail: row.guest_email, property: room?.property_name ?? "", room: room?.name ?? "", checkIn: row.check_in, checkOut: row.check_out, totalInr: row.total_amount_inr, status: row.status, createdAt: row.created_at };
  });
  const guests = new Map<string, { email: string; name: string; phone: string; lastStay: string }>();
  for (const row of reservations.data as ReservationRow[]) {
    const key = row.guest_email.toLowerCase();
    const previous = guests.get(key);
    if (!previous || row.check_in > previous.lastStay) guests.set(key, { email: row.guest_email, name: row.guest_name, phone: row.guest_phone, lastStay: row.check_in });
  }
  try {
    await replaceReportingSheet("bookings", bookingRows);
    await replaceReportingSheet("guests", [...guests.values()]);
    await replaceReportingSheet("enquiries", (enquiries.data ?? []).map((row) => ({ id: row.id, name: row.name, email: row.email, phone: row.phone, kind: row.kind, message: row.message, status: row.status, createdAt: row.created_at })));
    return NextResponse.json({ exported: { bookings: bookingRows.length, guests: guests.size, enquiries: enquiries.data?.length ?? 0 } });
  } catch (error) {
    return failure(error);
  }
}
