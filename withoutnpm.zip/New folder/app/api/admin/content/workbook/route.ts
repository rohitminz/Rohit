import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin-auth";
import { failure } from "@/lib/content/http";
import { readWorkbookBuffer } from "@/lib/content/store";

export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await requireAdmin();
  if (!admin.ok) return NextResponse.json({ error: "Administrator access required." }, { status: 401 });
  try {
    const buffer = await readWorkbookBuffer();
    return new NextResponse(new Uint8Array(buffer), {
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": 'attachment; filename="haris_court_management.xlsx"',
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    return failure(error);
  }
}
