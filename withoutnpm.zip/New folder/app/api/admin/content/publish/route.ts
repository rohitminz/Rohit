import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin-auth";
import { failure, sameOrigin } from "@/lib/content/http";
import { publishDraft } from "@/lib/content/store";

export async function POST(request: NextRequest) {
  const admin = await requireAdmin();
  if (!admin.ok) return NextResponse.json({ error: "Administrator access required." }, { status: 401 });
  if (!sameOrigin(request)) return NextResponse.json({ error: "Cross-site requests are not allowed." }, { status: 403 });
  let body: { expectedVersion?: unknown };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  if (typeof body.expectedVersion !== "number") return NextResponse.json({ error: "expectedVersion is required." }, { status: 400 });
  try {
    await publishDraft(body.expectedVersion);
    return NextResponse.json({ published: true });
  } catch (error) {
    return failure(error);
  }
}
