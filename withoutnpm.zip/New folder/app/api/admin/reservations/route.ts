import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin-auth";
import { listReservations, makeReference, saveReservation, updateReservation } from "@/lib/reservations-store";
import { sendReservationEmail } from "@/lib/email";
import { getSite } from "@/lib/content/service";

export const dynamic = "force-dynamic";

const STATUSES = ["pending_payment", "confirmed", "checked_in", "checked_out", "cancelled"];

// Locally-stored reservations taken while the live booking backend is not connected.
export async function GET() {
  const admin = await requireAdmin();
  if (!admin.ok) return NextResponse.json({ error: "Administrator access required." }, { status: 401 });
  try {
    return NextResponse.json({ reservations: await listReservations() });
  } catch {
    return NextResponse.json({ reservations: [] });
  }
}

// Creates a reservation taken by the front desk: persists it and emails the guest/hotel.
export async function POST(request: NextRequest) {
  const admin = await requireAdmin();
  if (!admin.ok) return NextResponse.json({ error: "Administrator access required." }, { status: 401 });
  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const guestName = clean(body.guestName, 100);
  const guestEmail = clean(body.guestEmail, 254).toLowerCase();
  const guestPhone = clean(body.guestPhone, 30);
  const roomName = clean(body.roomName, 80);
  const propertyName = clean(body.propertyName, 120);
  const propertySlug = clean(body.propertySlug, 40);
  const specialRequests = clean(body.specialRequests, 500);
  const checkIn = clean(body.checkIn, 10);
  const checkOut = clean(body.checkOut, 10);
  const guests = Math.max(1, Math.round(Number(body.guests) || 1));
  const amount = Math.max(0, Math.round(Number(body.amount) || 0));
  const amountPaid = Math.min(amount, Math.max(0, Math.round(Number(body.amountPaid) || 0)));
  const status = STATUSES.includes(String(body.status)) ? String(body.status) : "pending_payment";
  if (!guestName || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(guestEmail) || !roomName || !propertyName || !dateValid(checkIn) || !dateValid(checkOut) || checkOut <= checkIn) {
    return NextResponse.json({ error: "Please check the guest details and stay dates." }, { status: 400 });
  }
  const reference = makeReference();
  let notifyEmails: string[] = [];
  try {
    const site = await getSite();
    const prop = site.properties.find((item) => item.slug === propertySlug);
    notifyEmails = parseNotifyEmails(site.settings.reservationEmails, site.settings.contactEmail, prop?.contactEmail ? [prop.contactEmail] : []);
  } catch {
    notifyEmails = [];
  }
  let emailed = false;
  try {
    emailed = await sendReservationEmail(
      { reference, guestName, guestEmail, propertyName, roomName, checkIn, checkOut, amount, specialRequests },
      status === "confirmed",
      notifyEmails,
    );
  } catch (emailError) {
    console.error("Reservation email could not be sent", emailError instanceof Error ? emailError.message : emailError);
  }
  const saved = await saveReservation({
    reference,
    guest_name: guestName,
    guest_email: guestEmail,
    guest_phone: guestPhone,
    guests,
    special_requests: specialRequests,
    check_in: checkIn,
    check_out: checkOut,
    total_amount_inr: amount,
    amount_paid: amountPaid,
    status,
    created_at: new Date().toISOString(),
    room_types: { name: roomName, property_name: propertyName },
    property_slug: propertySlug,
    emailed,
  });
  return NextResponse.json({ reference, saved, emailed, status }, { status: 201 });
}

function clean(value: unknown, limit: number) {
  return typeof value === "string" ? value.trim().replace(/[<>]/g, "").slice(0, limit) : "";
}

function dateValid(value: string) {
  return /^\d{4}-\d{2}-\d{2}$/.test(value);
}

// Reservation notification recipients from the dashboard settings, falling back to the contact email.
function parseNotifyEmails(raw: string, fallback: string, extra: string[] = []): string[] {
  const parsed = (raw || "").split(/[\s,;]+/).map((item) => item.trim()).filter(Boolean);
  const base = parsed.length ? parsed : fallback ? [fallback] : [];
  const list = [...extra.filter(Boolean), ...base];
  return [...new Set(list.map((item) => item.toLowerCase()))];
}

export async function PATCH(request: NextRequest) {
  const admin = await requireAdmin();
  if (!admin.ok) return NextResponse.json({ error: "Administrator access required." }, { status: 401 });
  let body: { reference?: unknown; status?: unknown; amountPaid?: unknown; charges?: unknown; payments?: unknown };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const reference = typeof body.reference === "string" ? body.reference : "";
  if (!reference) return NextResponse.json({ error: "A reference is required." }, { status: 400 });
  const patch: { status?: string; amount_paid?: number; charges?: Charge[]; payments?: Payment[] } = {};
  if (body.status !== undefined) {
    if (!STATUSES.includes(String(body.status))) return NextResponse.json({ error: "A valid status is required." }, { status: 400 });
    patch.status = String(body.status);
  }
  if (body.amountPaid !== undefined) {
    patch.amount_paid = Math.max(0, Math.round(Number(body.amountPaid) || 0));
  }
  if (Array.isArray(body.charges)) {
    patch.charges = body.charges.slice(0, 50).map((item) => sanitizeCharge(item));
  }
  if (Array.isArray(body.payments)) {
    patch.payments = body.payments.slice(0, 100).map((item) => sanitizePayment(item));
  }
  if (patch.status === undefined && patch.amount_paid === undefined && patch.charges === undefined && patch.payments === undefined) {
    return NextResponse.json({ error: "Nothing to update." }, { status: 400 });
  }
  const updated = await updateReservation(reference, patch);
  if (!updated) return NextResponse.json({ error: "Reservation not found." }, { status: 404 });
  return NextResponse.json({ ok: true });
}

type Charge = { id: string; label: string; amount: number; at: string; image?: string };
type Payment = { id: string; amount: number; note: string; at: string };

function sanitizeCharge(item: unknown): Charge {
  const record = (item && typeof item === "object" ? item : {}) as Record<string, unknown>;
  const image = typeof record.image === "string" && (record.image.startsWith("/uploads/") || /^https:\/\//.test(record.image)) ? record.image.slice(0, 300) : undefined;
  return {
    id: typeof record.id === "string" && record.id ? record.id.slice(0, 40) : `chg-${Math.random().toString(36).slice(2, 10)}`,
    label: clean(record.label, 60) || "Extra charge",
    amount: Math.max(0, Math.round(Number(record.amount) || 0)),
    at: typeof record.at === "string" ? record.at.slice(0, 40) : new Date().toISOString(),
    ...(image ? { image } : {}),
  };
}

function sanitizePayment(item: unknown): Payment {
  const record = (item && typeof item === "object" ? item : {}) as Record<string, unknown>;
  return {
    id: typeof record.id === "string" && record.id ? record.id.slice(0, 40) : `pay-${Math.random().toString(36).slice(2, 10)}`,
    amount: Math.max(0, Math.round(Number(record.amount) || 0)),
    note: clean(record.note, 80),
    at: typeof record.at === "string" ? record.at.slice(0, 40) : new Date().toISOString(),
  };
}
