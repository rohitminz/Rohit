import { NextRequest, NextResponse } from "next/server";
import { requireSuper } from "@/lib/admin-auth";
import { createUser, decryptText, deleteUser, listUsers, toPublic, updateUser } from "@/lib/auth/users-store";
import { ROLES, type Role } from "@/lib/auth/permissions";
import { sameOrigin } from "@/lib/content/http";

export const dynamic = "force-dynamic";

function isRole(value: unknown): value is Role {
  return typeof value === "string" && (ROLES as string[]).includes(value);
}

export async function GET() {
  const gate = await requireSuper();
  if (!gate.ok) return NextResponse.json({ error: "Super administrator access required." }, { status: 403 });
  // Super admin may view any official's password, so include the decrypted value here (super-only route).
  return NextResponse.json({ users: (await listUsers()).map((user) => ({ ...toPublic(user), password: decryptText(user.passwordEnc) })) });
}

export async function POST(request: NextRequest) {
  const gate = await requireSuper();
  if (!gate.ok) return NextResponse.json({ error: "Super administrator access required." }, { status: 403 });
  if (!sameOrigin(request)) return NextResponse.json({ error: "Cross-site requests are not allowed." }, { status: 403 });
  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const username = typeof body.username === "string" ? body.username : "";
  const name = typeof body.name === "string" ? body.name : "";
  const password = typeof body.password === "string" ? body.password : "";
  const role: Role = isRole(body.role) ? body.role : "viewer";
  const result = await createUser({ username, name, password, role, permissions: body.permissions as never });
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: 400 });
  return NextResponse.json({ user: result.user }, { status: 201 });
}

export async function PATCH(request: NextRequest) {
  const gate = await requireSuper();
  if (!gate.ok) return NextResponse.json({ error: "Super administrator access required." }, { status: 403 });
  if (!sameOrigin(request)) return NextResponse.json({ error: "Cross-site requests are not allowed." }, { status: 403 });
  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const id = typeof body.id === "string" ? body.id : "";
  if (!id) return NextResponse.json({ error: "A user id is required." }, { status: 400 });
  const changes: Parameters<typeof updateUser>[1] = {};
  if (typeof body.name === "string") changes.name = body.name;
  if (isRole(body.role)) changes.role = body.role;
  if (body.permissions && typeof body.permissions === "object") changes.permissions = body.permissions as never;
  if (body.status === "active" || body.status === "disabled") changes.status = body.status;
  if (typeof body.password === "string" && body.password) changes.password = body.password;
  const result = await updateUser(id, changes);
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: 400 });
  return NextResponse.json({ user: result.user });
}

export async function DELETE(request: NextRequest) {
  const gate = await requireSuper();
  if (!gate.ok) return NextResponse.json({ error: "Super administrator access required." }, { status: 403 });
  if (!sameOrigin(request)) return NextResponse.json({ error: "Cross-site requests are not allowed." }, { status: 403 });
  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const id = typeof body.id === "string" ? body.id : "";
  if (!id) return NextResponse.json({ error: "A user id is required." }, { status: 400 });
  const ok = await deleteUser(id);
  if (!ok) return NextResponse.json({ error: "User not found." }, { status: 404 });
  return NextResponse.json({ ok: true });
}
