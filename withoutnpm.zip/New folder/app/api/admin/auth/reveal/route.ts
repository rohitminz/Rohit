import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth/session";
import { getUserPassword } from "@/lib/auth/users-store";

export const dynamic = "force-dynamic";

// Returns the signed-in user's own password: the super admin's from the env, an official's decrypted copy.
export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  if (user.isSuper) return NextResponse.json({ password: process.env.SUPERADMIN_PASSWORD ?? "" });
  return NextResponse.json({ password: await getUserPassword(user.id) });
}
