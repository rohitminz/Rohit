import { NextRequest, NextResponse } from "next/server";
import { authenticate, startSession } from "@/lib/auth/session";
import { markActive } from "@/lib/auth/users-store";
import { sameOrigin } from "@/lib/content/http";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  if (!sameOrigin(request)) return NextResponse.json({ error: "Cross-site requests are not allowed." }, { status: 403 });
  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const username = typeof body.username === "string" ? body.username.trim() : "";
  const password = typeof body.password === "string" ? body.password : "";
  if (!username || !password) return NextResponse.json({ error: "Enter your username and password." }, { status: 400 });
  const user = await authenticate(username, password);
  if (!user) return NextResponse.json({ error: "Invalid username or password." }, { status: 401 });
  await startSession(user);
  if (!user.isSuper) await markActive(user.id);
  return NextResponse.json({ user: { id: user.id, username: user.username, name: user.name, role: user.role, isSuper: user.isSuper, permissions: user.permissions } });
}
