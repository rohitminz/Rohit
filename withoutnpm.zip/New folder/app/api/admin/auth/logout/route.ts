import { NextRequest, NextResponse } from "next/server";
import { endSession } from "@/lib/auth/session";
import { sameOrigin } from "@/lib/content/http";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  if (!sameOrigin(request)) return NextResponse.json({ error: "Cross-site requests are not allowed." }, { status: 403 });
  await endSession();
  return NextResponse.json({ ok: true });
}
