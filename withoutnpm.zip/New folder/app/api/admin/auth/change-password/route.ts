import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth/session";
import { getUserById, updateUser, verifyPassword } from "@/lib/auth/users-store";
import { sameOrigin } from "@/lib/content/http";

export const dynamic = "force-dynamic";

// Lets the signed-in official change their own password after confirming the current one.
export async function POST(request: NextRequest) {
  if (!sameOrigin(request)) return NextResponse.json({ error: "Cross-site requests are not allowed." }, { status: 403 });
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const currentPassword = typeof body.currentPassword === "string" ? body.currentPassword : "";
  const newPassword = typeof body.newPassword === "string" ? body.newPassword : "";
  if (newPassword.length < 6) return NextResponse.json({ error: "New password must be at least 6 characters." }, { status: 400 });
  if (user.isSuper) {
    return NextResponse.json({ error: "The super admin password is set in .env.local (SUPERADMIN_PASSWORD). Edit it there and restart." }, { status: 400 });
  }
  const record = await getUserById(user.id);
  if (!record || !verifyPassword(currentPassword, record.passwordHash)) {
    return NextResponse.json({ error: "Your current password is incorrect." }, { status: 400 });
  }
  const result = await updateUser(user.id, { password: newPassword });
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: 400 });
  return NextResponse.json({ ok: true });
}
