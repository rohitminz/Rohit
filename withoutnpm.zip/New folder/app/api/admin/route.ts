import { NextRequest, NextResponse } from "next/server";
import { isHotelAdmin } from "@/lib/admin-auth";
import { getAdminSupabase } from "@/lib/supabase/admin";

export async function GET() {
  if (!await isHotelAdmin()) return NextResponse.json({ error: "Administrator access required." }, { status: 401 });
  const supabase = getAdminSupabase();
  if (!supabase) return NextResponse.json({ error: "Database is not configured." }, { status: 503 });
  const [rooms, reservations, payments, enquiries] = await Promise.all([
    supabase.from("room_types").select("id, property_slug, property_name, name, rate_inr, inventory, max_guests, active").order("property_slug").order("rate_inr"),
    supabase.from("reservations").select("reference, guest_name, guest_email, guest_phone, special_requests, check_in, check_out, guests, total_amount_inr, status, created_at, room_types(name, property_name)").order("created_at", { ascending: false }).limit(100),
    supabase.from("payments").select("id, reservation_reference, razorpay_payment_id, amount_inr, currency, status, paid_at, created_at").order("created_at", { ascending: false }).limit(100),
    supabase.from("enquiries").select("id, name, email, phone, kind, message, status, created_at").order("created_at", { ascending: false }).limit(100),
  ]);
  const queryError = rooms.error ?? reservations.error ?? payments.error ?? enquiries.error;
  if (queryError) {
    console.error("Admin overview query failed", queryError.message);
    return NextResponse.json({ error: "Could not load hotel records." }, { status: 503 });
  }
  return NextResponse.json({ rooms: rooms.data, reservations: reservations.data, payments: payments.data, enquiries: enquiries.data });
}

export async function PATCH(request: NextRequest) {
  if (!await isHotelAdmin()) return NextResponse.json({ error: "Administrator access required." }, { status: 401 });
  const supabase = getAdminSupabase();
  if (!supabase) return NextResponse.json({ error: "Database is not configured." }, { status: 503 });
  let body: { entity?: string; id?: string; changes?: Record<string, unknown> };
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Invalid request." }, { status: 400 }); }
  const changes = body.changes ?? {};
  let result;
  if (body.entity === "room" && isUuid(body.id) && validRoomChanges(changes)) {
    result = await supabase.from("room_types").update(changes).eq("id", body.id).select("id").maybeSingle();
  } else if (body.entity === "reservation" && typeof body.id === "string" && /^[A-Z0-9-]{6,40}$/.test(body.id) && ["cancelled", "checked_in", "checked_out"].includes(String(changes.status))) {
    result = await supabase.from("reservations").update({ status: changes.status }).eq("reference", body.id).in("status", ["pending_payment", "confirmed", "checked_in"]).select("reference").maybeSingle();
  } else if (body.entity === "enquiry" && isUuid(body.id) && ["new", "in_progress", "resolved"].includes(String(changes.status))) {
    result = await supabase.from("enquiries").update({ status: changes.status }).eq("id", body.id).select("id").maybeSingle();
  } else {
    return NextResponse.json({ error: "Unsupported update." }, { status: 400 });
  }
  if (result.error) {
    console.error("Admin update failed", result.error.message);
    return NextResponse.json({ error: "Could not save this change." }, { status: 503 });
  }
  if (!result.data) return NextResponse.json({ error: "Record not found or cannot be changed in its current state." }, { status: 409 });
  return NextResponse.json({ updated: true });
}

function validRoomChanges(changes: Record<string, unknown>) {
  const keys = Object.keys(changes);
  if (!keys.length || keys.some(key => !["rate_inr", "inventory", "active"].includes(key))) return false;
  return keys.every(key => key === "active"
    ? typeof changes[key] === "boolean"
    : typeof changes[key] === "number" && Number.isInteger(changes[key]) && Number(changes[key]) >= (key === "inventory" ? 0 : 500) && Number(changes[key]) <= 1000000);
}

function isUuid(value: unknown): value is string {
  return typeof value === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}