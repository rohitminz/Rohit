import { randomBytes } from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin-auth";
import { sameOrigin } from "@/lib/content/http";

const MAX_BYTES = 8 * 1024 * 1024;

function detectExtension(bytes: Uint8Array): "jpg" | "png" | "webp" | null {
  if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return "jpg";
  if (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) return "png";
  if (bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46 && bytes[8] === 0x57 && bytes[9] === 0x45 && bytes[10] === 0x42 && bytes[11] === 0x50) return "webp";
  return null;
}

/**
 * Stores an uploaded image under public/uploads with a unique name, so originals are never overwritten.
 * This writes to the local disk: on read-only hosting, point image fields at a CDN/blob URL instead.
 */
export async function POST(request: NextRequest) {
  const admin = await requireAdmin();
  if (!admin.ok) return NextResponse.json({ error: "Administrator access required." }, { status: 401 });
  if (!sameOrigin(request)) return NextResponse.json({ error: "Cross-site requests are not allowed." }, { status: 403 });
  let file: FormDataEntryValue | null;
  try {
    file = (await request.formData()).get("file");
  } catch {
    return NextResponse.json({ error: "Invalid upload." }, { status: 400 });
  }
  if (!(file instanceof File)) return NextResponse.json({ error: "Choose an image file." }, { status: 400 });
  if (file.size === 0 || file.size > MAX_BYTES) return NextResponse.json({ error: "Images must be under 8 MB." }, { status: 413 });
  const bytes = new Uint8Array(await file.arrayBuffer());
  const extension = detectExtension(bytes);
  if (!extension) return NextResponse.json({ error: "Only JPEG, PNG or WebP images are accepted." }, { status: 415 });
  const name = `${Date.now()}-${randomBytes(4).toString("hex")}.${extension}`;
  try {
    const directory = path.join(process.cwd(), "public", "uploads");
    await fs.mkdir(directory, { recursive: true });
    await fs.writeFile(path.join(directory, name), bytes, { flag: "wx" });
  } catch (error) {
    console.error("Image upload failed", error instanceof Error ? error.message : error);
    return NextResponse.json({ error: "Could not store the image on this server. Use an https image URL instead." }, { status: 503 });
  }
  return NextResponse.json({ url: `/uploads/${name}` });
}
