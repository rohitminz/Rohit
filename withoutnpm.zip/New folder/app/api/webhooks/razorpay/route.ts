import { createHmac, timingSafeEqual } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import { getAdminSupabase } from "@/lib/supabase/admin";
import { sendReservationEmail } from "@/lib/email";

export async function POST(request: NextRequest) {
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
  const signature = request.headers.get("x-razorpay-signature");
  if (!secret || !signature) return NextResponse.json({ error: "Webhook is not configured." }, { status: 503 });
  const rawBody = await request.text();
  const expected = createHmac("sha256", secret).update(rawBody).digest();
  let provided: Buffer;
  try { provided = Buffer.from(signature, "hex"); } catch { return NextResponse.json({ error: "Invalid signature." }, { status: 400 }); }
  if (expected.length !== provided.length || !timingSafeEqual(expected, provided)) return NextResponse.json({ error: "Invalid signature." }, { status: 400 });
  let event: {
    event?: string;
    payload?: {
      payment_link?: { entity?: { id?: string; reference_id?: string; amount?: number; currency?: string } };
      payment?: { entity?: { id?: string; status?: string; captured?: boolean } };
    };
  };
  try { event = JSON.parse(rawBody); } catch { return NextResponse.json({ error: "Invalid payload." }, { status: 400 }); }
  if (event.event !== "payment_link.paid") return NextResponse.json({ received: true });
  const link = event.payload?.payment_link?.entity;
  const payment = event.payload?.payment?.entity;
  if (!link?.id || !link.reference_id || !payment?.id || payment.status !== "captured") return NextResponse.json({ error: "Incomplete payment event." }, { status: 400 });
  const supabase = getAdminSupabase();
  if (!supabase) return NextResponse.json({ error: "Database is not configured." }, { status: 503 });
  const amountInRupees = Number(link.amount) / 100;
  const { data: expectedPayment, error: lookupError } = await supabase.from("payments")
    .select("reservation_reference, amount_inr").eq("razorpay_payment_link_id", link.id).maybeSingle();
  if (lookupError || !expectedPayment || expectedPayment.reservation_reference !== link.reference_id
    || expectedPayment.amount_inr !== amountInRupees || link.currency !== "INR") {
    console.error("Payment event did not match its stored payment link", lookupError?.message);
    return NextResponse.json({ error: "Payment details do not match." }, { status: 400 });
  }
  const paidAt = new Date().toISOString();
  const { error: paymentError } = await supabase.from("payments").update({
    razorpay_payment_id: payment.id,
    status: "paid",
    amount_inr: amountInRupees,
    currency: link.currency ?? "INR",
    paid_at: paidAt,
  }).eq("razorpay_payment_link_id", link.id);
  const { data: reservation, error: reservationError } = await supabase.from("reservations").update({ status: "confirmed", paid_at: paidAt })
    .eq("reference", link.reference_id).eq("status", "pending_payment")
    .select("reference, guest_name, guest_email, special_requests, check_in, check_out, total_amount_inr, room_types(name, property_name)").maybeSingle();
  if (paymentError || reservationError) {
    console.error("Payment reconciliation failed", paymentError?.message, reservationError?.message);
    return NextResponse.json({ error: "Could not reconcile payment." }, { status: 503 });
  }
  if (reservation) {
    const room = reservation.room_types as unknown as { name: string; property_name: string };
    try {
      await sendReservationEmail({
        reference: reservation.reference,
        guestName: reservation.guest_name,
        guestEmail: reservation.guest_email,
        propertyName: room.property_name,
        roomName: room.name,
        checkIn: reservation.check_in,
        checkOut: reservation.check_out,
        amount: reservation.total_amount_inr,
        specialRequests: reservation.special_requests ?? "",
      }, true);
    } catch (error) { console.error("Confirmation email could not be sent", error); }
  }
  return NextResponse.json({ received: true });
}