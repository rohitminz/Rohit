import { NextRequest, NextResponse } from "next/server";
import { getAdminSupabase } from "@/lib/supabase/admin";
import { Resend } from "resend";

export async function POST(request: NextRequest) {
  let body: Record<string, unknown>;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Invalid request." }, { status: 400 }); }
  if (typeof body.website === "string" && body.website) return NextResponse.json({ received: true });
  const name = stringValue(body.name, 100);
  const email = stringValue(body.email, 254).toLowerCase();
  const phone = stringValue(body.phone, 30);
  const message = stringValue(body.message, 2000);
  const kind = body.kind === "event" ? "event" : "general";
  if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || phone.length < 7 || !message) return NextResponse.json({ error: "Please complete each field with valid details." }, { status: 400 });
  const supabase = getAdminSupabase();
  if (!supabase) return NextResponse.json({ error: "Enquiries are not connected yet. Please email reservations@hariscourt.in." }, { status: 503 });
  const { error } = await supabase.from("enquiries").insert({ name, email, phone, message, kind, status: "new" });
  if (error) {
    console.error("Enquiry save failed", error.message);
    return NextResponse.json({ error: "We could not save your enquiry just now." }, { status: 503 });
  }
  if (process.env.RESEND_API_KEY && process.env.RESEND_FROM_EMAIL && process.env.HOTEL_RESERVATIONS_EMAIL) {
    try {
      const resend = new Resend(process.env.RESEND_API_KEY);
      await resend.emails.send({ from: process.env.RESEND_FROM_EMAIL, to: process.env.HOTEL_RESERVATIONS_EMAIL, subject: `New ${kind} enquiry from ${name}`, text: `${message}\n\n${name} · ${email} · ${phone}` });
    } catch (error) { console.error("Enquiry notification failed", error); }
  }
  return NextResponse.json({ received: true }, { status: 201 });
}

function stringValue(value: unknown, length: number) {
  return typeof value === "string" ? value.trim().replace(/[<>]/g, "").slice(0, length) : "";
}