import { NextRequest, NextResponse } from "next/server";
import { getAdminSupabase } from "@/lib/supabase/admin";
import { sendReservationEmail } from "@/lib/email";
import { todayInIndia } from "@/lib/booking-dates";
import { getSite } from "@/lib/content/service";
import { makeReference, saveReservation } from "@/lib/reservations-store";

type ReservationRow = {
  reference: string;
  room_name: string;
  property_name: string;
  total_amount_inr: number;
};

export async function POST(request: NextRequest) {
  if (Number(request.headers.get("content-length") ?? 0) > 16000) return NextResponse.json({ error: "Request is too large." }, { status: 413 });
  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  if (typeof body.website === "string" && body.website.length > 0) return NextResponse.json({ reference: "received" });
  const guestName = cleanString(body.guestName, 100);
  const guestEmail = cleanString(body.guestEmail, 254).toLowerCase();
  const guestPhone = cleanString(body.guestPhone, 30);
  const roomTypeId = cleanString(body.roomTypeId, 40);
  const property = cleanString(body.property, 20);
  const propertySlug = cleanString(body.propertySlug, 40);
  const checkIn = cleanString(body.checkIn, 10);
  const checkOut = cleanString(body.checkOut, 10);
  const guests = Number(body.guests);
  const specialRequests = cleanString(body.specialRequests, 500);
  if (!guestName || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(guestEmail) || guestPhone.length < 7 || !roomTypeId || !["gurugram", "delhi"].includes(property) || !validDates(checkIn, checkOut) || !Number.isInteger(guests) || guests < 1 || guests > 6) {
    return NextResponse.json({ error: "Please check your contact details and stay dates." }, { status: 400 });
  }
  const supabase = getAdminSupabase();
  if (!supabase) {
    // No live reservation database/payment provider yet: record the booking locally and email the guest.
    if (roomTypeId.startsWith("demo-")) {
      return NextResponse.json({ error: "This is a sample room. Add your own rooms in the dashboard to take bookings." }, { status: 400 });
    }
    return handleOfflineReservation({ guestName, guestEmail, guestPhone, roomTypeId, propertySlug, checkIn, checkOut, guests, specialRequests });
  }
  const { data, error } = await supabase.rpc("create_reservation", {
    p_room_type_id: roomTypeId,
    p_property_slug: property,
    p_check_in: checkIn,
    p_check_out: checkOut,
    p_guests: guests,
    p_guest_name: guestName,
    p_guest_email: guestEmail,
    p_guest_phone: guestPhone,
    p_special_requests: specialRequests,
  });
  if (error) {
    if (error.message.includes("SOLD_OUT")) return NextResponse.json({ error: "That room was just reserved for those dates. Please choose another room or dates." }, { status: 409 });
    console.error("Reservation creation failed", error.message);
    return NextResponse.json({ error: "We could not start your reservation. Please try again." }, { status: 503 });
  }
  const reservation = (Array.isArray(data) ? data[0] : data) as ReservationRow;
  if (!reservation?.reference) return NextResponse.json({ error: "We could not start your reservation." }, { status: 503 });
  let checkoutUrl: string | undefined;
  try {
    checkoutUrl = await createPaymentLink(reservation, { guestName, guestEmail, guestPhone });
  } catch (paymentError) {
    console.error("Razorpay checkout creation failed", paymentError);
  }
  try {
    await sendReservationEmail({
      reference: reservation.reference,
      guestName,
      guestEmail,
      propertyName: reservation.property_name,
      roomName: reservation.room_name,
      checkIn,
      checkOut,
      amount: reservation.total_amount_inr,
      specialRequests,
    }, false);
  } catch (emailError) {
    console.error("Reservation email could not be sent", emailError);
  }
  return NextResponse.json({ reference: reservation.reference, checkoutUrl: checkoutUrl ?? null, status: "pending_payment" }, { status: 201 });
}

async function handleOfflineReservation(input: {
  guestName: string; guestEmail: string; guestPhone: string; roomTypeId: string; propertySlug: string;
  checkIn: string; checkOut: string; guests: number; specialRequests: string;
}) {
  const site = await getSite();
  let prop = input.propertySlug ? site.properties.find((item) => item.slug === input.propertySlug) ?? null : null;
  let room = prop?.rooms.find((item) => item.id === input.roomTypeId) ?? null;
  if (!room) {
    for (const candidate of site.properties) {
      const match = candidate.rooms.find((item) => item.id === input.roomTypeId);
      if (match) { prop = candidate; room = match; break; }
    }
  }
  if (!prop || !room) {
    return NextResponse.json({ error: "We couldn't find that room. Please choose your room again." }, { status: 400 });
  }
  const nights = Math.max(1, Math.round((Date.parse(input.checkOut) - Date.parse(input.checkIn)) / 86400000));
  const amount = Math.max(0, room.rate) * nights;
  const propertyName = `${prop.name} ${prop.area}`.trim();
  const reference = makeReference();
  const notifyEmails = parseNotifyEmails(site.settings.reservationEmails, site.settings.contactEmail, [prop.contactEmail]);
  let emailed = false;
  try {
    emailed = await sendReservationEmail(
      { reference, guestName: input.guestName, guestEmail: input.guestEmail, propertyName, roomName: room.name, checkIn: input.checkIn, checkOut: input.checkOut, amount, specialRequests: input.specialRequests },
      false,
      notifyEmails,
    );
  } catch (emailError) {
    console.error("Reservation email could not be sent", emailError instanceof Error ? emailError.message : emailError);
  }
  const saved = await saveReservation({
    reference,
    guest_name: input.guestName,
    guest_email: input.guestEmail,
    guest_phone: input.guestPhone,
    guests: input.guests,
    special_requests: input.specialRequests,
    check_in: input.checkIn,
    check_out: input.checkOut,
    total_amount_inr: amount,
    amount_paid: 0,
    status: "pending_payment",
    created_at: new Date().toISOString(),
    room_types: { name: room.name, property_name: propertyName },
    property_slug: prop.slug,
    emailed,
  });
  return NextResponse.json({ reference, saved, emailed, offline: true }, { status: 201 });
}

async function createPaymentLink(reservation: ReservationRow, customer: { guestName: string; guestEmail: string; guestPhone: string }) {
  const keyId = process.env.RAZORPAY_KEY_ID;
  const keySecret = process.env.RAZORPAY_KEY_SECRET;
  if (!keyId || !keySecret) return undefined;
  const response = await fetch("https://api.razorpay.com/v1/payment_links", {
    method: "POST",
    headers: {
      Authorization: `Basic ${Buffer.from(`${keyId}:${keySecret}`).toString("base64")}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      amount: Math.round(reservation.total_amount_inr * 100),
      currency: "INR",
      accept_partial: false,
      reference_id: reservation.reference,
      description: `Hari's Court stay · ${reservation.reference}`,
      customer: { name: customer.guestName, email: customer.guestEmail, contact: customer.guestPhone },
      notify: { email: false, sms: false },
      reminder_enable: false,
      callback_url: `${process.env.NEXT_PUBLIC_SITE_URL ?? ""}/reservation/complete`,
      callback_method: "get",
    }),
    cache: "no-store",
  });
  const data = await response.json();
  if (!response.ok || typeof data.short_url !== "string") throw new Error(`Razorpay returned ${response.status}`);
  const { error } = await getAdminSupabase()!.from("payments").insert({
    reservation_reference: reservation.reference,
    razorpay_payment_link_id: data.id,
    amount_inr: reservation.total_amount_inr,
    currency: "INR",
    status: "created",
  });
  if (error) throw new Error("Could not save the payment record.");
  return data.short_url as string;
}

function cleanString(value: unknown, limit: number) {
  return typeof value === "string" ? value.trim().replace(/[<>]/g, "").slice(0, limit) : "";
}

// Reservation notification recipients from the dashboard settings, falling back to the contact email.
function parseNotifyEmails(raw: string, fallback: string, extra: string[] = []): string[] {
  const parsed = (raw || "").split(/[\s,;]+/).map((item) => item.trim()).filter(Boolean);
  const base = parsed.length ? parsed : fallback ? [fallback] : [];
  const list = [...extra.filter(Boolean), ...base];
  return [...new Set(list.map((item) => item.toLowerCase()))];
}

function validDates(checkIn: string, checkOut: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(checkIn) || !/^\d{4}-\d{2}-\d{2}$/.test(checkOut)) return false;
  const start = new Date(`${checkIn}T00:00:00Z`);
  const end = new Date(`${checkOut}T00:00:00Z`);
  return checkIn >= todayInIndia() && end > start && end.getTime() - start.getTime() <= 30 * 86400000;
}