import { NextResponse } from "next/server";
import { getSite } from "@/lib/content/service";

export const dynamic = "force-dynamic";

/** Public, read-only view of the published website content. Admin-only data (users, drafts) is never included. */
export async function GET() {
  const site = await getSite();
  return NextResponse.json({
    settings: site.settings,
    home: site.home,
    properties: site.properties,
    amenities: site.amenities,
    gallery: site.siteGallery,
  });
}
