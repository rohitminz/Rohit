import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Building2, ChevronRight, Mail, MapPin, Navigation, Phone, ShoppingBag, Train } from "lucide-react";
import AmenityIcon from "@/components/AmenityIcon";
import EnquiryForm from "@/components/EnquiryForm";
import HeroBookingBar from "@/components/HeroBookingBar";
import PropertyCard from "@/components/PropertyCard";
import PropertyMap from "@/components/PropertyMap";
import Reveal from "@/components/Reveal";
import RoomShowcase from "@/components/RoomShowcase";
import SiteFooter from "@/components/SiteFooter";
import SiteHeader from "@/components/SiteHeader";
import { getPropertyBySlug, seoFor, wantsPreview } from "@/lib/content/service";
import { directionsUrl } from "@/lib/properties";

export const dynamic = "force-dynamic";

const nearbyIcons = { metro: Train, hub: Building2, mall: ShoppingBag } as const;

type Props = { params: Promise<{ slug: string }>; searchParams: Promise<{ preview?: string }> };

export async function generateMetadata({ params, searchParams }: Props): Promise<Metadata> {
  const { slug } = await params;
  const { site, property } = await getPropertyBySlug(slug, { preview: await wantsPreview((await searchParams).preview) });
  if (!property) return {};
  const seo = seoFor(site, `locations/${slug}`, { title: `${property.name} ${property.location}`, description: property.summary });
  return { title: seo.title, description: seo.description, openGraph: { title: seo.title, description: seo.description, images: seo.ogImage ? [seo.ogImage] : undefined } };
}

export default async function LocationPage({ params, searchParams }: Props) {
  const { slug } = await params;
  const { site, property } = await getPropertyBySlug(slug, { preview: await wantsPreview((await searchParams).preview) });
  if (!property) notFound();
  const { settings } = site;
  const others = site.properties.filter((item) => item.slug !== property.slug);
  const gallery = property.gallery.length >= 3 ? property.gallery : [...property.gallery, ...site.siteGallery].slice(0, 6);
  const phone = property.contactPhone || settings.contactPhone;
  const email = property.contactEmail || settings.contactEmail;

  return (
    <main className="hc-page hc-page--hero">
      <SiteHeader bookHref="#booking" bookLabel={site.settings.bookCtaLabel} />
      {site.isPreview && <p className="hc-preview-banner">Previewing the unpublished draft</p>}

      <section className="hc-hero hc-hero--property" id="home" aria-label={`${property.name} ${property.location}`}>
        <div className="hc-hero-media" aria-hidden="true">
          <Image src={property.backgroundImage || property.cardImage} alt="" fill priority sizes="100vw" className={`hc-hero-img is-active${property.backgroundBlur ? " is-blur" : ""}`} />
          <div className="hc-hero-overlay" />
        </div>
        <div className="hc-hero-content">
          <div className="hc-hero-copy">
            <nav className="hc-crumb" aria-label="Breadcrumb">
              <Link href="/">Home</Link> <ChevronRight size={14} /> <Link href="/#locations">Our Locations</Link> <ChevronRight size={14} /> <span>{property.area}</span>
            </nav>
            <p className="hc-eyebrow hc-rise">{property.city}</p>
            <h1 className="hc-hero-title hc-rise" style={{ animationDelay: "0.1s" }}>
              {property.name} {property.area}
            </h1>
            <p className="hc-hero-text hc-rise" style={{ animationDelay: "0.2s" }}>
              {property.description}
            </p>
            <div className="hc-hero-actions hc-rise" style={{ animationDelay: "0.3s" }}>
              <a href="#booking" className="hc-btn hc-btn-gold">Book Now</a>
              <a href="#rooms" className="hc-btn hc-btn-ghost">View Rooms</a>
            </div>
          </div>
          <div className="hc-hero-feature hc-rise" style={{ animationDelay: "0.25s" }}>
            <Image src={property.cardImage} alt={`Hari's Court ${property.location}`} fill priority sizes="(max-width: 1000px) 0px, 380px" className="hc-feature-img is-active" />
          </div>
        </div>
        <div className="hc-hero-booking">
          <HeroBookingBar fixedProperty={property} maxGuests={settings.maxOnlineGuests} phone={settings.contactPhone} availabilityLabel={settings.availabilityCtaLabel} />
        </div>
      </section>

      <section className="hc-section hc-section-tint" id="rooms" aria-labelledby="rooms-title">
        <Reveal className="hc-section-head">
          <p className="hc-eyebrow">Rooms &amp; Suites</p>
          <h2 id="rooms-title">Rooms at {property.location}</h2>
          <p>Rates shown are starting rates. Select your dates in the booking bar for live availability.</p>
        </Reveal>
        <RoomShowcase property={property} availabilityLabel={settings.availabilityCtaLabel} />
      </section>

      <section className="hc-amenities" aria-label="Amenities">
        <div className="hc-amenities-inner">
          {site.amenities.map((amenity) => (
            <Reveal key={amenity.id} className="hc-amenity">
              <span className="hc-amenity-icon"><AmenityIcon name={amenity.icon} /></span>
              <div>
                <h3>{amenity.title}</h3>
                <p>{amenity.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {gallery.length > 0 && (
        <section className="hc-section" id="gallery" aria-labelledby="gallery-title">
          <Reveal className="hc-section-head">
            <p className="hc-eyebrow">Gallery</p>
            <h2 id="gallery-title">A look at Hari&apos;s Court {property.area}</h2>
          </Reveal>
          <div className="hc-gallery">
            {gallery.map((image, index) => (
              <Reveal key={image.id} delay={index * 60} className="hc-gallery-tile">
                <Image src={image.url} alt={image.alt || `Hari's Court ${property.location}`} fill sizes="(max-width: 700px) 100vw, (max-width: 1100px) 50vw, 400px" />
              </Reveal>
            ))}
          </div>
        </section>
      )}

      <section className="hc-section hc-section-tint" id="location" aria-labelledby="location-title">
        <div className="hc-location">
          <Reveal className="hc-location-copy">
            <p className="hc-eyebrow">Location</p>
            <h2 id="location-title">Find us in {property.area}</h2>
            <ul className="hc-nearby">
              {property.nearby.map((place) => {
                const Icon = nearbyIcons[place.icon];
                return (
                  <li key={place.label}>
                    <span className="hc-nearby-icon"><Icon size={18} /></span>
                    <span>
                      <strong>{place.label}</strong>
                      <small>{place.time}</small>
                    </span>
                  </li>
                );
              })}
            </ul>
            <a className="hc-btn hc-btn-gold" href={directionsUrl(property)} target="_blank" rel="noreferrer">
              <Navigation size={18} /> Get Directions
            </a>
          </Reveal>
          <Reveal className="hc-location-map" delay={100}>
            <PropertyMap key={property.slug} property={property} />
          </Reveal>
        </div>
      </section>

      <section className="hc-section hc-banquets hc-contact-section" id="enquiry" aria-labelledby="contact-title">
        <Reveal className="hc-contact-card">
          <p className="hc-eyebrow">Contact</p>
          <h2 id="contact-title">Hari&apos;s Court {property.area}</h2>
          <ul className="hc-contact-list">
            <li><MapPin size={18} /> {property.contactAddress || "Property address to be confirmed. Please contact us for directions."}</li>
            <li><Phone size={18} /> <a href={`tel:${phone.replace(/[^\d+]/g, "")}`}>{phone}</a></li>
            <li><Mail size={18} /> <a href={`mailto:${email}`}>{email}</a></li>
          </ul>
        </Reveal>
        <Reveal className="hc-banquet-form" delay={80}>
          <h3>Banquet &amp; event enquiry</h3>
          <EnquiryForm defaultKind="event" />
        </Reveal>
      </section>

      {others.length > 0 && (
        <section className="hc-section" aria-labelledby="others-title">
          <Reveal className="hc-section-head">
            <p className="hc-eyebrow">More from Hari&apos;s Court</p>
            <h2 id="others-title">Explore our other locations</h2>
          </Reveal>
          <div className="hc-property-grid hc-property-grid-3">
            {others.map((item, index) => (
              <Reveal key={item.slug} delay={index * 90}>
                <PropertyCard property={item} ctaLabel={settings.exploreCtaLabel} />
              </Reveal>
            ))}
          </div>
        </section>
      )}

      <SiteFooter propertySlug={property.slug} preview={site.isPreview} />
    </main>
  );
}
