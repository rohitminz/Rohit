"use client";

import { FormEvent, useState } from "react";

export default function LoginForm() {
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  async function signIn(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    const form = new FormData(event.currentTarget);
    try {
      const response = await fetch("/api/admin/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: String(form.get("username") || ""), password: String(form.get("password") || "") }),
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) { setError(result.error ?? "Sign-in failed. Check your credentials."); setBusy(false); return; }
      window.location.assign("/admin");
    } catch {
      setError("Could not reach the sign-in service. Try again.");
      setBusy(false);
    }
  }
  return <main className="login-shell"><form className="login-form" onSubmit={signIn}><span className="eyebrow">Hari&apos;s Court · Staff access</span><h1 className="serif">Welcome back</h1><label>Username<input type="text" name="username" required autoComplete="username" autoCapitalize="none" spellCheck={false} /></label><label>Password<input type="password" name="password" required autoComplete="current-password" /></label><button className="button button-gold" type="submit" disabled={busy}>{busy ? "Signing in..." : "Sign in"}</button>{error && <p role="alert">{error}</p>}</form><style jsx global>{`
    body { background: #f4f3ef; }
    .login-shell { display: grid; min-height: 100vh; place-items: center; padding: 20px; }
    .login-form { display: grid; width: min(420px, 100%); gap: 16px; padding: 38px; background: white; border: 1px solid var(--line); }
    .login-form h1 { margin: 0 0 8px; font-size: 46px; }
    .login-form label { display: grid; gap: 7px; color: #555750; font-size: 11px; font-weight: 700; }
    .login-form input { height: 44px; padding: 0 12px; border: 1px solid var(--line); background: #fbfaf7; }
    .login-form p { color: #8c3e34; font-size: 12px; line-height: 1.6; }
    @media(max-width:500px) { .login-form { padding: 27px 20px; } }
  `}</style></main>;
}