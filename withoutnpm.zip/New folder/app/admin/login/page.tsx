import LoginForm from "@/app/admin/login/LoginForm";

export default function AdminLoginPage() { return <LoginForm />; }