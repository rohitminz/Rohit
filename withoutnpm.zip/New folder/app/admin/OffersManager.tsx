"use client";

import { useMemo, useState } from "react";
import { BadgePercent, Check, Pencil, Plus, Search, Trash2, X } from "lucide-react";
import { TESTING_OFFERS, type Offer } from "@/lib/testing/dummy-data";

type PropertyOption = { slug: string; area: string; city: string };

function blankOffer(): Offer {
  return { id: `offer-${Date.now().toString(36)}`, title: "", description: "", code: "", discountLabel: "", scope: "all", active: true, validTill: "" };
}

export default function OffersManager({ properties }: { properties: PropertyOption[] }) {
  const [offers, setOffers] = useState<Offer[]>(() => TESTING_OFFERS.map(offer => ({ ...offer })));
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "active" | "inactive">("all");
  const [draft, setDraft] = useState<Offer | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const [notice, setNotice] = useState("");

  const flash = (text: string) => { setNotice(text); window.setTimeout(() => setNotice(""), 2400); };
  const scopeLabel = (scope: string) => {
    if (scope === "all") return "All properties";
    const property = properties.find(item => item.slug === scope);
    return property ? `${property.area}, ${property.city}` : scope;
  };

  const visible = useMemo(() => {
    const query = search.trim().toLowerCase();
    return offers.filter(offer => {
      if (filter === "active" && !offer.active) return false;
      if (filter === "inactive" && offer.active) return false;
      if (!query) return true;
      return `${offer.title} ${offer.code} ${offer.description}`.toLowerCase().includes(query);
    });
  }, [offers, search, filter]);

  function startNew() { setDraft(blankOffer()); setIsNew(true); }
  function startEdit(offer: Offer) { setDraft({ ...offer }); setIsNew(false); }
  function save() {
    if (!draft || !draft.title.trim() || !draft.code.trim()) return;
    setOffers(previous => (isNew ? [draft, ...previous] : previous.map(offer => (offer.id === draft.id ? draft : offer))));
    flash(isNew ? "Offer created." : "Offer updated.");
    setDraft(null);
  }
  function remove(id: string) { setOffers(previous => previous.filter(offer => offer.id !== id)); setConfirmId(null); flash("Offer deleted."); }
  function toggle(id: string) { setOffers(previous => previous.map(offer => (offer.id === id ? { ...offer, active: !offer.active } : offer))); }

  const set = (change: Partial<Offer>) => setDraft(current => (current ? { ...current, ...change } : current));
  const confirmTarget = offers.find(offer => offer.id === confirmId);

  return (
    <section className="offers-wrap">
      <div className="toolbar">
        <div className="search-field"><Search size={15} /><input type="search" value={search} onChange={event => setSearch(event.target.value)} placeholder="Search offers by name or code" aria-label="Search offers" /></div>
        <div className="filter-chips" role="group" aria-label="Filter offers">
          {(["all", "active", "inactive"] as const).map(value => <button key={value} className={filter === value ? "selected" : ""} onClick={() => setFilter(value)}>{value}</button>)}
        </div>
        <button className="pricing-publish" onClick={startNew}><Plus size={14} /> Add offer</button>
      </div>

      {notice && <p className="pricing-note ok"><Check size={14} /> {notice}</p>}

      {visible.length === 0 ? (
        <div className="admin-empty-state">
          <BadgePercent size={28} />
          <strong>{offers.length === 0 ? "No offers yet" : "No offers match your filters"}</strong>
          <span>{offers.length === 0 ? "Create a promotion to feature on the website." : "Try a different search or filter."}</span>
          {offers.length === 0 && <button className="pricing-publish" onClick={startNew}><Plus size={14} /> Add offer</button>}
        </div>
      ) : (
        <div className="admin-table-wrap">
          <table>
            <thead><tr><th>Offer</th><th>Discount</th><th>Scope</th><th>Valid till</th><th>Active</th><th>Actions</th></tr></thead>
            <tbody>
              {visible.map(offer => (
                <tr key={offer.id}>
                  <td><strong>{offer.title}</strong><span>Code: {offer.code}</span></td>
                  <td>{offer.discountLabel || "—"}</td>
                  <td>{scopeLabel(offer.scope)}</td>
                  <td>{offer.validTill || "—"}</td>
                  <td><label className="switch"><input type="checkbox" checked={offer.active} onChange={() => toggle(offer.id)} aria-label={`${offer.title} active`} /><span /></label></td>
                  <td className="row-actions">
                    <button className="admin-link" onClick={() => startEdit(offer)}><Pencil size={13} /> Edit</button>
                    <button className="admin-link danger" onClick={() => setConfirmId(offer.id)}><Trash2 size={13} /> Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {draft && (
        <div className="booking-modal" role="dialog" aria-modal="true" aria-label={isNew ? "Add offer" : "Edit offer"} onClick={() => setDraft(null)}>
          <div className="booking-dialog" onClick={event => event.stopPropagation()}>
            <header className="booking-dialog-head"><div><span className="admin-kicker">{isNew ? "NEW OFFER" : "EDIT OFFER"}</span><h2>Offer details</h2></div><button className="dialog-close" onClick={() => setDraft(null)} aria-label="Close"><X size={18} /></button></header>
            <div className="offer-form">
              <label className="offer-field wide"><span>Title</span><input value={draft.title} onChange={event => set({ title: event.target.value })} placeholder="Monsoon Escape" /></label>
              <label className="offer-field wide"><span>Description</span><textarea rows={2} value={draft.description} onChange={event => set({ description: event.target.value })} placeholder="15% off stays of 2 nights or more." /></label>
              <label className="offer-field"><span>Promo code</span><input value={draft.code} onChange={event => set({ code: event.target.value.toUpperCase() })} placeholder="MONSOON15" /></label>
              <label className="offer-field"><span>Discount label</span><input value={draft.discountLabel} onChange={event => set({ discountLabel: event.target.value })} placeholder="15% off" /></label>
              <label className="offer-field"><span>Applies to</span><select value={draft.scope} onChange={event => set({ scope: event.target.value })}><option value="all">All properties</option>{properties.map(item => <option key={item.slug} value={item.slug}>{item.area}, {item.city}</option>)}</select></label>
              <label className="offer-field"><span>Valid till</span><input type="date" value={draft.validTill} onChange={event => set({ validTill: event.target.value })} /></label>
              <label className="offer-field toggle-field"><span>Active</span><label className="switch"><input type="checkbox" checked={draft.active} onChange={event => set({ active: event.target.checked })} /><span /></label></label>
            </div>
            <footer className="booking-dialog-actions">
              <button className="pricing-publish" onClick={save} disabled={!draft.title.trim() || !draft.code.trim()}>{isNew ? "Create offer" : "Save changes"}</button>
              <button className="ghost-button" onClick={() => setDraft(null)}>Cancel</button>
              {(!draft.title.trim() || !draft.code.trim()) && <small>Title and promo code are required.</small>}
            </footer>
          </div>
        </div>
      )}

      {confirmTarget && (
        <div className="booking-modal" role="dialog" aria-modal="true" aria-label="Confirm delete" onClick={() => setConfirmId(null)}>
          <div className="booking-dialog confirm-dialog" onClick={event => event.stopPropagation()}>
            <h2>Delete offer?</h2>
            <p>“{confirmTarget.title}” will be removed. This cannot be undone.</p>
            <footer className="booking-dialog-actions">
              <button className="ghost-button danger" onClick={() => remove(confirmTarget.id)}><Trash2 size={14} /> Delete</button>
              <button className="ghost-button" onClick={() => setConfirmId(null)}>Cancel</button>
            </footer>
          </div>
        </div>
      )}
    </section>
  );
}
