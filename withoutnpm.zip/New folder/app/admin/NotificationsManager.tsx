"use client";

import { useMemo, useState } from "react";
import { Bell, Check, CircleDollarSign, Mail, Settings2, Trash2, ClipboardList } from "lucide-react";
import { TESTING_NOTIFICATIONS, type NotificationItem } from "@/lib/testing/dummy-data";

const ICONS = { booking: ClipboardList, payment: CircleDollarSign, enquiry: Mail, system: Settings2 } as const;

function timeAgo(iso: string) {
  const then = new Date(iso).getTime();
  const mins = Math.round((Date.now() - then) / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} min ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours} hr ago`;
  const days = Math.round(hours / 24);
  return `${days} day${days === 1 ? "" : "s"} ago`;
}

export default function NotificationsManager() {
  const [items, setItems] = useState<NotificationItem[]>(() => TESTING_NOTIFICATIONS.map(item => ({ ...item })));
  const [filter, setFilter] = useState<"all" | "unread">("all");

  const unread = items.filter(item => !item.read).length;
  const visible = useMemo(() => (filter === "unread" ? items.filter(item => !item.read) : items), [items, filter]);

  const markRead = (id: string) => setItems(previous => previous.map(item => (item.id === id ? { ...item, read: true } : item)));
  const markAll = () => setItems(previous => previous.map(item => ({ ...item, read: true })));
  const remove = (id: string) => setItems(previous => previous.filter(item => item.id !== id));

  return (
    <section className="offers-wrap">
      <div className="toolbar">
        <div className="filter-chips" role="group" aria-label="Filter notifications">
          <button className={filter === "all" ? "selected" : ""} onClick={() => setFilter("all")}>All ({items.length})</button>
          <button className={filter === "unread" ? "selected" : ""} onClick={() => setFilter("unread")}>Unread ({unread})</button>
        </div>
        <button className="ghost-button" onClick={markAll} disabled={unread === 0}><Check size={14} /> Mark all read</button>
      </div>

      {visible.length === 0 ? (
        <div className="admin-empty-state"><Bell size={28} /><strong>{filter === "unread" ? "No unread notifications" : "No notifications"}</strong><span>{filter === "unread" ? "You're all caught up." : "New activity will appear here."}</span></div>
      ) : (
        <div className="notif-list">
          {visible.map(item => {
            const Icon = ICONS[item.kind];
            return (
              <article className={`notif-row ${item.read ? "" : "unread"}`} key={item.id}>
                <span className={`notif-icon notif-${item.kind}`}><Icon size={15} /></span>
                <div className="notif-copy"><strong>{item.title}</strong><small>{item.detail}</small></div>
                <time>{timeAgo(item.createdAt)}</time>
                <div className="notif-actions">
                  {!item.read && <button className="admin-link" onClick={() => markRead(item.id)}>Mark read</button>}
                  <button className="admin-link danger" onClick={() => remove(item.id)} aria-label="Dismiss notification"><Trash2 size={13} /></button>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
}
