import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import AdminDashboard from "@/app/admin/AdminDashboard";

export const dynamic = "force-dynamic";

export default async function AdminPage({ searchParams }: { searchParams: Promise<{ preview?: string }> }) {
  const params = await searchParams;
  if (process.env.NODE_ENV === "development" && params.preview === "1") {
    return <AdminDashboard preview />;
  }
  if (!await getCurrentUser()) redirect("/admin/login");
  return <AdminDashboard />;
}