"use client";

import { useMemo, useState } from "react";
import { ScrollText, Search } from "lucide-react";
import { TESTING_AUDIT_LOG } from "@/lib/testing/dummy-data";

function formatAt(iso: string) {
  return new Date(iso).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", hour12: true });
}

export default function AuditLog() {
  const [search, setSearch] = useState("");

  const visible = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return TESTING_AUDIT_LOG;
    return TESTING_AUDIT_LOG.filter(event => `${event.user} ${event.action} ${event.target} ${event.detail}`.toLowerCase().includes(query));
  }, [search]);

  return (
    <section className="offers-wrap">
      <div className="toolbar">
        <div className="search-field"><Search size={15} /><input type="search" value={search} onChange={event => setSearch(event.target.value)} placeholder="Search by user, action or record" aria-label="Search audit log" /></div>
      </div>

      {visible.length === 0 ? (
        <div className="admin-empty-state"><ScrollText size={28} /><strong>No audit entries match</strong><span>Try a different search.</span></div>
      ) : (
        <div className="admin-table-wrap">
          <table>
            <thead><tr><th>When</th><th>User</th><th>Action</th><th>Record</th><th>Details</th></tr></thead>
            <tbody>
              {visible.map(event => (
                <tr key={event.id}>
                  <td>{formatAt(event.at)}</td>
                  <td><strong>{event.user}</strong></td>
                  <td>{event.action}</td>
                  <td>{event.target}</td>
                  <td>{event.detail}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <p className="pricing-hint">The audit trail is read-only. Entries are recorded automatically once backend persistence is connected.</p>
    </section>
  );
}
