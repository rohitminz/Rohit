"use client";

import { useCallback, useEffect, useState, type ReactNode } from "react";
import { Download, Eye, Plus, RefreshCw, Rocket, Save, Trash2, Undo2, Upload } from "lucide-react";
import type { HomeContent, PropertyRecord, RoomRecord, SiteContent } from "@/lib/content/schema";

type Remote = {
  published: SiteContent;
  draft: { content: SiteContent; savedAt: string; savedBy: string } | null;
  source: "workbook" | "defaults";
  storage: "local" | "graph";
};

const SECTIONS = ["Properties", "Rooms", "Amenities", "Gallery", "Homepage", "Settings & SEO", "Users"] as const;
type Section = (typeof SECTIONS)[number];
type Notice = { kind: "ok" | "error"; text: string; issues?: string[] };

const uid = (prefix: string) => `${prefix}-${Date.now().toString(36)}${Math.floor(Math.random() * 36 ** 2).toString(36)}`;

/**
 * Reads a response body as JSON, but never crashes on an HTML/empty body (e.g. an auth
 * redirect or server error page). Returns parsed JSON, or throws a readable message so the
 * user never sees a raw "Unexpected token '<'" error.
 */
async function readJson(response: Response): Promise<Record<string, unknown>> {
  const text = await response.text();
  if (!text) return {};
  try {
    return JSON.parse(text) as Record<string, unknown>;
  } catch {
    const hint =
      response.status === 401 || response.status === 403
        ? "Please sign in as an administrator and try again."
        : "The content service is unavailable. Check that you are signed in and try again.";
    throw new Error(`Unexpected response from the server (status ${response.status}). ${hint}`);
  }
}

function Field({ label, children, wide }: { label: string; children: ReactNode; wide?: boolean }) {
  return (
    <label className={`cm-field${wide ? " wide" : ""}`}>
      <span>{label}</span>
      {children}
    </label>
  );
}

function Text({ label, value, onChange, wide, max }: { label: string; value: string; onChange: (value: string) => void; wide?: boolean; max?: number }) {
  return (
    <Field label={label} wide={wide}>
      <input value={value} maxLength={max} onChange={(event) => onChange(event.target.value)} />
    </Field>
  );
}

function Area({ label, value, onChange, rows = 3 }: { label: string; value: string; onChange: (value: string) => void; rows?: number }) {
  return (
    <Field label={label} wide>
      <textarea value={value} rows={rows} onChange={(event) => onChange(event.target.value)} />
    </Field>
  );
}

function Num({ label, value, onChange }: { label: string; value: number; onChange: (value: number) => void }) {
  return (
    <Field label={label}>
      <input type="number" min={0} value={Number.isFinite(value) ? value : 0} onChange={(event) => onChange(Math.max(0, Math.round(Number(event.target.value) || 0)))} />
    </Field>
  );
}

function Toggle({ label, value, onChange }: { label: string; value: boolean; onChange: (value: boolean) => void }) {
  return (
    <label className="cm-toggle">
      <input type="checkbox" checked={value} onChange={(event) => onChange(event.target.checked)} /> {label}
    </label>
  );
}

function Pick<T extends string>({ label, value, options, onChange }: { label: string; value: T; options: readonly T[]; onChange: (value: T) => void }) {
  return (
    <Field label={label}>
      <select value={value} onChange={(event) => onChange(event.target.value as T)}>
        {options.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
    </Field>
  );
}

/** One value per line, for short string lists such as room amenities. */
function Lines({ label, value, onChange }: { label: string; value: string[]; onChange: (value: string[]) => void }) {
  return (
    <Field label={`${label} (one per line)`} wide>
      <textarea rows={Math.min(8, Math.max(3, value.length + 1))} value={value.join("\n")} onChange={(event) => onChange(event.target.value.split("\n"))} onBlur={() => onChange(value.map((line) => line.trim()).filter(Boolean))} />
    </Field>
  );
}

function ImageField({ label, value, onChange, onError }: { label: string; value: string; onChange: (value: string) => void; onError: (message: string) => void }) {
  const [busy, setBusy] = useState(false);
  async function upload(file: File | undefined) {
    if (!file) return;
    setBusy(true);
    try {
      const body = new FormData();
      body.set("file", file);
      const response = await fetch("/api/admin/upload", { method: "POST", body });
      const result = (await response.json()) as { url?: string; error?: string };
      if (!response.ok || !result.url) throw new Error(result.error ?? "Upload failed.");
      onChange(result.url);
    } catch (error) {
      onError(error instanceof Error ? error.message : "Upload failed.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="cm-image wide">
      <span className="cm-label">{label}</span>
      <div className="cm-image-row">
        {value ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={value} alt="" className="cm-thumb" />
        ) : (
          <span className="cm-thumb empty">No image</span>
        )}
        <input value={value} placeholder="/images/example.jpg or https://…" onChange={(event) => onChange(event.target.value)} aria-label={`${label} path or URL`} />
        <label className="cm-button">
          <Upload size={14} /> {busy ? "Uploading…" : "Upload"}
          <input type="file" accept="image/jpeg,image/png,image/webp" hidden disabled={busy} onChange={(event) => void upload(event.target.files?.[0])} />
        </label>
      </div>
    </div>
  );
}

function ArrayEditor<T>({ items, onChange, makeNew, render, addLabel, max = 50, removeLabel = "Remove" }: { items: T[]; onChange: (items: T[]) => void; makeNew: () => T; render: (item: T, update: (change: Partial<T>) => void, index: number) => ReactNode; addLabel: string; max?: number; removeLabel?: string }) {
  return (
    <div className="cm-list">
      {items.map((item, index) => (
        <div className="cm-row" key={index}>
          <div className="cm-grid">{render(item, (change) => onChange(items.map((current, i) => (i === index ? { ...current, ...change } : current))), index)}</div>
          <button type="button" className="cm-button danger" onClick={() => onChange(items.filter((_, i) => i !== index))} aria-label={`${removeLabel} item ${index + 1}`}>
            <Trash2 size={14} /> {removeLabel}
          </button>
        </div>
      ))}
      <button type="button" className="cm-button" disabled={items.length >= max} onClick={() => onChange([...items, makeNew()])}>
        <Plus size={14} /> {addLabel}
      </button>
    </div>
  );
}

export default function ContentManager() {
  const [remote, setRemote] = useState<Remote | null>(null);
  const [content, setContent] = useState<SiteContent | null>(null);
  const [dirty, setDirty] = useState(false);
  const [busy, setBusy] = useState("");
  const [loadError, setLoadError] = useState("");
  const [notice, setNotice] = useState<Notice | null>(null);
  const [section, setSection] = useState<Section>("Properties");
  const [propertyIndex, setPropertyIndex] = useState(0);
  const [roomScope, setRoomScope] = useState("");
  const [galleryScope, setGalleryScope] = useState("site");

  const load = useCallback(async () => {
    setLoadError("");
    try {
      const response = await fetch("/api/admin/content", { cache: "no-store" });
      const result = (await readJson(response)) as unknown as Remote & { error?: string };
      if (!response.ok) throw new Error(result.error ?? "Could not load the website content.");
      setRemote(result);
      setContent(result.draft?.content ?? result.published);
      setDirty(false);
    } catch (error) {
      setLoadError(error instanceof Error ? error.message : "Could not load the website content.");
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const edit = (change: Partial<SiteContent>) => {
    setContent((current) => (current ? { ...current, ...change } : current));
    setDirty(true);
  };
  const setHome = (change: Partial<HomeContent>) => content && edit({ home: { ...content.home, ...change } });
  const imageError = (text: string) => setNotice({ kind: "error", text });

  async function request(method: string, url: string, body?: unknown) {
    const response = await fetch(url, { method, headers: body ? { "Content-Type": "application/json" } : undefined, body: body ? JSON.stringify(body) : undefined });
    const result = (await readJson(response)) as { error?: string; issues?: string[] };
    if (!response.ok) throw Object.assign(new Error(result.error ?? "Request failed."), { issues: result.issues });
    return result;
  }

  async function run(label: string, task: () => Promise<string>) {
    setBusy(label);
    setNotice(null);
    try {
      setNotice({ kind: "ok", text: await task() });
    } catch (error) {
      setNotice({ kind: "error", text: error instanceof Error ? error.message : "Something went wrong.", issues: (error as { issues?: string[] }).issues });
    } finally {
      setBusy("");
    }
  }

  const saveDraft = async () => {
    if (!content || !remote) return;
    await request("PUT", "/api/admin/content", { content, expectedVersion: remote.published.version });
    await load();
  };

  const onSave = () => run("save", async () => (await saveDraft(), "Draft saved. The public website is unchanged until you publish."));
  const onPublish = () =>
    run("publish", async () => {
      if (!remote) return "";
      if (dirty) await saveDraft();
      await request("POST", "/api/admin/content/publish", { expectedVersion: remote.published.version });
      await load();
      return "Published. The website now shows these changes.";
    });
  const onDiscard = () =>
    run("discard", async () => {
      if (!window.confirm("Discard the saved draft and return to the published content?")) return "Nothing was discarded.";
      await request("DELETE", "/api/admin/content");
      await load();
      return "Draft discarded.";
    });
  const onPreview = () =>
    run("preview", async () => {
      if (dirty) await saveDraft();
      window.open("/?preview=1", "_blank", "noopener");
      return "Preview opened in a new tab. Only signed-in administrators can see it.";
    });

  if (loadError) return <p className="admin-error" role="alert">{loadError}</p>;
  if (!content || !remote) return <p className="admin-empty">Loading website content…</p>;

  const slugs = content.properties.map((property) => property.slug);
  const property = content.properties[Math.min(propertyIndex, content.properties.length - 1)];
  const setProperty = (change: Partial<PropertyRecord>) => edit({ properties: content.properties.map((item) => (item === property ? { ...item, ...change } : item)) });
  const changePropertySlug = (raw: string) => {
    const next = raw.trim().toLowerCase().replace(/[^a-z0-9-]/g, "-").replace(/-+/g, "-");
    const prev = property.slug;
    if (next === prev) return;
    edit({
      properties: content.properties.map((item) => (item === property ? { ...item, slug: next } : item)),
      rooms: content.rooms.map((room) => (room.propertySlug === prev ? { ...room, propertySlug: next } : room)),
      gallery: content.gallery.map((image) => (image.scope === prev ? { ...image, scope: next } : image)),
    });
  };
  const addProperty = () => {
    if (content.properties.length >= 12) {
      setNotice({ kind: "error", text: "The website supports up to 12 properties." });
      return;
    }
    const used = new Set(slugs);
    const base = uid("property");
    let slugValue = base;
    let suffix = 2;
    while (used.has(slugValue)) slugValue = `${base}-${suffix++}`;
    const next: PropertyRecord = {
      slug: slugValue,
      backendKey: "gurugram",
      order: content.properties.length + 1,
      active: false,
      name: "New property",
      area: "",
      city: "",
      location: "New property",
      summary: "",
      description: "",
      cardImage: "",
      backgroundImage: "",
      backgroundBlur: false,
      mapQuery: "",
      nearby: [],
      contactPhone: "",
      contactEmail: "",
      contactAddress: "",
    };
    const insertIndex = content.properties.length;
    edit({ properties: [...content.properties, next] });
    setPropertyIndex(insertIndex);
    setNotice({ kind: "ok", text: "New property added to the draft. Fill in its details, then Save draft and Publish to make it live." });
  };
  const deleteProperty = () => {
    if (content.properties.length <= 1) {
      setNotice({ kind: "error", text: "At least one property is required." });
      return;
    }
    const roomCount = content.rooms.filter((room) => room.propertySlug === property.slug).length;
    const galleryCount = content.gallery.filter((image) => image.scope === property.slug).length;
    const confirmed = window.confirm(
      `Delete "${property.location || property.name}"? This also removes its ${roomCount} room type(s) and ${galleryCount} gallery image(s) from the website. Existing reservations are kept in the booking system.`,
    );
    if (!confirmed) return;
    edit({
      properties: content.properties.filter((item) => item !== property),
      rooms: content.rooms.filter((room) => room.propertySlug !== property.slug),
      gallery: content.gallery.filter((image) => image.scope !== property.slug),
    });
    setPropertyIndex(0);
    setNotice({ kind: "ok", text: "Property removed from the draft. Publish to update the live website." });
  };
  const roomProperty = slugs.includes(roomScope) ? roomScope : slugs[0];
  const visibleRooms = content.rooms.map((room, index) => ({ room, index })).filter(({ room }) => room.propertySlug === roomProperty);
  const setRoom = (index: number, change: Partial<RoomRecord>) => edit({ rooms: content.rooms.map((room, i) => (i === index ? { ...room, ...change } : room)) });
  const galleryItems = content.gallery.map((image, index) => ({ image, index })).filter(({ image }) => image.scope === galleryScope);
  const unsaved = dirty ? "Unsaved changes" : remote.draft ? `Draft saved ${new Date(remote.draft.savedAt).toLocaleString("en-IN")}` : "No draft";

  return (
    <div className="cm">
      <style>{`
        .cm { display: grid; gap: 14px; }
        .cm-bar { position: sticky; top: 0; z-index: 5; display: flex; flex-wrap: wrap; align-items: center; gap: 10px; padding: 12px 14px; background: #fff; border: 1px solid #e8ebf1; border-radius: 10px; }
        .cm-bar .status { margin-right: auto; font-size: 13px; color: #475066; }
        .cm-bar .status strong { color: #111827; }
        .cm-button { display: inline-flex; align-items: center; gap: 6px; padding: 8px 12px; border: 1px solid #d5dae3; border-radius: 8px; background: #fff; color: #1f2937; font-size: 13px; cursor: pointer; }
        .cm-button:hover:not(:disabled) { border-color: #ad7b3e; color: #8f6330; }
        .cm-button:disabled { opacity: .5; cursor: not-allowed; }
        .cm-button.primary { background: #ad7b3e; border-color: #ad7b3e; color: #fff; }
        .cm-button.primary:hover:not(:disabled) { background: #8f6330; color: #fff; }
        .cm-button.danger { color: #b42318; }
        .cm-tabs { display: flex; flex-wrap: wrap; gap: 6px; }
        .cm-tabs button { padding: 8px 14px; border: 1px solid #e0e4ec; border-radius: 999px; background: #fff; font-size: 13px; cursor: pointer; }
        .cm-tabs button.active { background: #1f2937; border-color: #1f2937; color: #fff; }
        .cm-panel { display: grid; gap: 14px; padding: 16px; background: #fff; border: 1px solid #e8ebf1; border-radius: 10px; }
        .cm-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 12px; flex: 1; }
        .cm-prop-head { display: flex; flex-wrap: wrap; align-items: flex-end; gap: 12px 16px; }
        .cm-prop-head > .cm-field { flex: 0 1 280px; min-width: 220px; }
        .cm-prop-actions { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; margin-left: auto; }
        .cm-field, .cm-image { display: grid; gap: 4px; font-size: 12px; color: #475066; }
        .cm-field.wide, .cm-image.wide { grid-column: 1 / -1; }
        .cm-field input, .cm-field select, .cm-field textarea, .cm-image-row input[type=text], .cm-image-row > input { width: 100%; padding: 8px 10px; border: 1px solid #d5dae3; border-radius: 8px; background: #fff; color: #111827; font-size: 14px; }
        .cm-label { font-size: 12px; }
        .cm-image-row { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
        .cm-image-row > input { flex: 1; min-width: 200px; }
        .cm-thumb { width: 72px; height: 54px; border-radius: 8px; object-fit: cover; background: #eef1f6; }
        .cm-thumb.empty { display: grid; place-items: center; font-size: 10px; color: #8a93a5; }
        .cm-toggle { display: inline-flex; align-items: center; gap: 6px; font-size: 13px; color: #1f2937; align-self: end; padding-bottom: 8px; }
        .cm-list { display: grid; gap: 12px; }
        .cm-row { display: flex; flex-wrap: wrap; align-items: flex-start; gap: 12px; padding: 12px; border: 1px solid #edf0f4; border-radius: 10px; background: #fafbfc; }
        .cm-note { margin: 0; font-size: 13px; color: #6b7280; }
        .cm-notice { padding: 10px 14px; border-radius: 8px; font-size: 13px; }
        .cm-notice.ok { background: #ecfdf3; color: #067647; }
        .cm-notice.error { background: #fef3f2; color: #b42318; }
        .cm-notice ul { margin: 6px 0 0; padding-left: 18px; }
        .cm h3 { margin: 4px 0 0; font-size: 15px; }
      `}</style>

      <div className="cm-bar" role="toolbar" aria-label="Draft and publish">
        <span className="status">
          <strong>{unsaved}</strong> · Published version {remote.published.version} · Stored in {remote.storage === "graph" ? "OneDrive (Microsoft Graph)" : "local workbook"}
          {remote.source === "defaults" ? " · using built-in defaults" : ""}
        </span>
        <button type="button" className="cm-button" onClick={() => void load()} disabled={!!busy}>
          <RefreshCw size={14} /> Reload
        </button>
        <a className="cm-button" href="/api/admin/content/workbook">
          <Download size={14} /> Workbook
        </a>
        <button type="button" className="cm-button" onClick={() => void onDiscard()} disabled={!!busy || !remote.draft}>
          <Undo2 size={14} /> Discard draft
        </button>
        <button type="button" className="cm-button" onClick={() => void onSave()} disabled={!!busy || !dirty}>
          <Save size={14} /> {busy === "save" ? "Saving…" : "Save draft"}
        </button>
        <button type="button" className="cm-button" onClick={() => void onPreview()} disabled={!!busy || (!dirty && !remote.draft)}>
          <Eye size={14} /> Preview
        </button>
        <button type="button" className="cm-button primary" onClick={() => void onPublish()} disabled={!!busy || (!dirty && !remote.draft)}>
          <Rocket size={14} /> {busy === "publish" ? "Publishing…" : "Publish"}
        </button>
      </div>

      {notice && (
        <div className={`cm-notice ${notice.kind}`} role={notice.kind === "error" ? "alert" : "status"}>
          {notice.text}
          {notice.issues && notice.issues.length > 0 && (
            <ul>
              {notice.issues.map((issue) => (
                <li key={issue}>{issue}</li>
              ))}
            </ul>
          )}
        </div>
      )}

      <div className="cm-tabs" role="tablist">
        {SECTIONS.map((name) => (
          <button key={name} type="button" role="tab" aria-selected={section === name} className={section === name ? "active" : ""} onClick={() => setSection(name)}>
            {name}
          </button>
        ))}
      </div>

      {section === "Properties" && property && (
        <div className="cm-panel">
          <div className="cm-prop-head">
            <Field label="Property">
              <select value={propertyIndex} onChange={(event) => setPropertyIndex(Number(event.target.value))}>
                {content.properties.map((item, index) => (
                  <option key={item.slug} value={index}>
                    {item.location}
                  </option>
                ))}
              </select>
            </Field>
            <Toggle label="Shown on the website" value={property.active} onChange={(active) => setProperty({ active })} />
            <div className="cm-prop-actions">
              <button type="button" className="cm-button" onClick={addProperty}>
                <Plus size={14} /> Add property
              </button>
              <button type="button" className="cm-button danger" onClick={deleteProperty}>
                <Trash2 size={14} /> Delete property
              </button>
            </div>
          </div>
          <p className="cm-note">Page address: /locations/{property.slug}. The reservation system currently knows two booking groups (gurugram, delhi).</p>
          <div className="cm-grid">
            <Text label="Name" value={property.name} onChange={(name) => setProperty({ name })} />
            <Text label="Area" value={property.area} onChange={(area) => setProperty({ area })} />
            <Text label="City" value={property.city} onChange={(city) => setProperty({ city })} />
            <Text label="Location label" value={property.location} onChange={(location) => setProperty({ location })} />
            <Text label="Page address (slug)" value={property.slug} onChange={changePropertySlug} max={40} />
            <Num label="Order" value={property.order} onChange={(order) => setProperty({ order })} />
            <Pick label="Booking group" value={property.backendKey} options={["gurugram", "delhi"] as const} onChange={(backendKey) => setProperty({ backendKey })} />
            <Area label="Short summary (property card)" value={property.summary} onChange={(summary) => setProperty({ summary })} rows={2} />
            <Area label="Full description" value={property.description} onChange={(description) => setProperty({ description })} rows={4} />
            <ImageField label="Property card photograph" value={property.cardImage} onChange={(cardImage) => setProperty({ cardImage })} onError={imageError} />
            <ImageField label="Homepage background image" value={property.backgroundImage} onChange={(backgroundImage) => setProperty({ backgroundImage })} onError={imageError} />
            <Toggle label="Soften background (use for small or portrait photos)" value={property.backgroundBlur} onChange={(backgroundBlur) => setProperty({ backgroundBlur })} />
            <Text label="Map search (place name or address)" value={property.mapQuery} onChange={(mapQuery) => setProperty({ mapQuery })} wide />
            <Text label="Contact phone" value={property.contactPhone} onChange={(contactPhone) => setProperty({ contactPhone })} />
            <Text label="Contact email" value={property.contactEmail} onChange={(contactEmail) => setProperty({ contactEmail })} />
            <Text label="Contact address" value={property.contactAddress} onChange={(contactAddress) => setProperty({ contactAddress })} wide />
          </div>
          <h3>Nearby landmarks</h3>
          <ArrayEditor
            items={property.nearby}
            onChange={(nearby) => setProperty({ nearby })}
            addLabel="Add landmark"
            max={8}
            makeNew={() => ({ label: "", time: "", icon: "hub" as const, query: "" })}
            render={(item, update) => (
              <>
                <Text label="Label" value={item.label} onChange={(label) => update({ label })} />
                <Text label="Travel time" value={item.time} onChange={(time) => update({ time })} />
                <Pick label="Icon" value={item.icon} options={["metro", "hub", "mall"] as const} onChange={(icon) => update({ icon })} />
                <Text label="Map search" value={item.query} onChange={(query) => update({ query })} />
              </>
            )}
          />
        </div>
      )}

      {section === "Rooms" && (
        <div className="cm-panel">
          <div className="cm-grid">
            <Field label="Property">
              <select value={roomProperty} onChange={(event) => setRoomScope(event.target.value)}>
                {content.properties.map((item) => (
                  <option key={item.slug} value={item.slug}>
                    {item.location}
                  </option>
                ))}
              </select>
            </Field>
          </div>
          <p className="cm-note">Prices are starting rates shown on the website. Set “Price status” to placeholder or on-request when a rate is not confirmed. Live availability comes from the booking system.</p>
          <div className="cm-list">
            {visibleRooms.map(({ room, index }) => (
              <div className="cm-row" key={room.id}>
                <div className="cm-grid">
                  <Text label="Room name" value={room.name} onChange={(name) => setRoom(index, { name })} />
                  <Num label="Starting rate (₹ per night)" value={room.rate} onChange={(rate) => setRoom(index, { rate })} />
                  <Pick label="Price status" value={room.priceStatus} options={["configured", "placeholder", "on-request"] as const} onChange={(priceStatus) => setRoom(index, { priceStatus })} />
                  <Num label="Guests" value={room.guests} onChange={(guests) => setRoom(index, { guests: Math.max(1, guests) })} />
                  <Text label="Bed type" value={room.bed} onChange={(bed) => setRoom(index, { bed })} />
                  <Num label="Size (sq. ft.)" value={room.sqft} onChange={(sqft) => setRoom(index, { sqft })} />
                  <Num label="Order" value={room.order} onChange={(order) => setRoom(index, { order })} />
                  <Toggle label="Shown on the website" value={room.active} onChange={(active) => setRoom(index, { active })} />
                  <Area label="Description" value={room.description} onChange={(description) => setRoom(index, { description })} rows={2} />
                  <Lines label="Amenities" value={room.amenities} onChange={(amenities) => setRoom(index, { amenities })} />
                  <div className="cm-image wide">
                    <span className="cm-label">Room photographs (the first is the card image)</span>
                    <ArrayEditor<string>
                      items={room.images}
                      onChange={(images) => setRoom(index, { images })}
                      addLabel="Add photograph"
                      max={12}
                      makeNew={() => ""}
                      render={(url, _update, imageIndex) => <ImageField label={`Photograph ${imageIndex + 1}`} value={url} onChange={(value) => setRoom(index, { images: room.images.map((current, i) => (i === imageIndex ? value : current)) })} onError={imageError} />}
                    />
                  </div>
                </div>
                <button type="button" className="cm-button danger" onClick={() => window.confirm(`Remove ${room.name}?`) && edit({ rooms: content.rooms.filter((_, i) => i !== index) })}>
                  <Trash2 size={14} /> Remove room
                </button>
              </div>
            ))}
          </div>
          <button type="button" className="cm-button" onClick={() => edit({ rooms: [...content.rooms, { id: uid(roomProperty), propertySlug: roomProperty, order: visibleRooms.length + 1, active: true, name: "New room", description: "", guests: 2, bed: "", sqft: 0, amenities: [], images: [], rate: 0, priceStatus: "placeholder" }] })}>
            <Plus size={14} /> Add room
          </button>
        </div>
      )}

      {section === "Amenities" && (
        <div className="cm-panel">
          <ArrayEditor
            items={content.amenities}
            onChange={(amenities) => edit({ amenities })}
            addLabel="Add amenity"
            max={40}
            makeNew={() => ({ id: uid("amenity"), icon: "wifi" as const, title: "", text: "", order: content.amenities.length + 1 })}
            render={(item, update) => (
              <>
                <Text label="Title" value={item.title} onChange={(title) => update({ title })} />
                <Pick label="Icon" value={item.icon} options={["ac", "wifi", "dining", "housekeeping", "service", "desk", "parking", "tv"] as const} onChange={(icon) => update({ icon })} />
                <Num label="Order" value={item.order} onChange={(order) => update({ order })} />
                <Text label="Description" value={item.text} onChange={(text) => update({ text })} wide />
              </>
            )}
          />
        </div>
      )}

      {section === "Gallery" && (
        <div className="cm-panel">
          <div className="cm-grid">
            <Field label="Gallery">
              <select value={galleryScope} onChange={(event) => setGalleryScope(event.target.value)}>
                <option value="site">Website (homepage)</option>
                {content.properties.map((item) => (
                  <option key={item.slug} value={item.slug}>
                    {item.location}
                  </option>
                ))}
              </select>
            </Field>
          </div>
          <div className="cm-list">
            {galleryItems.map(({ image, index }) => (
              <div className="cm-row" key={image.id}>
                <div className="cm-grid">
                  <ImageField label="Image" value={image.url} onChange={(url) => edit({ gallery: content.gallery.map((item, i) => (i === index ? { ...item, url } : item)) })} onError={imageError} />
                  <Text label="Alt text (describe the photo)" value={image.alt} onChange={(alt) => edit({ gallery: content.gallery.map((item, i) => (i === index ? { ...item, alt } : item)) })} />
                  <Num label="Order" value={image.order} onChange={(order) => edit({ gallery: content.gallery.map((item, i) => (i === index ? { ...item, order } : item)) })} />
                </div>
                <button type="button" className="cm-button danger" onClick={() => edit({ gallery: content.gallery.filter((_, i) => i !== index) })}>
                  <Trash2 size={14} /> Remove
                </button>
              </div>
            ))}
          </div>
          <button type="button" className="cm-button" onClick={() => edit({ gallery: [...content.gallery, { id: uid("img"), scope: galleryScope, url: "", alt: "", order: galleryItems.length + 1 }] })}>
            <Plus size={14} /> Add image
          </button>
        </div>
      )}

      {section === "Homepage" && (
        <div className="cm-panel">
          <h3>Hero</h3>
          <div className="cm-grid">
            <Text label="Eyebrow" value={content.home.heroEyebrow} onChange={(heroEyebrow) => setHome({ heroEyebrow })} />
            <Text label="Heading" value={content.home.heroTitle} onChange={(heroTitle) => setHome({ heroTitle })} />
            <Text label="Subtitle" value={content.home.heroSubtitle} onChange={(heroSubtitle) => setHome({ heroSubtitle })} wide />
            <Text label="Highlights heading" value={content.home.highlightsHeading} onChange={(highlightsHeading) => setHome({ highlightsHeading })} wide />
          </div>
          <h3>About</h3>
          <div className="cm-grid">
            <Text label="Eyebrow" value={content.home.aboutEyebrow} onChange={(aboutEyebrow) => setHome({ aboutEyebrow })} />
            <Text label="Heading" value={content.home.aboutHeading} onChange={(aboutHeading) => setHome({ aboutHeading })} />
            <ImageField label="Main image" value={content.home.aboutImage} onChange={(aboutImage) => setHome({ aboutImage })} onError={imageError} />
            <ImageField label="Second image" value={content.home.aboutImageSecondary} onChange={(aboutImageSecondary) => setHome({ aboutImageSecondary })} onError={imageError} />
          </div>
          <ArrayEditor<string> items={content.home.aboutParagraphs} onChange={(aboutParagraphs) => setHome({ aboutParagraphs })} addLabel="Add paragraph" max={6} makeNew={() => ""} render={(text, _u, i) => <Area label={`Paragraph ${i + 1}`} value={text} rows={3} onChange={(value) => setHome({ aboutParagraphs: content.home.aboutParagraphs.map((p, n) => (n === i ? value : p)) })} />} />
          <h3>Rooms section</h3>
          <div className="cm-grid">
            <Text label="Heading" value={content.home.roomsHeading} onChange={(roomsHeading) => setHome({ roomsHeading })} />
            <Area label="Introduction" value={content.home.roomsIntro} onChange={(roomsIntro) => setHome({ roomsIntro })} rows={2} />
          </div>
          <h3>Banquets &amp; events</h3>
          <div className="cm-grid">
            <Text label="Eyebrow" value={content.home.banquetEyebrow} onChange={(banquetEyebrow) => setHome({ banquetEyebrow })} />
            <Text label="Heading" value={content.home.banquetHeading} onChange={(banquetHeading) => setHome({ banquetHeading })} />
            <Area label="Text" value={content.home.banquetText} onChange={(banquetText) => setHome({ banquetText })} rows={3} />
            <ImageField label="Banquet image" value={content.home.banquetImage} onChange={(banquetImage) => setHome({ banquetImage })} onError={imageError} />
          </div>
          <ArrayEditor items={content.home.eventTypes} onChange={(eventTypes) => setHome({ eventTypes })} addLabel="Add event type" max={8} makeNew={() => ({ title: "", text: "" })} render={(item, update) => (<><Text label="Title" value={item.title} onChange={(title) => update({ title })} /><Text label="Description" value={item.text} onChange={(text) => update({ text })} /></>)} />
          <h3>Offers</h3>
          <div className="cm-grid">
            <Text label="Heading" value={content.home.offersHeading} onChange={(offersHeading) => setHome({ offersHeading })} />
            <Text label="Introduction" value={content.home.offersIntro} onChange={(offersIntro) => setHome({ offersIntro })} />
          </div>
          <p className="cm-note">Only add offers you can honour; none are invented for you.</p>
          <ArrayEditor items={content.home.offers} onChange={(offers) => setHome({ offers })} addLabel="Add offer" max={8} makeNew={() => ({ id: uid("offer"), title: "", text: "", cta: "Enquire", href: "/#banquets", enabled: false })} render={(item, update) => (<><Text label="Title" value={item.title} onChange={(title) => update({ title })} /><Text label="Button label" value={item.cta} onChange={(cta) => update({ cta })} /><Text label="Button link" value={item.href} onChange={(href) => update({ href })} /><Toggle label="Shown on the website" value={item.enabled} onChange={(enabled) => update({ enabled })} /><Area label="Text" value={item.text} onChange={(text) => update({ text })} rows={2} /></>)} />
          <h3>Testimonials</h3>
          <p className="cm-note">Replace placeholder quotes with verified guest reviews only.</p>
          <div className="cm-grid"><Text label="Heading" value={content.home.testimonialsHeading} onChange={(testimonialsHeading) => setHome({ testimonialsHeading })} wide /></div>
          <ArrayEditor items={content.home.testimonials} onChange={(testimonials) => setHome({ testimonials })} addLabel="Add testimonial" max={12} makeNew={() => ({ name: "", location: "", quote: "" })} render={(item, update) => (<><Text label="Guest name" value={item.name} onChange={(name) => update({ name })} /><Text label="Location" value={item.location} onChange={(location) => update({ location })} /><Area label="Quote" value={item.quote} onChange={(quote) => update({ quote })} rows={2} /></>)} />
          <h3>Location section</h3>
          <div className="cm-grid">
            <Text label="Heading" value={content.home.locationHeading} onChange={(locationHeading) => setHome({ locationHeading })} />
            <Text label="Introduction" value={content.home.locationIntro} onChange={(locationIntro) => setHome({ locationIntro })} />
          </div>
          <h3>FAQ</h3>
          <ArrayEditor items={content.home.faqs} onChange={(faqs) => setHome({ faqs })} addLabel="Add question" max={20} makeNew={() => ({ question: "", answer: "" })} render={(item, update) => (<><Text label="Question" value={item.question} onChange={(question) => update({ question })} wide /><Area label="Answer" value={item.answer} onChange={(answer) => update({ answer })} rows={2} /></>)} />
        </div>
      )}

      {section === "Settings & SEO" && (
        <div className="cm-panel">
          <h3>Website settings</h3>
          <div className="cm-grid">
            <Text label="Site name" value={content.settings.siteName} onChange={(siteName) => edit({ settings: { ...content.settings, siteName } })} />
            <Text label="Phone" value={content.settings.contactPhone} onChange={(contactPhone) => edit({ settings: { ...content.settings, contactPhone } })} />
            <Text label="Email" value={content.settings.contactEmail} onChange={(contactEmail) => edit({ settings: { ...content.settings, contactEmail } })} />
            <Text label="Address" value={content.settings.contactAddress} onChange={(contactAddress) => edit({ settings: { ...content.settings, contactAddress } })} />
            <Text label="Reservation alert emails (comma separated)" value={content.settings.reservationEmails} onChange={(reservationEmails) => edit({ settings: { ...content.settings, reservationEmails } })} wide max={400} />
            <Text label="Instagram URL" value={content.settings.instagramUrl} onChange={(instagramUrl) => edit({ settings: { ...content.settings, instagramUrl } })} />
            <Text label="Facebook URL" value={content.settings.facebookUrl} onChange={(facebookUrl) => edit({ settings: { ...content.settings, facebookUrl } })} />
            <Text label="LinkedIn URL" value={content.settings.linkedinUrl} onChange={(linkedinUrl) => edit({ settings: { ...content.settings, linkedinUrl } })} />
            <Text label="Header “Book” button label" value={content.settings.bookCtaLabel} onChange={(bookCtaLabel) => edit({ settings: { ...content.settings, bookCtaLabel } })} />
            <Text label="Hero “Check availability” button label" value={content.settings.availabilityCtaLabel} onChange={(availabilityCtaLabel) => edit({ settings: { ...content.settings, availabilityCtaLabel } })} />
            <Text label="Property card “Explore” button label" value={content.settings.exploreCtaLabel} onChange={(exploreCtaLabel) => edit({ settings: { ...content.settings, exploreCtaLabel } })} />
            <Num label="Most guests bookable online" value={content.settings.maxOnlineGuests} onChange={(maxOnlineGuests) => edit({ settings: { ...content.settings, maxOnlineGuests: Math.max(1, maxOnlineGuests) } })} />
          </div>
          <h3>SEO</h3>
          <ArrayEditor items={content.seo} onChange={(seo) => edit({ seo })} addLabel="Add page" max={60} makeNew={() => ({ page: "", title: "", description: "", ogImage: "" })} render={(item, update) => (<><Text label="Page (home or a property slug)" value={item.page} onChange={(page) => update({ page })} /><Text label="Title" value={item.title} onChange={(title) => update({ title })} /><Area label="Description" value={item.description} onChange={(description) => update({ description })} rows={2} /><ImageField label="Share image" value={item.ogImage} onChange={(ogImage) => update({ ogImage })} onError={imageError} /></>)} />
        </div>
      )}

      {section === "Users" && (
        <div className="cm-panel">
          <p className="cm-note">This is the editorial team directory kept in the workbook. Sign-in access itself is granted in Supabase Auth by setting a user’s app_metadata role to admin.</p>
          <ArrayEditor items={content.users} onChange={(users) => edit({ users })} addLabel="Add user" max={100} makeNew={() => ({ email: "", name: "", role: "editor" as const, status: "active" as const })} render={(item, update) => (<><Text label="Email" value={item.email} onChange={(email) => update({ email })} /><Text label="Name" value={item.name} onChange={(name) => update({ name })} /><Pick label="Role" value={item.role} options={["admin", "editor", "viewer"] as const} onChange={(role) => update({ role })} /><Pick label="Status" value={item.status} options={["active", "disabled"] as const} onChange={(status) => update({ status })} /></>)} />
        </div>
      )}
    </div>
  );
}
