"use client";

import { useMemo, useState } from "react";
import { Check, RotateCcw, Save, Search } from "lucide-react";
import { TESTING_SEO, type SeoEntry } from "@/lib/testing/dummy-data";

const TITLE_MAX = 60;
const DESC_MAX = 160;

export default function SeoManager() {
  const [entries, setEntries] = useState<SeoEntry[]>(() => TESTING_SEO.map(entry => ({ ...entry })));
  const [search, setSearch] = useState("");
  const [dirty, setDirty] = useState(false);
  const [notice, setNotice] = useState("");

  const visible = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return entries;
    return entries.filter(entry => `${entry.page} ${entry.path} ${entry.title}`.toLowerCase().includes(query));
  }, [entries, search]);

  const update = (id: string, change: Partial<SeoEntry>) => {
    setEntries(previous => previous.map(entry => (entry.id === id ? { ...entry, ...change } : entry)));
    setDirty(true);
  };
  const save = () => { setDirty(false); setNotice("SEO changes saved."); window.setTimeout(() => setNotice(""), 2400); };
  const reset = () => { setEntries(TESTING_SEO.map(entry => ({ ...entry }))); setDirty(false); setNotice("Reverted to the last published SEO."); window.setTimeout(() => setNotice(""), 2400); };

  return (
    <section className="seo-wrap">
      <div className="toolbar">
        <div className="search-field"><Search size={15} /><input type="search" value={search} onChange={event => setSearch(event.target.value)} placeholder="Search pages" aria-label="Search SEO pages" /></div>
        <button className="ghost-button" onClick={reset} disabled={!dirty}><RotateCcw size={14} /> Revert</button>
        <button className="pricing-publish" onClick={save} disabled={!dirty}><Save size={14} /> Save changes</button>
      </div>

      {notice && <p className="pricing-note ok"><Check size={14} /> {notice}</p>}
      <p className="pricing-hint">Search titles stay under {TITLE_MAX} characters and meta descriptions under {DESC_MAX} for best search results. Counters turn red when exceeded.</p>

      <div className="seo-list">
        {visible.map(entry => {
          const titleOver = entry.title.length > TITLE_MAX;
          const descOver = entry.description.length > DESC_MAX;
          return (
            <article className="seo-card" key={entry.id}>
              <div className="seo-card-head"><h3>{entry.page}</h3><code>{entry.path}</code></div>
              <label className="offer-field wide">
                <span>Meta title <em className={titleOver ? "over" : ""}>{entry.title.length}/{TITLE_MAX}</em></span>
                <input value={entry.title} onChange={event => update(entry.id, { title: event.target.value })} />
              </label>
              <label className="offer-field wide">
                <span>Meta description <em className={descOver ? "over" : ""}>{entry.description.length}/{DESC_MAX}</em></span>
                <textarea rows={2} value={entry.description} onChange={event => update(entry.id, { description: event.target.value })} />
              </label>
              <div className="seo-preview"><strong>{entry.title || "Untitled page"}</strong><span className="seo-url">hariscourt.in{entry.path}</span><small>{entry.description || "No description set."}</small></div>
            </article>
          );
        })}
        {visible.length === 0 && <div className="admin-empty-state"><Search size={28} /><strong>No pages match your search</strong><span>Try a different page name or path.</span></div>}
      </div>
    </section>
  );
}
