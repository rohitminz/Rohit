"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Check, RefreshCw, Rocket, Save, Undo2 } from "lucide-react";
import type { RoomRecord, SiteContent } from "@/lib/content/schema";

type Remote = {
  published: SiteContent;
  draft: { content: SiteContent; savedAt: string; savedBy: string } | null;
  source: "workbook" | "defaults";
  storage: "local" | "graph";
};

function money(value: number) {
  return `₹${value.toLocaleString("en-IN")}`;
}

/** Pricing editor backed by the website content layer (the same source the public site reads). Edits save as a draft and only change the live site when published. */
export default function PricingManager({ propertyFilter }: { propertyFilter: string }) {
  const [remote, setRemote] = useState<Remote | null>(null);
  const [content, setContent] = useState<SiteContent | null>(null);
  const [dirty, setDirty] = useState(false);
  const [busy, setBusy] = useState("");
  const [loadError, setLoadError] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const load = useCallback(async () => {
    setLoadError("");
    try {
      const response = await fetch("/api/admin/content", { cache: "no-store" });
      const result = (await response.json()) as Remote & { error?: string };
      if (!response.ok) throw new Error(result.error ?? "Could not load pricing.");
      setRemote(result);
      setContent(result.draft?.content ?? result.published);
      setDirty(false);
    } catch (caught) {
      setLoadError(caught instanceof Error ? caught.message : "Could not load pricing.");
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const setRoom = (id: string, change: Partial<RoomRecord>) => {
    setContent(current => (current ? { ...current, rooms: current.rooms.map(room => (room.id === id ? { ...room, ...change } : room)) } : current));
    setDirty(true);
  };

  async function request(method: string, url: string, body?: unknown) {
    const response = await fetch(url, { method, headers: body ? { "Content-Type": "application/json" } : undefined, body: body ? JSON.stringify(body) : undefined });
    const result = (await response.json().catch(() => ({}))) as { error?: string; issues?: string[] };
    if (!response.ok) throw Object.assign(new Error(result.error ?? "Request failed."), { issues: result.issues });
    return result;
  }

  async function run(label: string, task: () => Promise<string>) {
    setBusy(label);
    setNotice("");
    setError("");
    try {
      setNotice(await task());
    } catch (caught) {
      const issues = (caught as { issues?: string[] }).issues;
      setError((caught instanceof Error ? caught.message : "Something went wrong.") + (issues?.length ? ` (${issues.join("; ")})` : ""));
    } finally {
      setBusy("");
    }
  }

  const saveDraft = async () => {
    if (!content || !remote) return;
    await request("PUT", "/api/admin/content", { content, expectedVersion: remote.published.version });
    await load();
  };
  const onSave = () => run("save", async () => (await saveDraft(), "Draft saved. The public website is unchanged until you publish."));
  const onPublish = () =>
    run("publish", async () => {
      if (!remote) return "";
      if (dirty) await saveDraft();
      await request("POST", "/api/admin/content/publish", { expectedVersion: remote.published.version });
      await load();
      return "Published. The website now shows these prices.";
    });
  const onDiscard = () =>
    run("discard", async () => {
      if (!window.confirm("Discard the saved draft and return to the published prices?")) return "Nothing was discarded.";
      await request("DELETE", "/api/admin/content");
      await load();
      return "Draft discarded.";
    });

  const groups = useMemo(() => {
    if (!content) return [];
    return content.properties
      .filter(property => propertyFilter === "all" || property.slug === propertyFilter)
      .slice()
      .sort((a, b) => a.order - b.order)
      .map(property => ({ property, rooms: content.rooms.filter(room => room.propertySlug === property.slug).slice().sort((a, b) => a.order - b.order) }));
  }, [content, propertyFilter]);

  if (loadError) {
    return <div className="pricing-wrap"><p className="admin-error" role="alert">{loadError}</p><p className="pricing-hint">Editing prices here uses the live website content API, which requires a signed-in administrator (or the <code>CONTENT_ADMIN_DEV_BYPASS</code> dev setting). <button className="admin-link" onClick={() => void load()}>Try again</button></p></div>;
  }
  if (!content || !remote) return <p className="admin-empty">Loading pricing…</p>;

  const hasDraft = Boolean(remote.draft);
  const publicPrice = (room: RoomRecord) => (room.priceStatus === "on-request" ? "On request" : room.rate ? `${money(room.rate)}${room.priceStatus === "placeholder" ? " (from)" : ""}` : "—");

  return (
    <section className="pricing-wrap">
      <div className="pricing-bar">
        <div className="pricing-status"><strong>{dirty ? "Unsaved changes" : hasDraft ? "Draft ready to publish" : "All prices published"}</strong><small>Published version {remote.published.version} · Stored in {remote.storage === "graph" ? "OneDrive (Microsoft Graph)" : "local workbook"}</small></div>
        <div className="pricing-actions">
          <button type="button" className="ghost-button" onClick={() => void load()} disabled={Boolean(busy)}><RefreshCw size={14} /> Reload</button>
          {hasDraft && <button type="button" className="ghost-button danger" onClick={() => void onDiscard()} disabled={Boolean(busy)}><Undo2 size={14} /> Discard draft</button>}
          <button type="button" className="ghost-button" onClick={() => void onSave()} disabled={Boolean(busy) || !dirty}><Save size={14} /> {busy === "save" ? "Saving…" : "Save draft"}</button>
          <button type="button" className="pricing-publish" onClick={() => void onPublish()} disabled={Boolean(busy) || (!dirty && !hasDraft)}><Rocket size={14} /> {busy === "publish" ? "Publishing…" : "Publish"}</button>
        </div>
      </div>

      {notice && <p className="pricing-note ok"><Check size={14} /> {notice}</p>}
      {error && <p className="admin-error" role="alert">{error}</p>}
      <p className="pricing-hint">Rates and price status come from the website content layer. Saving creates a draft; publishing updates the public property pages. Existing bookings keep their agreed price.</p>

      {groups.map(group => (
        <div className="pricing-group" key={group.property.slug}>
          <div className="pricing-group-head"><h3>{group.property.area}</h3><small>{group.property.location}</small></div>
          <div className="admin-table-wrap">
            <table>
              <thead><tr><th>Room type</th><th>Nightly rate (₹)</th><th>Price status</th><th>Shown on website</th></tr></thead>
              <tbody>
                {group.rooms.map(room => (
                  <tr key={room.id}>
                    <td><strong>{room.name}</strong>{room.active ? null : <span>Hidden on website</span>}</td>
                    <td><input className="admin-number" type="number" min={0} step={100} value={room.rate} disabled={Boolean(busy)} aria-label={`${room.name} nightly rate`} onChange={event => setRoom(room.id, { rate: Math.max(0, Math.round(Number(event.target.value) || 0)) })} /></td>
                    <td><select value={room.priceStatus} disabled={Boolean(busy)} aria-label={`${room.name} price status`} onChange={event => setRoom(room.id, { priceStatus: event.target.value as RoomRecord["priceStatus"] })}><option value="configured">Configured</option><option value="placeholder">Placeholder</option><option value="on-request">On request</option></select></td>
                    <td>{publicPrice(room)}</td>
                  </tr>
                ))}
                {group.rooms.length === 0 && <tr><td colSpan={4} className="pricing-empty">No rooms configured for this property.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      ))}
    </section>
  );
}
