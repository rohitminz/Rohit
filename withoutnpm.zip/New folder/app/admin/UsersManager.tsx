"use client";

import { useEffect, useMemo, useState } from "react";
import { Check, KeyRound, Pencil, Plus, Search, ShieldCheck, Trash2, X } from "lucide-react";
import { normalisePermissions, presetFor, ROLES, SECTIONS, type Access, type Permissions, type Role } from "@/lib/auth/permissions";

type User = {
  id: string;
  username: string;
  name: string;
  role: Role;
  permissions: Permissions;
  status: "active" | "disabled";
  createdAt: string;
  lastActive?: string;
  password?: string;
};

type Draft = {
  id: string | null;
  username: string;
  name: string;
  password: string;
  currentPassword: string;
  role: Role;
  permissions: Permissions;
  status: "active" | "disabled";
};

const ACCESS_OPTIONS: Access[] = ["none", "view", "edit"];

function blankDraft(): Draft {
  return { id: null, username: "", name: "", password: "", currentPassword: "", role: "viewer", permissions: presetFor("viewer"), status: "active" };
}

export default function UsersManager() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [search, setSearch] = useState("");
  const [draft, setDraft] = useState<Draft | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [showPw, setShowPw] = useState(false);

  const flash = (text: string) => { setNotice(text); window.setTimeout(() => setNotice(""), 2600); };

  async function reload() {
    setLoading(true);
    try {
      const response = await fetch("/api/admin/users", { cache: "no-store" });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) { setError(result.error ?? "Could not load users."); setUsers([]); }
      else { setUsers(Array.isArray(result.users) ? result.users : []); setError(""); }
    } catch {
      setError("Could not reach the user service.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { void reload(); }, []);

  const visible = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return users;
    return users.filter(user => `${user.name} ${user.username} ${user.role}`.toLowerCase().includes(query));
  }, [users, search]);

  function startNew() { setError(""); setShowPw(false); setDraft(blankDraft()); setIsNew(true); }
  function startEdit(user: User) {
    setError("");
    setShowPw(false);
    setDraft({ id: user.id, username: user.username, name: user.name, password: "", currentPassword: user.password ?? "", role: user.role, permissions: normalisePermissions(user.permissions), status: user.status });
    setIsNew(false);
  }
  const set = (change: Partial<Draft>) => setDraft(current => (current ? { ...current, ...change } : current));
  const setAccess = (section: string, access: Access) => setDraft(current => (current ? { ...current, permissions: { ...current.permissions, [section]: access } } : current));
  const applyPreset = (role: Role) => setDraft(current => (current ? { ...current, role, permissions: presetFor(role) } : current));

  async function save() {
    if (!draft) return;
    if (isNew && !/^[a-zA-Z0-9._-]{3,40}$/.test(draft.username.trim())) { setError("Username must be 3-40 letters, numbers, dot, dash or underscore."); return; }
    if (isNew && draft.password.length < 6) { setError("Set a password of at least 6 characters."); return; }
    if (!isNew && draft.password && draft.password.length < 6) { setError("New password must be at least 6 characters."); return; }
    setSaving(true);
    setError("");
    try {
      const response = await fetch("/api/admin/users", {
        method: isNew ? "POST" : "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(isNew
          ? { username: draft.username.trim(), name: draft.name.trim(), password: draft.password, role: draft.role, permissions: draft.permissions }
          : { id: draft.id, name: draft.name.trim(), role: draft.role, permissions: draft.permissions, status: draft.status, ...(draft.password ? { password: draft.password } : {}) }),
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) { setError(result.error ?? "Could not save the user."); setSaving(false); return; }
      flash(isNew ? "Official added." : "Official updated.");
      setDraft(null);
      await reload();
    } catch {
      setError("Could not save the user.");
    } finally {
      setSaving(false);
    }
  }

  async function toggleStatus(user: User) {
    try {
      const response = await fetch("/api/admin/users", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: user.id, status: user.status === "active" ? "disabled" : "active" }),
      });
      if (!response.ok) { const result = await response.json().catch(() => ({})); setError(result.error ?? "Could not update access."); return; }
      flash(user.status === "active" ? "Access disabled." : "Access enabled.");
      await reload();
    } catch { setError("Could not update access."); }
  }

  async function remove(id: string) {
    try {
      const response = await fetch("/api/admin/users", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) });
      if (!response.ok) { const result = await response.json().catch(() => ({})); setError(result.error ?? "Could not remove the user."); return; }
      flash("Official removed.");
      setConfirmId(null);
      await reload();
    } catch { setError("Could not remove the user."); }
  }

  const grantedCount = (permissions: Permissions) => SECTIONS.filter(section => permissions[section] !== "none").length;
  const confirmTarget = users.find(user => user.id === confirmId);

  return (
    <section className="offers-wrap">
      <div className="su-banner"><ShieldCheck size={16} /> <span>You are the <strong>super admin</strong>. Create officials and choose exactly which sections they see and whether they can view or edit.</span></div>
      <div className="toolbar">
        <div className="search-field"><Search size={15} /><input type="search" value={search} onChange={event => setSearch(event.target.value)} placeholder="Search by name, username or role" aria-label="Search officials" /></div>
        <button className="pricing-publish" onClick={startNew}><Plus size={14} /> Add official</button>
      </div>

      {notice && <p className="pricing-note ok"><Check size={14} /> {notice}</p>}
      {error && !draft && <p className="pricing-note err"><X size={14} /> {error}</p>}

      {loading ? <p className="pricing-note">Loading officials…</p>
        : visible.length === 0 ? (
          <div className="admin-empty-state">
            <ShieldCheck size={28} />
            <strong>{users.length === 0 ? "No officials yet" : "No officials match your search"}</strong>
            <span>{users.length === 0 ? "Add managers, editors or viewers and control what each can access." : "Try a different search."}</span>
            {users.length === 0 && <button className="pricing-publish" onClick={startNew}><Plus size={14} /> Add official</button>}
          </div>
        ) : (
          <div className="admin-table-wrap">
            <table>
              <thead><tr><th>Official</th><th>Role</th><th>Sections</th><th>Last active</th><th>Access</th><th>Actions</th></tr></thead>
              <tbody>{visible.map(user => <tr key={user.id}>
                <td><strong>{user.name}</strong><span>@{user.username}</span></td>
                <td className="role-cell">{user.role}</td>
                <td>{grantedCount(user.permissions)} of {SECTIONS.length}</td>
                <td>{user.lastActive ? new Date(user.lastActive).toLocaleString("en-IN", { timeZone: "Asia/Kolkata" }) : "—"}</td>
                <td><label className="switch"><input type="checkbox" aria-label={`${user.name} access`} checked={user.status === "active"} onChange={() => void toggleStatus(user)} /><span /></label></td>
                <td className="row-actions"><button className="admin-link" onClick={() => startEdit(user)}><Pencil size={13} /> Edit</button><button className="admin-link danger" onClick={() => setConfirmId(user.id)}><Trash2 size={13} /> Delete</button></td>
              </tr>)}</tbody>
            </table>
          </div>
        )}

      {draft && <div className="booking-modal" role="dialog" aria-modal="true" aria-label={isNew ? "Add official" : "Edit official"} onClick={() => setDraft(null)}>
        <div className="booking-dialog su-dialog" onClick={event => event.stopPropagation()}>
          <header className="booking-dialog-head"><div><span className="admin-kicker">{isNew ? "NEW OFFICIAL" : "EDIT OFFICIAL"}</span><h2>{isNew ? "Add official" : draft.name || draft.username}</h2></div><button className="dialog-close" onClick={() => setDraft(null)} aria-label="Close"><X size={18} /></button></header>
          <div className="offer-form">
            <label className="offer-field"><span>Full name</span><input value={draft.name} onChange={event => set({ name: event.target.value })} placeholder="Jane Doe" /></label>
            <label className="offer-field"><span>Username</span><input value={draft.username} onChange={event => set({ username: event.target.value })} placeholder="jane" disabled={!isNew} autoCapitalize="none" spellCheck={false} /></label>
            <label className="offer-field"><span>{isNew ? "Password" : "Reset password (optional)"}</span><input type="password" value={draft.password} onChange={event => set({ password: event.target.value })} placeholder={isNew ? "At least 6 characters" : "Leave blank to keep current"} autoComplete="new-password" /></label>
            {!isNew && <label className="offer-field"><span>Current password</span><span className="su-current-pw">{showPw ? (draft.currentPassword || "— not available —") : "••••••••"}<button type="button" className="admin-link" onClick={() => setShowPw(value => !value)}>{showPw ? "Hide" : "Show"}</button></span></label>}
            <label className="offer-field"><span>Role preset</span><select value={draft.role} onChange={event => applyPreset(event.target.value as Role)}>{ROLES.map(role => <option key={role} value={role}>{role}</option>)}</select></label>
          </div>
          <div className="perm-head"><KeyRound size={14} /> <strong>Section access</strong><small>Pick a role preset, then fine-tune any section.</small></div>
          <div className="perm-grid">{SECTIONS.map(section => <div className="perm-row" key={section}>
            <span>{section}</span>
            <div className="perm-choices" role="group" aria-label={`${section} access`}>{ACCESS_OPTIONS.map(option => <button key={option} type="button" className={`perm-chip ${draft.permissions[section] === option ? `is-${option}` : ""}`} onClick={() => setAccess(section, option)}>{option}</button>)}</div>
          </div>)}</div>
          {error && <p className="pricing-note err"><X size={14} /> {error}</p>}
          <footer className="booking-dialog-actions">
            <button className="pricing-publish" onClick={save} disabled={saving}>{saving ? "Saving…" : isNew ? "Create official" : "Save changes"}</button>
            <button className="ghost-button" onClick={() => setDraft(null)}>Cancel</button>
          </footer>
        </div>
      </div>}

      {confirmTarget && <div className="booking-modal" role="dialog" aria-modal="true" aria-label="Confirm remove" onClick={() => setConfirmId(null)}>
        <div className="booking-dialog confirm-dialog" onClick={event => event.stopPropagation()}>
          <h2>Remove {confirmTarget.name}?</h2>
          <p>@{confirmTarget.username} will lose all access to the dashboard. This cannot be undone.</p>
          <footer className="booking-dialog-actions">
            <button className="ghost-button danger" onClick={() => void remove(confirmTarget.id)}><Trash2 size={14} /> Remove</button>
            <button className="ghost-button" onClick={() => setConfirmId(null)}>Cancel</button>
          </footer>
        </div>
      </div>}

      <style jsx global>{`
        .su-banner { display: flex; align-items: center; gap: 8px; margin: 0 0 14px; padding: 11px 14px; border-radius: 10px; background: #f0e9fb; color: #5a3aa0; font-size: 13px; }
        .pricing-note.err { color: #c0392b; }
        .role-cell { text-transform: capitalize; }
        .su-dialog { width: min(640px, 100%); max-height: 88vh; overflow-y: auto; }
        .perm-head { display: flex; align-items: center; gap: 7px; margin: 6px 0 10px; color: #4a2f86; }
        .perm-head small { color: #948aac; font-weight: 400; margin-left: auto; }
        .perm-grid { display: grid; gap: 6px; margin: 0 0 16px; }
        .perm-row { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 7px 10px; border: 1px solid #ece4f8; border-radius: 9px; background: #faf7ff; }
        .perm-row > span { font-size: 13px; color: #39334a; }
        .perm-choices { display: inline-flex; gap: 4px; }
        .perm-chip { padding: 5px 12px; border: 1px solid #e3d7f4; border-radius: 999px; background: #fff; color: #8a81a4; font-size: 12px; text-transform: capitalize; cursor: pointer; }
        .perm-chip.is-none { background: #eceaf0; color: #6a6479; border-color: #ded9e6; }
        .perm-chip.is-view { background: #e9eefc; color: #3a5bd0; border-color: #cdd8f7; }
        .perm-chip.is-edit { background: #e7f7ef; color: #13a775; border-color: #c3ecd8; }
        .su-current-pw { display: inline-flex; align-items: center; justify-content: space-between; gap: 10px; padding: 9px 11px; border: 1px solid #e3d7f4; border-radius: 8px; background: #faf7ff; color: #39334a; font-size: 13px; font-family: monospace; }
        .su-current-pw .admin-link { font-family: inherit; font-size: 11px; }
      `}</style>
    </section>
  );
}

