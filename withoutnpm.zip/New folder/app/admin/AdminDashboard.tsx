﻿"use client";

import BrandLogo from "@/components/BrandLogo";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowDownRight, ArrowRight, ArrowUpRight, BadgePercent, Bell, BedDouble, Building2, CalendarDays,
  Check, CheckCircle2, ChevronLeft, ChevronRight, CircleDollarSign, ClipboardList, Clock3, CreditCard, DoorOpen,
  Download, Gauge, Globe, History, LayoutDashboard, LogOut, Mail, MapPin, Menu, PanelLeftClose, PanelLeftOpen, Paperclip, Pencil, Plus,
  BarChart3, RefreshCw, RotateCcw, ScrollText, Search, Settings as SettingsIcon, Tag, Trash2, TrendingUp, User, Users, Wallet, X, XCircle,
} from "lucide-react";
import ContentManager from "./ContentManager";
import PricingManager from "./PricingManager";
import OffersManager from "./OffersManager";
import UsersManager from "./UsersManager";
import SeoManager from "./SeoManager";
import NotificationsManager from "./NotificationsManager";
import LoginHistory from "./LoginHistory";
import AuditLog from "./AuditLog";
import { todayInIndia } from "@/lib/booking-dates";
import { emptyAdminData, ENQUIRY_STATUSES, STAFF_NAMES, TESTING_DATA_ENABLED, type AdminData } from "@/lib/testing/dummy-data";
import { applyChange, loadTestingData, persistTestingData, resetTestingData, roomHasBookings } from "@/lib/testing/store";
import { canEdit as hasEdit, canView as hasView, type Permissions } from "@/lib/auth/permissions";

type CurrentUser = { id: string; username: string; name: string; role: string; isSuper: boolean; permissions: Permissions };

type Reservation = AdminData["reservations"][number];
type Enquiry = AdminData["enquiries"][number];
type Room = AdminData["rooms"][number];
type Guest = AdminData["guests"][number];
type BookingDraft = { property: string; roomName: string; guestName: string; guestEmail: string; guestPhone: string; checkIn: string; checkOut: string; guests: number; status: string; amountPaid: number };

const navigation = [
  { tab: "Overview", icon: LayoutDashboard, group: "Overview" },
  { tab: "Reports", icon: BarChart3, group: "Overview" },
  { tab: "Bookings", icon: ClipboardList, group: "Hotel operations" },
  { tab: "Calendar", icon: CalendarDays, group: "Hotel operations" },
  { tab: "Rooms", icon: BedDouble, group: "Hotel operations" },
  { tab: "Pricing", icon: Tag, group: "Hotel operations" },
  { tab: "Guests", icon: Users, group: "Hotel operations" },
  { tab: "Payments", icon: CreditCard, group: "Hotel operations" },
  { tab: "Enquiries", icon: Mail, group: "Hotel operations" },
  { tab: "Website content", icon: Globe, group: "Website" },
  { tab: "Offers", icon: BadgePercent, group: "Website" },
  { tab: "SEO", icon: Gauge, group: "Website" },
  { tab: "Users", icon: Users, group: "Administration" },
  { tab: "Notifications", icon: Bell, group: "Administration" },
  { tab: "Login history", icon: History, group: "Administration" },
  { tab: "Audit log", icon: ScrollText, group: "Administration" },
  { tab: "Settings", icon: SettingsIcon, group: "Account" },
] as const;
type Tab = typeof navigation[number]["tab"];
const NAV_GROUPS = ["Overview", "Hotel operations", "Website", "Administration", "Account"] as const;
const GROUP_LABELS: Record<string, string> = { "Overview": "OVERVIEW", "Hotel operations": "HOTEL OPERATIONS", "Website": "WEBSITE", "Administration": "ADMINISTRATION", "Account": "ACCOUNT" };
const TAB_META: Record<string, { kicker: string; title: string; desc: string }> = {
  "Overview": { kicker: "OVERVIEW & PERFORMANCE", title: "Dashboard Hotel", desc: "A clear view of today\u2019s hotel activity." },
  "Reports": { kicker: "ANALYTICS", title: "Reports", desc: "Revenue, bookings and occupancy trends for the selected period." },
  "Bookings": { kicker: "HOTEL OPERATIONS", title: "Bookings", desc: "Search, filter and manage reservations across all Hari\u2019s Court properties." },
  "Calendar": { kicker: "HOTEL OPERATIONS", title: "Availability Calendar", desc: "Room availability by day, derived from live reservations." },
  "Rooms": { kicker: "HOTEL OPERATIONS", title: "Rooms", desc: "Manage room types, nightly rates and live inventory." },
  "Pricing": { kicker: "HOTEL OPERATIONS", title: "Pricing Management", desc: "Edit nightly rates per property. Save a draft, then publish to update the public website." },
  "Guests": { kicker: "HOTEL OPERATIONS", title: "Guests", desc: "Guest directory built from reservation history." },
  "Payments": { kicker: "HOTEL OPERATIONS", title: "Payments", desc: "Payment ledger and collection summary for the selected period." },
  "Enquiries": { kicker: "HOTEL OPERATIONS", title: "Enquiries", desc: "Customer enquiries from across all Hari\u2019s Court properties." },
  "Website content": { kicker: "WEBSITE", title: "Website content", desc: "Edit property photos, rooms, prices, amenities and homepage text. Save a draft, preview it, then publish." },
  "Offers": { kicker: "WEBSITE", title: "Offers & Promotions", desc: "Create and manage promotional offers shown across the website." },
  "SEO": { kicker: "WEBSITE", title: "SEO Management", desc: "Edit search titles and meta descriptions for each public page." },
  "Users": { kicker: "ADMINISTRATION", title: "Users & Roles", desc: "Manage who can access the dashboard and what they can do." },
  "Notifications": { kicker: "ADMINISTRATION", title: "Notifications", desc: "Activity alerts for bookings, payments and enquiries." },
  "Login history": { kicker: "ADMINISTRATION", title: "Login History", desc: "Recent sign-in activity for dashboard accounts." },
  "Audit log": { kicker: "ADMINISTRATION", title: "Audit Log", desc: "A record of changes made in the dashboard." },
  "Settings": { kicker: "ACCOUNT", title: "Settings", desc: "Dashboard preferences and account details." },
};
const NO_PERIOD_TABS = new Set(["Website content", "Settings", "Calendar", "Rooms", "Pricing", "Offers", "Users", "SEO", "Notifications", "Login history", "Audit log"]);
const NON_DATA_TABS = new Set(["Website content", "Settings", "Offers", "Users", "SEO", "Notifications", "Login history", "Audit log"]);
type Period = "Today" | "This week" | "This month" | "This year" | "Custom";
type DateRange = { from: string; to: string };

function addDays(date: string, amount: number) {
  const value = new Date(`${date}T00:00:00Z`);
  value.setUTCDate(value.getUTCDate() + amount);
  return value.toISOString().slice(0, 10);
}

function escapeRegExp(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function isEmailValid(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
}

function formatMoney(amount: number) {
  return `₹${amount.toLocaleString("en-IN")}`;
}

function formatPeriodDate(date: string) {
  return new Intl.DateTimeFormat("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
    timeZone: "UTC",
  }).format(new Date(`${date}T12:00:00Z`));
}

function isInRange(value: string, range: DateRange) {
  const date = value.slice(0, 10);
  return date >= range.from && date <= range.to;
}

export default function AdminDashboard({ preview = false }: { preview?: boolean }) {
  const [tab, setTab] = useState<Tab>("Overview");
  const [currentUser, setCurrentUser] = useState<CurrentUser | null>(null);
  const [data, setData] = useState<AdminData | null>(null);
  const localRefs = useRef<Set<string>>(new Set());
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState<Period>("Today");
  const [range, setRange] = useState<DateRange>(() => ({ from: todayInIndia(), to: todayInIndia() }));
  const [localTime, setLocalTime] = useState("--:--:--");
  const [localDate, setLocalDate] = useState("");
  const [properties, setProperties] = useState<{ slug: string; name: string; area: string; city: string; location: string; cardImage: string; backendKey: string; rooms: { id: string; name: string; rate: number; priceStatus: string }[] }[]>([]);
  const [collapsed, setCollapsed] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [propertyFilter, setPropertyFilter] = useState("all");
  const [bookingSearch, setBookingSearch] = useState("");
  const [bookingStatus, setBookingStatus] = useState("all");
  const [selectedBooking, setSelectedBooking] = useState<Reservation | null>(null);
  const [chargeLabel, setChargeLabel] = useState("");
  const [chargeAmount, setChargeAmount] = useState("");
  const [chargeImage, setChargeImage] = useState("");
  const [chargeUploading, setChargeUploading] = useState(false);
  const [payAmount, setPayAmount] = useState("");
  const [payNote, setPayNote] = useState("");
  const [confirmCheckout, setConfirmCheckout] = useState<Reservation | null>(null);
  const [guestSearch, setGuestSearch] = useState("");
  const [roomSearch, setRoomSearch] = useState("");
  const [roomStatusFilter, setRoomStatusFilter] = useState("all");
  const [roomDraft, setRoomDraft] = useState<Room | null>(null);
  const [roomDraftNew, setRoomDraftNew] = useState(false);
  const [confirmRoomId, setConfirmRoomId] = useState<string | null>(null);
  const [enquirySearch, setEnquirySearch] = useState("");
  const [enquiryStatusFilter, setEnquiryStatusFilter] = useState("all");
  const [selectedEnquiry, setSelectedEnquiry] = useState<Enquiry | null>(null);
  const [confirmEnquiryId, setConfirmEnquiryId] = useState<string | null>(null);
  const [guestDraft, setGuestDraft] = useState<Guest | null>(null);
  const [guestDraftNew, setGuestDraftNew] = useState(false);
  const [confirmGuestId, setConfirmGuestId] = useState<string | null>(null);
  const [selectedGuest, setSelectedGuest] = useState<Guest | null>(null);
  const [bookingDraft, setBookingDraft] = useState<BookingDraft | null>(null);
  const [calendarMonth, setCalendarMonth] = useState(() => todayInIndia().slice(0, 7));
  const [compact, setCompact] = useState(false);
  const [savedNote, setSavedNote] = useState("");
  const [toast, setToast] = useState<{ text: string; tone: "error" | "ok" } | null>(null);
  const toastTimer = useRef<number | null>(null);
  const showToast = (text: string, tone: "error" | "ok" = "error") => {
    setToast({ text, tone });
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 3800);
  };
  const denyAccess = () => showToast("You don't have permission to do this. Please contact your administrator.");
  // Account / own-password self-service.
  const [revealedPassword, setRevealedPassword] = useState<string | null>(null);
  const [pwCurrent, setPwCurrent] = useState("");
  const [pwNext, setPwNext] = useState("");
  const [pwConfirm, setPwConfirm] = useState("");
  const [pwBusy, setPwBusy] = useState(false);
  const [pwMsg, setPwMsg] = useState("");
  const [pwErr, setPwErr] = useState("");
  async function revealMyPassword() {
    if (revealedPassword !== null) { setRevealedPassword(null); return; }
    try {
      const response = await fetch("/api/admin/auth/reveal", { cache: "no-store" });
      const result = await response.json().catch(() => ({}));
      setRevealedPassword(response.ok ? (result.password || "") : "");
    } catch {
      setRevealedPassword("");
    }
  }
  async function changeMyPassword() {
    setPwErr(""); setPwMsg("");
    if (pwNext.length < 6) { setPwErr("New password must be at least 6 characters."); return; }
    if (pwNext !== pwConfirm) { setPwErr("New password and confirmation do not match."); return; }
    setPwBusy(true);
    try {
      const response = await fetch("/api/admin/auth/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword: pwCurrent, newPassword: pwNext }),
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) { setPwErr(result.error ?? "Could not change your password."); setPwBusy(false); return; }
      setPwMsg("Password updated.");
      setPwCurrent(""); setPwNext(""); setPwConfirm(""); setRevealedPassword(null);
    } catch {
      setPwErr("Could not change your password.");
    } finally {
      setPwBusy(false);
    }
  }
  // Wraps an action so no-access users get the permission toast instead of the action running.
  const guarded = (action: () => void) => () => { if (canEditCurrent) action(); else denyAccess(); };
  const today = todayInIndia();
  const selectTab = (next: Tab) => { setTab(next); setMobileNavOpen(false); };

  // Access control: the super admin (and preview mode) sees everything; officials see only permitted sections.
  const fullAccess = preview || currentUser?.isSuper === true;
  const allowedNav = useMemo(() => navigation.filter(item => {
    if (item.tab === "Users") return fullAccess; // user management is super-admin only
    if (item.tab === "Settings") return true; // personal account & password are always available
    if (fullAccess || !currentUser) return true;
    return hasView(currentUser.permissions, item.tab);
  }), [fullAccess, currentUser]);
  const canEditTab = (section: string) => fullAccess || !currentUser || hasEdit(currentUser.permissions, section);
  const canEditCurrent = canEditTab(tab);
  useEffect(() => {
    if (allowedNav.length && !allowedNav.some(item => item.tab === tab)) setTab(allowedNav[0].tab);
  }, [allowedNav, tab]);

  const applyLocalReservations = (local: AdminData["reservations"]) => {
    if (!local.length) return;
    setData(current => {
      if (!current) return current;
      const existing = new Set(current.reservations.map(reservation => reservation.reference));
      const fresh = local.filter(reservation => !existing.has(reservation.reference));
      return fresh.length ? { ...current, reservations: [...fresh, ...current.reservations] } : current;
    });
  };

  async function fetchLocalReservations(): Promise<AdminData["reservations"]> {
    try {
      const response = await fetch("/api/admin/reservations", { cache: "no-store" });
      if (!response.ok) return [];
      const json = await response.json();
      const list = Array.isArray(json.reservations) ? json.reservations : [];
      list.forEach((reservation: { reference: string }) => localRefs.current.add(reservation.reference));
      return list;
    } catch {
      return [];
    }
  }

  async function load() {
    setLoading(true);
    try {
      const response = await fetch("/api/admin", { cache: "no-store" });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) {
        // No live backend connected (e.g. Supabase absent): run on the local working dataset.
        setData(TESTING_DATA_ENABLED ? loadTestingData(todayInIndia()) : emptyAdminData());
        setError("");
        applyLocalReservations(await fetchLocalReservations());
      } else {
        setData(result);
        setError("");
        applyLocalReservations(await fetchLocalReservations());
      }
    } catch {
      setData(TESTING_DATA_ENABLED ? loadTestingData(todayInIndia()) : emptyAdminData());
      setError("");
      applyLocalReservations(await fetchLocalReservations());
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (preview) {
      setData(TESTING_DATA_ENABLED ? loadTestingData(todayInIndia()) : emptyAdminData());
      setLoading(false);
      void fetchLocalReservations().then(applyLocalReservations);
      return;
    }
    void load();
  }, [preview]);

  // Load the signed-in user's role + section permissions so the dashboard can gate access.
  useEffect(() => {
    let active = true;
    fetch("/api/admin/auth/session", { cache: "no-store" })
      .then(response => (response.ok ? response.json() : null))
      .then(result => { if (active && result?.user) setCurrentUser(result.user as CurrentUser); })
      .catch(() => {});
    return () => { active = false; };
  }, []);

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setLocalTime(new Intl.DateTimeFormat("en-IN", { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false, timeZone: "Asia/Kolkata" }).format(now));
      setLocalDate(new Intl.DateTimeFormat("en-IN", { weekday: "long", day: "2-digit", month: "long", year: "numeric", timeZone: "Asia/Kolkata" }).format(now));
    };
    updateClock();
    const timer = window.setInterval(updateClock, 1000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    let active = true;
    fetch("/api/content", { cache: "no-store" })
      .then(response => (response.ok ? response.json() : null))
      .then(result => { if (active && result?.properties) setProperties(result.properties); })
      .catch(() => {});
    return () => { active = false; };
  }, []);

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem("hc-admin-prefs");
      if (!stored) return;
      const prefs = JSON.parse(stored) as { compact?: boolean; period?: Exclude<Period, "Custom"> };
      if (prefs.compact) setCompact(true);
      if (prefs.period && prefs.period !== "Today") choosePeriod(prefs.period);
    } catch {}
  }, []);

  function savePreferences(next: { compact?: boolean; period?: Exclude<Period, "Custom"> }) {
    try {
      const current = JSON.parse(window.localStorage.getItem("hc-admin-prefs") ?? "{}");
      const merged = { ...current, ...next };
      window.localStorage.setItem("hc-admin-prefs", JSON.stringify(merged));
      setSavedNote("Preferences saved.");
      window.setTimeout(() => setSavedNote(""), 2400);
    } catch {}
  }

  function choosePeriod(value: Exclude<Period, "Custom">) {
    const current = todayInIndia();
    let from = current;
    if (value === "This week") {
      const weekday = new Date(`${current}T00:00:00Z`).getUTCDay();
      from = addDays(current, -((weekday + 6) % 7));
    } else if (value === "This month") from = `${current.slice(0, 8)}01`;
    else if (value === "This year") from = `${current.slice(0, 4)}-01-01`;
    setPeriod(value);
    setRange({ from, to: current });
  }

  async function update(entity: string, id: string, changes: Record<string, unknown>) {
    if (!canEditCurrent) { denyAccess(); return; }
    if (entity === "reservation" && localRefs.current.has(id)) {
      // Website booking stored locally: persist the status/amount change to the file store.
      try {
        const response = await fetch("/api/admin/reservations", {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            reference: id,
            ...(changes.status !== undefined ? { status: changes.status } : {}),
            ...(changes.amount_paid !== undefined ? { amountPaid: changes.amount_paid } : {}),
            ...(changes.charges !== undefined ? { charges: changes.charges } : {}),
            ...(changes.payments !== undefined ? { payments: changes.payments } : {}),
          }),
        });
        if (!response.ok) {
          const result = await response.json().catch(() => ({}));
          setError(result.error ?? "Could not update this booking.");
          return;
        }
      } catch {
        setError("Could not update this booking.");
        return;
      }
      setData(current => (current ? { ...current, reservations: current.reservations.map(reservation => (reservation.reference === id ? { ...reservation, ...changes } : reservation)) } : current));
      setSavedNote("Booking updated.");
      window.setTimeout(() => setSavedNote(""), 2000);
      return;
    }
    // Local working dataset: mutate and persist to localStorage so edits survive a refresh.
    setData(current => {
      if (!current) return current;
      const next = applyChange(current, entity, id, changes);
      persistTestingData(next);
      return next;
    });
    setSavedNote("Change saved.");
    window.setTimeout(() => setSavedNote(""), 2000);
  }

  function resetTestData() {
    if (!window.confirm("Reset all test data to its original sample values? Your test edits will be cleared.")) return;
    setData(resetTestingData(todayInIndia()));
    setSavedNote("Test data reset to original sample values.");
    window.setTimeout(() => setSavedNote(""), 2600);
  }

  const flashSaved = (text: string) => { setSavedNote(text); window.setTimeout(() => setSavedNote(""), 2200); };
  function commit(mutator: (current: AdminData) => AdminData) {
    if (!canEditCurrent) { denyAccess(); return; }
    setData(current => {
      if (!current) return current;
      const next = mutator(current);
      persistTestingData(next);
      return next;
    });
  }
  function startAddRoom() {
    const target = activeProperty ?? properties[0];
    setRoomDraft({ id: `room-${Date.now().toString(36)}`, property_name: target ? target.location : "Cyber City, Gurugram", name: "", rate_inr: 0, inventory: 0, active: true });
    setRoomDraftNew(true);
  }
  function saveRoomDraft() {
    if (!roomDraft || !roomDraft.name.trim()) return;
    const clean = { ...roomDraft, rate_inr: Math.max(0, Math.round(roomDraft.rate_inr || 0)), inventory: Math.max(0, Math.round(roomDraft.inventory || 0)) };
    commit(current => (current.rooms.some(room => room.id === clean.id) ? applyChange(current, "room", clean.id, clean) : applyChange(current, "room:add", clean.id, clean)));
    flashSaved(roomDraftNew ? "Room type added." : "Room type updated.");
    setRoomDraft(null);
  }
  function deleteRoom(room: Room) {
    commit(current => applyChange(current, "room:delete", room.id, {}));
    setConfirmRoomId(null);
    flashSaved("Room type deleted.");
  }
  function deleteEnquiry(id: string) {
    commit(current => applyChange(current, "enquiry:delete", id, {}));
    setConfirmEnquiryId(null);
    setSelectedEnquiry(null);
    flashSaved("Enquiry deleted.");
  }
  function startAddGuest() { setGuestDraft({ id: `gst-${Date.now().toString(36)}`, name: "", email: "", phone: "", city: "" }); setGuestDraftNew(true); }
  function saveGuestDraft() {
    if (!guestDraft || !guestDraft.name.trim() || !isEmailValid(guestDraft.email)) return;
    const duplicate = (data?.guests ?? []).some(guest => guest.id !== guestDraft.id && guest.email.trim().toLowerCase() === guestDraft.email.trim().toLowerCase());
    if (duplicate) { flashSaved("A guest with that email already exists."); return; }
    commit(current => (current.guests.some(guest => guest.id === guestDraft.id) ? applyChange(current, "guest", guestDraft.id, guestDraft) : applyChange(current, "guest:add", guestDraft.id, guestDraft)));
    flashSaved(guestDraftNew ? "Guest added." : "Guest updated.");
    setGuestDraft(null);
  }
  function deleteGuest(id: string) {
    commit(current => applyChange(current, "guest:delete", id, {}));
    setConfirmGuestId(null);
    setSelectedGuest(null);
    flashSaved("Guest removed.");
  }
  function startCreateBooking() {
    const target = activeProperty ?? properties[0];
    setBookingDraft({ property: target ? target.location : "", roomName: "", guestName: "", guestEmail: "", guestPhone: "", checkIn: today, checkOut: addDays(today, 1), guests: 2, status: "pending_payment", amountPaid: 0 });
  }
  async function createBooking() {
    if (!bookingDraft || !data) return;
    if (!canEditTab("Bookings")) { denyAccess(); return; }
    const draft = bookingDraft;
    const room = data.rooms.find(item => item.property_name === draft.property && item.name === draft.roomName);
    if (!draft.guestName.trim() || !isEmailValid(draft.guestEmail) || !room || !(draft.checkOut > draft.checkIn)) return;
    const nights = Math.max(1, Math.round((Date.parse(`${draft.checkOut}T00:00:00Z`) - Date.parse(`${draft.checkIn}T00:00:00Z`)) / 86400000));
    const amount = room.rate_inr * nights;
    const amountPaid = Math.min(amount, Math.max(0, Math.round(draft.amountPaid || 0)));
    const propertySlug = properties.find(item => item.location === draft.property)?.slug ?? "";
    try {
      const response = await fetch("/api/admin/reservations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          guestName: draft.guestName.trim(), guestEmail: draft.guestEmail.trim().toLowerCase(), guestPhone: draft.guestPhone.trim(),
          guests: draft.guests, roomName: draft.roomName, propertyName: draft.property, propertySlug,
          checkIn: draft.checkIn, checkOut: draft.checkOut, amount, amountPaid, status: draft.status, specialRequests: "",
        }),
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) { setError(result.error ?? "Could not create this booking."); return; }
      const reference: string = result.reference;
      const reservation = {
        reference, guest_name: draft.guestName.trim(), guest_email: draft.guestEmail.trim().toLowerCase(), guest_phone: draft.guestPhone.trim(), guests: draft.guests,
        special_requests: "", check_in: draft.checkIn, check_out: draft.checkOut, total_amount_inr: amount, amount_paid: amountPaid, status: draft.status,
        created_at: new Date().toISOString(), room_types: { name: draft.roomName, property_name: draft.property },
      };
      localRefs.current.add(reference);
      setData(current => (current ? { ...current, reservations: [reservation, ...current.reservations] } : current));
      flashSaved(result.emailed ? `Booking ${reference} created. Confirmation email sent to ${draft.guestEmail.trim().toLowerCase()}.` : `Booking ${reference} created. Email not sent — set RESEND_API_KEY and RESEND_FROM_EMAIL to enable guest emails.`);
      setBookingDraft(null);
    } catch {
      setError("Could not create this booking.");
    }
  }

  // Opens the booking detail modal, seeding a payment entry from any legacy amount_paid so the ledger stays consistent.
  function openBooking(row: Reservation) {
    const payments = row.payments && row.payments.length
      ? row.payments
      : (row.amount_paid ? [{ id: `pay-${Date.now().toString(36)}`, amount: Number(row.amount_paid), note: "Recorded payment", at: row.created_at }] : []);
    setChargeLabel(""); setChargeAmount(""); setChargeImage(""); setPayAmount(""); setPayNote("");
    setSelectedBooking({ ...row, charges: row.charges ?? [], payments });
  }
  async function uploadChargeImage(file: File) {
    setChargeUploading(true);
    try {
      const form = new FormData();
      form.append("file", file);
      const response = await fetch("/api/admin/upload", { method: "POST", body: form });
      const result = await response.json().catch(() => ({}));
      if (response.ok && result.url) setChargeImage(result.url);
      else setError(result.error ?? "Could not upload the image.");
    } catch {
      setError("Could not upload the image.");
    } finally {
      setChargeUploading(false);
    }
  }
  function addBookingCharge() {
    const amount = Math.max(0, Math.round(Number(chargeAmount) || 0));
    if (!amount) return;
    const entry = { id: `chg-${Date.now().toString(36)}`, label: chargeLabel.trim() || "Extra charge", amount, at: new Date().toISOString(), ...(chargeImage ? { image: chargeImage } : {}) };
    setSelectedBooking(current => (current ? { ...current, charges: [...(current.charges ?? []), entry] } : current));
    setChargeLabel(""); setChargeAmount(""); setChargeImage("");
  }
  function addBookingPayment() {
    const amount = Math.max(0, Math.round(Number(payAmount) || 0));
    if (!amount) return;
    const entry = { id: `pay-${Date.now().toString(36)}`, amount, note: payNote.trim(), at: new Date().toISOString() };
    setSelectedBooking(current => (current ? { ...current, payments: [...(current.payments ?? []), entry] } : current));
    setPayAmount(""); setPayNote("");
  }
  function removeBookingCharge(chargeId: string) {
    setSelectedBooking(current => (current ? { ...current, charges: (current.charges ?? []).filter(item => item.id !== chargeId) } : current));
  }
  function removeBookingPayment(paymentId: string) {
    setSelectedBooking(current => (current ? { ...current, payments: (current.payments ?? []).filter(item => item.id !== paymentId) } : current));
  }
  function saveBookingFolio() {
    if (!selectedBooking) return;
    const payments = selectedBooking.payments ?? [];
    const charges = selectedBooking.charges ?? [];
    const amount_paid = payments.reduce((sum, item) => sum + item.amount, 0);
    void update("reservation", selectedBooking.reference, { status: selectedBooking.status, charges, payments, amount_paid });
    setSelectedBooking(null);
  }

  async function signOut() {
    try { await fetch("/api/admin/auth/logout", { method: "POST" }); } catch { /* ignore */ }
    window.location.assign("/admin/login");
  }

  const activeProperty = propertyFilter === "all" ? null : properties.find(item => item.slug === propertyFilter) ?? null;
  const propertyScope = useMemo(() => {
    const reservations = data?.reservations ?? [];
    const payments = data?.payments ?? [];
    const rooms = data?.rooms ?? [];
    if (!activeProperty) return { reservations, payments, rooms };
    const place = activeProperty.location.split(",")[0].trim() || activeProperty.area;
    const resMatcher = new RegExp(escapeRegExp(place), "i");
    const clusterMatcher = activeProperty.backendKey === "delhi" ? /delhi|lajpat/i : /gurugram|cyber|mg\s*road/i;
    const scopedReservations = reservations.filter(row => resMatcher.test(row.room_types?.property_name ?? ""));
    const references = new Set(scopedReservations.map(row => row.reference));
    // Prefer an exact per-property room match (test data carries the full property name); fall back to the
    // backend cluster (gurugram/delhi) when live inventory only records the cluster.
    const exactRooms = rooms.filter(row => resMatcher.test(row.property_name));
    return {
      reservations: scopedReservations,
      payments: payments.filter(row => references.has(row.reservation_reference)),
      rooms: exactRooms.length ? exactRooms : rooms.filter(row => clusterMatcher.test(row.property_name)),
    };
  }, [data, activeProperty]);
  const scopedReservations = propertyScope.reservations;
  const scopedPayments = propertyScope.payments;
  const scopedRooms = propertyScope.rooms;

  const rangeBookings = useMemo(() => scopedReservations.filter(row => isInRange(row.created_at, range)), [scopedReservations, range]);
  const rangePayments = useMemo(() => scopedPayments.filter(row => row.status === "paid" && row.paid_at && isInRange(row.paid_at, range)), [scopedPayments, range]);
  // Amount collected directly against bookings in the period (front-desk / offline payments).
  const reservationPaidInRange = useMemo(() => scopedReservations.filter(row => row.status !== "cancelled" && isInRange(row.created_at, range)).reduce((sum, row) => sum + (Number(row.amount_paid) || 0), 0), [scopedReservations, range]);
  const checkIns = scopedReservations.filter(row => row.check_in === today && row.status !== "cancelled").length;
  const checkOuts = scopedReservations.filter(row => row.check_out === today && ["confirmed", "checked_in", "checked_out"].includes(row.status)).length;
  const occupiedNow = scopedReservations.filter(row => row.status === "checked_in" && row.check_in <= today && row.check_out > today).length;
  const totalRooms = scopedRooms.reduce((sum, room) => sum + room.inventory, 0);
  const liveInventory = scopedRooms.filter(room => room.active).reduce((sum, room) => sum + room.inventory, 0);
  const offMarket = Math.max(0, totalRooms - liveInventory);
  const bookedTonight = scopedReservations.filter(row => ["confirmed", "pending_payment", "checked_in"].includes(row.status) && row.check_in <= today && row.check_out > today).length;
  const availableTonight = Math.max(0, liveInventory - bookedTonight);
  // Occupancy uses sellable (active) rooms as the denominator; out-of-service rooms are excluded.
  const occupancy = liveInventory ? Math.round((occupiedNow / liveInventory) * 100) : 0;
  const revenue = rangePayments.reduce((sum, payment) => sum + payment.amount_inr, 0) + reservationPaidInRange;
  const propertyBreakdown = useMemo(() => {
    const source = activeProperty ? [activeProperty] : properties;
    return source.map(property => {
      const place = property.location.split(",")[0].trim() || property.area;
      const matcher = new RegExp(escapeRegExp(place), "i");
      const bookings = (data?.reservations ?? []).filter(row => matcher.test(row.room_types?.property_name ?? ""));
      const periodBookings = bookings.filter(row => isInRange(row.created_at, range));
      const references = new Set(periodBookings.map(row => row.reference));
      const paidRevenue = (data?.payments ?? []).filter(row => row.status === "paid" && row.paid_at && isInRange(row.paid_at, range) && references.has(row.reservation_reference)).reduce((sum, row) => sum + row.amount_inr, 0);
      const bookingPaid = periodBookings.filter(row => row.status !== "cancelled").reduce((sum, row) => sum + (Number(row.amount_paid) || 0), 0);
      const rates = property.rooms.map(room => room.rate).filter(rate => rate > 0);
      return {
        slug: property.slug,
        area: property.area,
        name: property.name,
        location: property.location,
        city: property.city,
        roomTypes: property.rooms.length,
        fromRate: rates.length ? Math.min(...rates) : 0,
        arrivals: bookings.filter(row => row.check_in === today && row.status !== "cancelled").length,
        departures: bookings.filter(row => row.check_out === today && ["confirmed", "checked_in", "checked_out"].includes(row.status)).length,
        bookings: periodBookings.length,
        revenue: paidRevenue + bookingPaid,
      };
    });
  }, [properties, activeProperty, data, range, today]);
  const pendingCount = scopedReservations.filter(row => row.status === "pending_payment").length;
  const monthStart = `${today.slice(0, 8)}01`;
  const monthBookings = scopedReservations.filter(row => row.created_at.slice(0, 10) >= monthStart && row.created_at.slice(0, 10) <= today).length;
  const monthReservationPaid = scopedReservations.filter(row => row.status !== "cancelled" && row.created_at.slice(0, 10) >= monthStart && row.created_at.slice(0, 10) <= today).reduce((sum, row) => sum + (Number(row.amount_paid) || 0), 0);
  const monthRevenue = scopedPayments.filter(row => row.status === "paid" && row.paid_at && row.paid_at.slice(0, 10) >= monthStart && row.paid_at.slice(0, 10) <= today).reduce((sum, row) => sum + row.amount_inr, 0) + monthReservationPaid;
  const pendingEnquiries = data?.enquiries.filter(row => row.status === "new").length ?? 0;
  const totalProperties = activeProperty ? 1 : (properties.length || propertyBreakdown.length);
  const activities = [
    ...scopedReservations.map(row => ({ id: row.reference, kind: "booking", date: row.created_at, title: row.status === "checked_in" ? "Guest checked in" : "Booking received", detail: `${row.guest_name} · ${row.reference}`, status: row.status })),
    ...scopedPayments.map(row => ({ id: row.id, kind: "payment", date: row.paid_at ?? row.created_at, title: row.status === "paid" ? "Payment received" : "Payment link created", detail: `${formatMoney(row.amount_inr)} · ${row.reservation_reference}`, status: row.status })),
    ...(activeProperty ? [] : (data?.enquiries ?? [])).map(row => ({ id: row.id, kind: "enquiry", date: row.created_at, title: "New customer enquiry", detail: `${row.name} · ${row.kind}`, status: row.status })),
  ].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 5);
  const weekDays = Array.from({ length: 7 }, (_, index) => addDays(today, index - 6)).map(date => ({
    date,
    label: new Intl.DateTimeFormat("en", { weekday: "short", timeZone: "Asia/Kolkata" }).format(new Date(`${date}T12:00:00+05:30`)),
    arrivals: scopedReservations.filter(row => row.check_in === date && row.status !== "cancelled").length,
    departures: scopedReservations.filter(row => row.check_out === date && row.status !== "cancelled").length,
  }));
  const maxActivity = Math.max(1, ...weekDays.flatMap(day => [day.arrivals, day.departures]));

  const filteredBookings = useMemo(() => {
    const query = bookingSearch.trim().toLowerCase();
    return rangeBookings.filter(row => {
      if (bookingStatus !== "all" && row.status !== bookingStatus) return false;
      if (!query) return true;
      return [row.reference, row.guest_name, row.guest_email, row.room_types?.name, row.room_types?.property_name]
        .some(field => (field ?? "").toLowerCase().includes(query));
    });
  }, [rangeBookings, bookingSearch, bookingStatus]);
  const bookingStatuses = useMemo(() => {
    const set = new Set<string>();
    (data?.reservations ?? []).forEach(row => set.add(row.status));
    return [...set];
  }, [data]);

  const filteredRooms = useMemo(() => {
    const query = roomSearch.trim().toLowerCase();
    return scopedRooms.filter(row => {
      if (roomStatusFilter === "on-sale" && !row.active) return false;
      if (roomStatusFilter === "off-sale" && row.active) return false;
      if (!query) return true;
      return `${row.name} ${row.property_name}`.toLowerCase().includes(query);
    });
  }, [scopedRooms, roomSearch, roomStatusFilter]);

  // Rooms booked for today per room type, counting website + dashboard reservations (matched by
  // room name and property area so local bookings like "Hari's Court Cyber City" still count).
  const roomBooked = useMemo(() => {
    const map = new Map<string, number>();
    for (const room of filteredRooms) {
      const area = (room.property_name.split(",")[0] || room.property_name).trim().toLowerCase();
      const booked = scopedReservations.filter(reservation =>
        ["confirmed", "pending_payment", "checked_in"].includes(reservation.status) &&
        reservation.room_types?.name === room.name &&
        (reservation.room_types?.property_name ?? "").toLowerCase().includes(area) &&
        reservation.check_in <= today && reservation.check_out > today,
      ).length;
      map.set(room.id, booked);
    }
    return map;
  }, [filteredRooms, scopedReservations, today]);

  const filteredEnquiries = useMemo(() => {
    const query = enquirySearch.trim().toLowerCase();
    return (data?.enquiries ?? []).filter(row => {
      if (activeProperty && row.property && row.property !== "all" && row.property !== activeProperty.slug) return false;
      if (enquiryStatusFilter !== "all" && row.status !== enquiryStatusFilter) return false;
      if (!isInRange(row.created_at, range)) return false;
      if (!query) return true;
      return `${row.name} ${row.email} ${row.phone} ${row.kind}`.toLowerCase().includes(query);
    });
  }, [data, enquirySearch, enquiryStatusFilter, activeProperty, range]);

  const guestStats = useMemo(() => {
    const map = new Map<string, { stays: number; nights: number; spend: number; last: string; properties: Set<string> }>();
    for (const row of (data?.reservations ?? [])) {
      const key = (row.guest_email || row.guest_name).toLowerCase();
      const entry = map.get(key) ?? { stays: 0, nights: 0, spend: 0, last: "", properties: new Set<string>() };
      entry.stays += 1;
      const nights = Math.max(1, Math.round((Date.parse(`${row.check_out}T00:00:00Z`) - Date.parse(`${row.check_in}T00:00:00Z`)) / 86400000));
      entry.nights += nights;
      if (row.status !== "cancelled") entry.spend += row.total_amount_inr;
      if (row.check_in > entry.last) entry.last = row.check_in;
      if (row.room_types?.property_name) entry.properties.add(row.room_types.property_name);
      map.set(key, entry);
    }
    return map;
  }, [data]);
  const guestRecords = useMemo(() => {
    const query = guestSearch.trim().toLowerCase();
    return (data?.guests ?? [])
      .filter(guest => !query || `${guest.name} ${guest.email} ${guest.phone} ${guest.city}`.toLowerCase().includes(query))
      .map(guest => {
        const stats = guestStats.get(guest.email.toLowerCase());
        return { ...guest, stays: stats?.stays ?? 0, nights: stats?.nights ?? 0, spend: stats?.spend ?? 0, last: stats?.last ?? "" };
      })
      .sort((a, b) => b.spend - a.spend);
  }, [data, guestStats, guestSearch]);

  const calendarDays = useMemo(() => {
    const [yearStr, monthStr] = calendarMonth.split("-");
    const year = Number(yearStr);
    const month = Number(monthStr);
    const first = new Date(Date.UTC(year, month - 1, 1));
    const daysInMonth = new Date(Date.UTC(year, month, 0)).getUTCDate();
    const leading = first.getUTCDay();
    const cells: ({ date: string; booked: number; inventory: number; state: string } | null)[] = Array.from({ length: leading }, () => null);
    for (let day = 1; day <= daysInMonth; day += 1) {
      const date = `${calendarMonth}-${String(day).padStart(2, "0")}`;
      const booked = scopedReservations.filter(row => ["confirmed", "pending_payment", "checked_in"].includes(row.status) && row.check_in <= date && row.check_out > date).length;
      const inventory = liveInventory;
      const ratio = inventory ? booked / inventory : 0;
      const state = date < today ? "past" : booked === 0 ? "open" : ratio >= 1 ? "full" : "partial";
      cells.push({ date, booked, inventory, state });
    }
    return cells;
  }, [calendarMonth, scopedReservations, liveInventory, today]);
  const calendarLabel = useMemo(() => new Intl.DateTimeFormat("en-IN", { month: "long", year: "numeric", timeZone: "UTC" }).format(new Date(`${calendarMonth}-01T12:00:00Z`)), [calendarMonth]);
  function shiftMonth(amount: number) {
    const [year, month] = calendarMonth.split("-").map(Number);
    const next = new Date(Date.UTC(year, month - 1 + amount, 1));
    setCalendarMonth(`${next.getUTCFullYear()}-${String(next.getUTCMonth() + 1).padStart(2, "0")}`);
  }

  const paymentsInRange = useMemo(() => scopedPayments.filter(row => isInRange(row.created_at, range)), [scopedPayments, range]);
  // Revenue across fixed buckets (today, this week/month/year, all time) for the active property scope.
  const revenueBuckets = useMemo(() => {
    const yearStart = `${today.slice(0, 4)}-01-01`;
    const monthFrom = `${today.slice(0, 8)}01`;
    const weekday = new Date(`${today}T00:00:00Z`).getUTCDay();
    const weekStart = addDays(today, -((weekday + 6) % 7));
    const within = (value: string, from: string) => { const date = value.slice(0, 10); return date >= from && date <= today; };
    const calc = (from: string) =>
      scopedPayments.filter(row => row.status === "paid" && row.paid_at && within(row.paid_at, from)).reduce((sum, row) => sum + row.amount_inr, 0)
      + scopedReservations.filter(row => row.status !== "cancelled" && within(row.created_at, from)).reduce((sum, row) => sum + (Number(row.amount_paid) || 0), 0);
    const all = scopedPayments.filter(row => row.status === "paid").reduce((sum, row) => sum + row.amount_inr, 0)
      + scopedReservations.filter(row => row.status !== "cancelled").reduce((sum, row) => sum + (Number(row.amount_paid) || 0), 0);
    return { today: calc(today), week: calc(weekStart), month: calc(monthFrom), year: calc(yearStart), all };
  }, [scopedPayments, scopedReservations, today]);
  const paymentSummary = useMemo(() => {
    const collected = paymentsInRange.filter(row => row.status === "paid").reduce((sum, row) => sum + row.amount_inr, 0) + reservationPaidInRange;
    const pendingList = paymentsInRange.filter(row => ["created", "pending", "attempted"].includes(row.status));
    const pending = pendingList.reduce((sum, row) => sum + row.amount_inr, 0);
    const failed = paymentsInRange.filter(row => ["failed", "refunded"].includes(row.status)).length;
    return { collected, pending, pendingCount: pendingList.length, failed, total: paymentsInRange.length };
  }, [paymentsInRange, reservationPaidInRange]);

  const reports = useMemo(() => {
    const statusCounts = new Map<string, number>();
    rangeBookings.forEach(row => statusCounts.set(row.status, (statusCounts.get(row.status) ?? 0) + 1));
    const enquiryKinds = new Map<string, number>();
    (activeProperty ? [] : (data?.enquiries ?? [])).filter(row => isInRange(row.created_at, range)).forEach(row => enquiryKinds.set(row.kind, (enquiryKinds.get(row.kind) ?? 0) + 1));
    const roomTypeCounts = new Map<string, number>();
    rangeBookings.forEach(row => { const name = row.room_types?.name ?? "Other"; roomTypeCounts.set(name, (roomTypeCounts.get(name) ?? 0) + 1); });
    const confirmedStays = rangeBookings.filter(row => ["confirmed", "checked_in", "checked_out"].includes(row.status)).length;
    const conversion = rangeBookings.length ? Math.round((confirmedStays / rangeBookings.length) * 100) : 0;
    const avgBooking = rangeBookings.length ? Math.round(rangeBookings.reduce((sum, row) => sum + row.total_amount_inr, 0) / rangeBookings.length) : 0;
    return {
      statusCounts: [...statusCounts.entries()].sort((a, b) => b[1] - a[1]),
      enquiryKinds: [...enquiryKinds.entries()].sort((a, b) => b[1] - a[1]),
      roomTypes: [...roomTypeCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5),
      conversion, avgBooking, confirmedStays,
    };
  }, [rangeBookings, data, range, activeProperty]);

  function exportBookingsCsv() {
    const header = ["Reference", "Guest", "Email", "Phone", "Room type", "Property", "Check-in", "Check-out", "Amount", "Status", "Booked at"];
    const rows = filteredBookings.map(row => [
      row.reference, row.guest_name, row.guest_email, row.guest_phone ?? "", row.room_types?.name ?? "", row.room_types?.property_name ?? "",
      row.check_in, row.check_out, String(row.total_amount_inr), row.status, row.created_at,
    ]);
    const escape = (value: string) => `"${value.replaceAll('"', '""')}"`;
    const csv = [header, ...rows].map(line => line.map(escape).join(",")).join("\r\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `haris-court-bookings-${range.from}-to-${range.to}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  const meta = TAB_META[tab] ?? TAB_META.Overview;

  return <main className={`admin-app ${collapsed ? "nav-collapsed" : ""} ${compact ? "is-compact" : ""}`}>
    <aside className={`admin-sidebar ${collapsed ? "is-collapsed" : ""} ${mobileNavOpen ? "is-open" : ""}`}>
      <div className="admin-sidebar-head">
        <a className="admin-brand admin-brand-logo" href="/admin" aria-label="Hari’s Court Hotel – Admin"><BrandLogo size="admin" showName={false} /><small>HOTEL OPERATIONS</small></a>
        <button type="button" className="nav-collapse-toggle" onClick={() => setCollapsed(value => !value)} aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"} title={collapsed ? "Expand sidebar" : "Collapse sidebar"}>{collapsed ? <PanelLeftOpen size={16} /> : <PanelLeftClose size={16} />}</button>
        <button type="button" className="nav-close" onClick={() => setMobileNavOpen(false)} aria-label="Close menu"><X size={18} /></button>
      </div>
      <div className="admin-clock"><span>LOCAL HOTEL TIME</span><strong>{localTime}</strong><small>{localDate}</small></div>
      <nav className="admin-nav" aria-label="Hotel administration">
        {NAV_GROUPS.map(group => { const items = allowedNav.filter(item => item.group === group); if (!items.length) return null; return <div key={group} className="admin-nav-group"><p>{GROUP_LABELS[group]}</p>{items.map(item => <button key={item.tab} className={`admin-nav-item ${tab === item.tab ? "active" : ""}`} title={item.tab} onClick={() => selectTab(item.tab)}><item.icon size={16} />{item.tab}</button>)}</div>; })}
      </nav>
      <div className={`admin-connection ${error ? "disconnected" : ""}`}><span className="connection-dot">●</span><strong>{error ? "Needs attention" : loading ? "Connecting..." : "System connected"}</strong><small>{error || "Hotel records are up to date"}</small></div>
    </aside>
    <div className={`nav-overlay ${mobileNavOpen ? "is-visible" : ""}`} onClick={() => setMobileNavOpen(false)} aria-hidden="true" />

    {toast && <div className={`hc-toast hc-toast-${toast.tone}`} role="alert"><span className="hc-toast-icon">{toast.tone === "error" ? <XCircle size={18} /> : <Check size={18} />}</span><span className="hc-toast-text">{toast.text}</span><button className="hc-toast-close" onClick={() => setToast(null)} aria-label="Dismiss"><X size={15} /></button></div>}

    <section className="admin-workspace">
      <header className="admin-topbar"><button type="button" className="nav-hamburger" onClick={() => setMobileNavOpen(true)} aria-label="Open menu"><Menu size={18} /></button><div className="topbar-label"><span>HARI’S COURT</span><span className="topbar-divider">/</span><span>OPERATIONS</span></div><div className="topbar-tools"><span className="topbar-date">{localDate}</span><button className="admin-icon-button" aria-label={`${pendingCount} pending bookings`} title={`${pendingCount} pending bookings`} onClick={() => setTab("Bookings")}><Bell size={17} />{pendingCount > 0 && <i>{pendingCount}</i>}</button><div className="admin-profile"><span className="profile-avatar">{(currentUser?.name ?? "HC").split(" ").filter(Boolean).map(word => word[0]).join("").slice(0, 2).toUpperCase() || "HC"}</span><span><strong>{currentUser?.name ?? "Hotel Admin"}</strong><small>{currentUser ? (currentUser.isSuper ? "Super admin" : currentUser.role) : (preview ? "Preview mode" : "Operations team")}</small></span></div><button className="admin-icon-button signout-button" title={preview ? "Return to admin sign in" : "Sign out"} aria-label={preview ? "Return to admin sign in" : "Sign out"} onClick={() => preview ? window.location.assign("/admin/login") : void signOut()}><LogOut size={16} /></button></div></header>

      <div className="admin-content">
        <div className="admin-title-row"><div><span className="admin-kicker">{meta.kicker}</span><h1>{meta.title}</h1><p>{meta.desc}</p></div><button className="refresh-button" onClick={() => preview ? setData(TESTING_DATA_ENABLED ? loadTestingData(todayInIndia()) : emptyAdminData()) : void load()} title="Refresh records" aria-label="Refresh records"><RefreshCw size={15} /></button></div>

        {error && <p className="admin-error" role="alert">{error}</p>}

        {!NON_DATA_TABS.has(tab) && properties.length > 0 && <section className="property-switch" aria-label="Property selector">
          <label><Building2 size={15} /><span>PROPERTY</span><select value={propertyFilter} onChange={event => setPropertyFilter(event.target.value)} aria-label="Select property"><option value="all">All Properties</option>{properties.map(item => <option key={item.slug} value={item.slug}>{item.area} · {item.city}</option>)}</select></label>
          {activeProperty && <span className="property-switch-note">Showing {activeProperty.area}, {activeProperty.city} only</span>}
        </section>}

        {!NO_PERIOD_TABS.has(tab) && <section className="period-bar" aria-label="Dashboard date range"><label><CalendarDays size={15} /><span>PERIOD</span><input aria-label="Period from" type="date" value={range.from} onChange={event => { setRange({ ...range, from: event.target.value }); setPeriod("Custom"); }} /><span className="range-separator">to</span><input aria-label="Period to" type="date" value={range.to} onChange={event => { setRange({ ...range, to: event.target.value }); setPeriod("Custom"); }} /></label><div className="period-presets">{(["Today", "This week", "This month", "This year"] as const).map(value => <button key={value} className={period === value ? "selected" : ""} onClick={() => choosePeriod(value)}>{value}</button>)}</div></section>}

        {tab === "Website content" && <ContentManager />}
        {tab === "Pricing" && <PricingManager propertyFilter={propertyFilter} />}
        {tab === "Offers" && <OffersManager properties={properties.map(item => ({ slug: item.slug, area: item.area, city: item.city }))} />}
        {tab === "Users" && <UsersManager />}
        {tab === "SEO" && <SeoManager />}
        {tab === "Notifications" && <NotificationsManager />}
        {tab === "Login history" && <LoginHistory />}
        {tab === "Audit log" && <AuditLog />}
        {loading && !data && !NON_DATA_TABS.has(tab) && tab !== "Pricing" && <p className="admin-empty">Loading hotel records...</p>}
        {!loading && !data && !error && !NON_DATA_TABS.has(tab) && tab !== "Pricing" && <p className="admin-empty">No hotel records are available.</p>}

        {data && tab === "Overview" && <>
          <section className="kpi-overview" aria-label="Key metrics">
            <SummaryCard icon={<Building2 size={18} />} value={String(totalProperties)} label="Total Properties" tone="violet" />
            <SummaryCard icon={<BedDouble size={18} />} value={String(totalRooms)} label="Total Rooms" tone="blue" />
            <SummaryCard icon={<ClipboardList size={18} />} value={String(monthBookings)} label="Bookings This Month" tone="indigo" />
            <SummaryCard icon={<CircleDollarSign size={18} />} value={formatMoney(monthRevenue)} label="Revenue This Month" tone="green" />
            <SummaryCard icon={<CheckCircle2 size={18} />} value={String(occupiedNow)} label="Occupied Rooms" tone="amber" />
            <SummaryCard icon={<DoorOpen size={18} />} value={String(availableTonight)} label="Available Rooms" tone="teal" />
            <SummaryCard icon={<Clock3 size={18} />} value={String(pendingCount)} label="Pending Bookings" tone="red" />
            <SummaryCard icon={<Mail size={18} />} value={String(pendingEnquiries)} label="Pending Enquiries" tone="rose" />
          </section>

          {properties.length > 0 && <section className="property-overview" aria-labelledby="po-title">
            <div className="po-heading"><div><span>PORTFOLIO</span><h2 id="po-title">Property overview</h2></div><small>{activeProperty ? "1 of " + properties.length : properties.length} properties</small></div>
            <div className="po-grid">{(activeProperty ? properties.filter(item => item.slug === activeProperty.slug) : properties).map(item => {
              const rates = item.rooms.map(room => room.rate).filter(rate => rate > 0);
              const fromRate = rates.length ? Math.min(...rates) : 0;
              return <article className="po-card" key={item.slug}>
                <div className="po-media">{item.cardImage && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={item.cardImage} alt={`${item.name} ${item.location}`} />
                )}<span className="po-status">Active</span></div>
                <div className="po-body"><h3>{item.area}</h3><small><MapPin size={12} /> {item.name} · {item.city}</small><div className="po-stats"><div><strong>{item.rooms.length}</strong><span>Room types</span></div><div><strong>{fromRate ? formatMoney(fromRate) : "On request"}</strong><span>From / night</span></div></div><div className="po-actions"><button type="button" className="po-manage" onClick={() => setTab("Rooms")}>Manage</button><a className="po-view" href={`/locations/${item.slug}`} target="_blank" rel="noreferrer">View Website</a></div></div>
              </article>;
            })}</div>
          </section>}

          <section className="property-pulse">
            <div className="pulse-main"><div className="pulse-copy"><span className="pulse-eyebrow"><MapPin size={13} /> {activeProperty ? `${activeProperty.area.toUpperCase()}, ${activeProperty.city.toUpperCase()}` : "ALL PROPERTIES"} · LIVE SNAPSHOT</span><h2>Today at<br />Hari&apos;s Court</h2><p>{activeProperty ? `Room occupancy for ${activeProperty.area}, ${activeProperty.city}.` : "Room occupancy across all four Hari\u2019s Court properties."}</p><button className="pulse-link" onClick={() => setTab("Rooms")}>View room inventory <ArrowRight size={14} /></button></div><div className="pulse-gauge" style={{ background: `conic-gradient(#a989f2 0 ${occupancy}%, #ffffff24 ${occupancy}% 100%)` }}><div><strong>{occupancy}<small>%</small></strong><span>occupied</span></div></div></div>
            <div className="pulse-stats"><div><span>Occupied now</span><strong>{occupiedNow}<small> rooms</small></strong></div><div><span>Ready to book</span><strong>{availableTonight}<small> rooms</small></strong></div><div><span>Reserved tonight</span><strong>{bookedTonight}<small> rooms</small></strong></div><div><span>Out of service</span><strong>{offMarket}<small> rooms</small></strong></div></div>
          </section>

          <section className="locations-overview" aria-labelledby="locations-overview-title"><div className="locations-heading"><div><span>PROPERTY BREAKDOWN</span><h2 id="locations-overview-title">Performance by property</h2></div><small>Verified bookings &amp; revenue · {range.from} to {range.to}</small></div><div className="location-cards">{propertyBreakdown.map(location => (
            <article className="location-card" key={location.slug}><header className="location-card-head"><span className="location-marker"><MapPin size={16} /></span><div><small>{location.city}</small><h3>{location.area}</h3></div><button className="location-action" onClick={() => { setPropertyFilter(location.slug); }} aria-label={`Focus ${location.area}`} title={`Focus on ${location.area}`}><ArrowRight size={15} /></button></header><div className="location-metrics"><div><span>Room types</span><strong>{location.roomTypes}</strong></div><div><span>From / night</span><strong>{location.fromRate ? formatMoney(location.fromRate) : "On request"}</strong></div><div><span>Arrivals today</span><strong>{location.arrivals}</strong></div><div><span>Departures today</span><strong>{location.departures}</strong></div></div><footer className="location-period-stats"><div><span>Bookings</span><strong>{location.bookings}</strong></div><div><span>Verified revenue</span><strong>{formatMoney(location.revenue)}</strong></div></footer></article>
          ))}</div></section>

          <section className="front-desk"><div className="desk-heading"><div><span className="desk-eyebrow">FRONT DESK</span><h2>Arrivals & departures</h2><p>Guest movements scheduled for today</p></div><span className="desk-date"><CalendarDays size={14} />{new Intl.DateTimeFormat("en-IN", { weekday: "short", day: "numeric", month: "short", timeZone: "Asia/Kolkata" }).format(new Date())}</span></div><div className="desk-flow"><button className="desk-movement" onClick={() => setTab("Bookings")}><span className="movement-icon arrival-icon"><ArrowDownRight size={17} /></span><span><small>EXPECTED ARRIVALS</small><strong>{checkIns}</strong><em>Check-ins today</em></span><ArrowRight className="movement-arrow" size={15} /></button><div className="desk-divider" /><button className="desk-movement" onClick={() => setTab("Bookings")}><span className="movement-icon departure-icon"><ArrowUpRight size={17} /></span><span><small>EXPECTED DEPARTURES</small><strong>{checkOuts}</strong><em>Check-outs today</em></span><ArrowRight className="movement-arrow" size={15} /></button><div className="desk-divider" /><button className="desk-movement" onClick={() => setTab("Bookings")}><span className="movement-icon pending-icon"><Clock3 size={17} /></span><span><small>AWAITING PAYMENT</small><strong>{pendingCount}</strong><em>Pending reservations</em></span><ArrowRight className="movement-arrow" size={15} /></button></div></section>

          <section className="performance-section" aria-labelledby="performance-title"><div className="performance-heading"><div><span>PERIOD PERFORMANCE</span><h2 id="performance-title">Booking &amp; revenue summary</h2></div><small>{formatPeriodDate(range.from)}{range.from !== range.to ? ` – ${formatPeriodDate(range.to)}` : ""}</small></div><div className="kpi-ribbon" aria-label="Performance summary"><SummaryCard icon={<ClipboardList size={17} />} value={String(rangeBookings.length)} label="Bookings" tone="blue" /><SummaryCard icon={<CircleDollarSign size={17} />} value={formatMoney(revenue)} label="Collected revenue" tone="violet" /><SummaryCard icon={<CheckCircle2 size={17} />} value={String(rangeBookings.filter(row => ["confirmed", "checked_in", "checked_out"].includes(row.status)).length)} label="Confirmed stays" tone="green" /><SummaryCard icon={<XCircle size={17} />} value={String(rangeBookings.filter(row => row.status === "cancelled").length)} label="Cancelled" tone="red" /></div></section>

          <section className="analytics-grid redesign-analytics"><article className="analytics-panel arrivals-panel"><div className="panel-heading"><div><span className="panel-overline">SEVEN DAY OUTLOOK</span><h2>Guest movement</h2><p>Arrival and departure pattern</p></div><div className="chart-key"><span><i className="blue-key" />Arrivals</span><span><i className="green-key" />Departures</span></div></div><div className="bar-chart">{weekDays.map(day => <div className="chart-column" key={day.date}><div className="bar-pair"><i className="arrival-bar" title={`${day.arrivals} check-ins`} style={{ height: `${Math.max(3, day.arrivals / maxActivity * 100)}%` }} /><i className="departure-bar" title={`${day.departures} check-outs`} style={{ height: `${Math.max(3, day.departures / maxActivity * 100)}%` }} /></div><span>{day.label}</span></div>)}</div></article>

          <article className="analytics-panel activity-panel"><div className="panel-heading"><div><span className="panel-overline">LATEST UPDATES</span><h2>Activity log</h2><p>Recent guest and payment events</p></div><button className="text-action" onClick={() => setTab("Bookings")}>All bookings <ArrowRight size={12} /></button></div><div className="activity-list">{activities.length ? activities.map(item => <div className="activity-row" key={`${item.kind}-${item.id}`}><span className={`activity-icon activity-${item.kind}`}>{item.kind === "booking" ? <Check size={14} /> : item.kind === "payment" ? <CircleDollarSign size={14} /> : <Mail size={14} />}</span><span className="activity-copy"><strong>{item.title}</strong><small>{item.detail}</small></span><time>{new Intl.DateTimeFormat("en-IN", { hour: "2-digit", minute: "2-digit", timeZone: "Asia/Kolkata" }).format(new Date(item.date))}</time></div>) : <p className="empty-inline">No recent activity yet.</p>}</div></article></section>
        </>}

        {data && tab === "Bookings" && <>
          <div className="toolbar">
            <div className="search-field"><Search size={15} /><input type="search" value={bookingSearch} onChange={event => setBookingSearch(event.target.value)} placeholder="Search reference, guest, email or room" aria-label="Search bookings" /></div>
            <div className="filter-chips" role="group" aria-label="Filter by status">
              <button className={bookingStatus === "all" ? "selected" : ""} onClick={() => setBookingStatus("all")}>All</button>
              {bookingStatuses.map(status => <button key={status} className={bookingStatus === status ? "selected" : ""} onClick={() => setBookingStatus(status)}>{status.replaceAll("_", " ")}</button>)}
            </div>
            <button className="ghost-button" onClick={exportBookingsCsv} title="Export filtered bookings to CSV"><Download size={14} /> Export CSV</button>
            <button className={`pricing-publish${canEditCurrent ? "" : " locked-btn"}`} onClick={guarded(startCreateBooking)}><Plus size={14} /> Create booking</button>
          </div>
          <DataTable title={`Bookings (${filteredBookings.length})`} empty="No bookings match these filters."><table><thead><tr><th>Reference / Guest</th><th>Stay</th><th>Dates</th><th>Total</th><th>Status</th><th>Action</th></tr></thead><tbody>{filteredBookings.map(row => <tr key={row.reference}><td><strong>{row.reference}</strong><span>{row.guest_name} · {row.guest_email}</span>{row.special_requests ? <span>Requests: {row.special_requests}</span> : null}</td><td>{row.room_types?.name}<span>{row.room_types?.property_name}</span></td><td>{row.check_in} – {row.check_out}</td><td>{formatMoney(row.total_amount_inr + (row.charges ?? []).reduce((sum, charge) => sum + charge.amount, 0))}{(() => { const paid = (row.payments && row.payments.length) ? row.payments.reduce((sum, item) => sum + item.amount, 0) : (row.amount_paid ?? 0); return paid > 0 ? <span>Paid {formatMoney(paid)}</span> : null; })()}</td><td><Status value={row.status} /></td><td className="row-actions"><button className="admin-link" onClick={() => openBooking(row)}>View</button>{row.status === "checked_in" ? <button className={`admin-action${canEditCurrent ? "" : " locked-btn"}`} onClick={guarded(() => setConfirmCheckout(row))}>Check out</button> : ["pending_payment", "confirmed"].includes(row.status) && <button className={`admin-action${canEditCurrent ? "" : " locked-btn"}`} onClick={guarded(() => void update("reservation", row.reference, { status: "cancelled" }))}>Cancel</button>}</td></tr>)}</tbody></table></DataTable>
        </>}

        {data && tab === "Calendar" && <section className="calendar-wrap">
          <div className="calendar-head">
            <div className="calendar-nav"><button onClick={() => shiftMonth(-1)} aria-label="Previous month"><ChevronLeft size={16} /></button><strong>{calendarLabel}</strong><button onClick={() => shiftMonth(1)} aria-label="Next month"><ChevronRight size={16} /></button></div>
            <div className="calendar-legend"><span><i className="cal-open" />Available</span><span><i className="cal-partial" />Partially booked</span><span><i className="cal-full" />Fully booked</span><span><i className="cal-past" />Past</span></div>
          </div>
          <div className="calendar-grid-head">{["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map(day => <span key={day}>{day}</span>)}</div>
          <div className="calendar-grid">{calendarDays.map((cell, index) => cell === null ? <span key={`pad-${index}`} className="cal-cell cal-pad" /> : <button key={cell.date} className={`cal-cell cal-${cell.state}`} onClick={() => { setBookingSearch(""); setBookingStatus("all"); setRange({ from: cell.date, to: cell.date }); setPeriod("Custom"); setTab("Bookings"); }} title={`${cell.booked} of ${cell.inventory || "—"} rooms booked`}><strong>{Number(cell.date.slice(-2))}</strong><small>{cell.state === "past" ? "—" : `${cell.booked}/${cell.inventory || "—"}`}</small></button>)}</div>
          <p className="calendar-note">Availability is derived from confirmed, pending and in-house reservations against total live inventory ({liveInventory} rooms). Select a day to view its bookings.</p>
        </section>}

        {data && tab === "Rooms" && <>
          <div className="toolbar">
            <div className="search-field"><Search size={15} /><input type="search" value={roomSearch} onChange={event => setRoomSearch(event.target.value)} placeholder="Search room type or property" aria-label="Search rooms" /></div>
            <div className="filter-chips" role="group" aria-label="Filter by sale status">
              {(["all", "on-sale", "off-sale"] as const).map(value => <button key={value} className={roomStatusFilter === value ? "selected" : ""} onClick={() => setRoomStatusFilter(value)}>{value.replace("-", " ")}</button>)}
            </div>
            <div className="toolbar-stat"><BedDouble size={14} /> {totalRooms} rooms · {liveInventory} on sale</div>
            <button className={`pricing-publish${canEditCurrent ? "" : " locked-btn"}`} onClick={guarded(startAddRoom)}><Plus size={14} /> Add room type</button>
          </div>
          {filteredRooms.length === 0 ? <div className="admin-empty-state"><BedDouble size={28} /><strong>No room types match</strong><span>Try a different search or filter, or add a room type.</span><button className={`pricing-publish${canEditCurrent ? "" : " locked-btn"}`} onClick={guarded(startAddRoom)}><Plus size={14} /> Add room type</button></div>
          : <div className="admin-table-wrap"><div className="table-heading"><h2>Room inventory ({filteredRooms.length})</h2><small>Booked / available reflect active reservations for today and update automatically as bookings are made.</small></div><table><thead><tr><th>Room type</th><th>Property</th><th>Rate / night (₹)</th><th>Inventory</th><th>Booked today</th><th>Available</th><th>On sale</th><th>Actions</th></tr></thead><tbody>{filteredRooms.map(row => { const booked = roomBooked.get(row.id) ?? 0; const available = Math.max(0, row.inventory - booked); return <tr key={row.id}>
            <td><strong>{row.name}</strong></td>
            <td>{row.property_name}</td>
            <td><input key={`rate-${row.id}-${row.rate_inr}`} aria-label={`${row.name} rate`} className="admin-number" type="number" min="0" step="100" defaultValue={row.rate_inr} disabled={!canEditCurrent} onBlur={event => { const rate = Math.max(0, Math.round(Number(event.currentTarget.value) || 0)); if (rate !== row.rate_inr) void update("room", row.id, { rate_inr: rate }); }} /></td>
            <td><input key={`inv-${row.id}-${row.inventory}`} aria-label={`${row.name} inventory`} className="admin-number" type="number" min="0" defaultValue={row.inventory} disabled={!canEditCurrent} onBlur={event => { const inventory = Math.max(0, Math.round(Number(event.currentTarget.value) || 0)); if (inventory !== row.inventory) void update("room", row.id, { inventory }); }} /></td>
            <td><span className="avail-badge avail-booked">{booked}</span></td>
            <td><span className={`avail-badge ${available > 0 ? "avail-open" : "avail-none"}`}>{available}</span></td>
            <td><label className="switch"><input aria-label={`${row.name} active`} type="checkbox" checked={row.active} disabled={!canEditCurrent} onChange={event => void update("room", row.id, { active: event.currentTarget.checked })} /><span /></label></td>
            <td className="row-actions"><button className={`admin-link${canEditCurrent ? "" : " locked-btn"}`} onClick={guarded(() => { setRoomDraft({ ...row }); setRoomDraftNew(false); })}><Pencil size={13} /> Edit</button><button className={`admin-link danger${canEditCurrent ? "" : " locked-btn"}`} onClick={guarded(() => setConfirmRoomId(row.id))}><Trash2 size={13} /> Delete</button></td>
          </tr>; })}</tbody></table></div>}
          {savedNote && <p className="pricing-note ok"><Check size={14} /> {savedNote}</p>}
        </>}

        {data && tab === "Guests" && <>
          <div className="toolbar">
            <div className="search-field"><Search size={15} /><input type="search" value={guestSearch} onChange={event => setGuestSearch(event.target.value)} placeholder="Search name, email, phone or city" aria-label="Search guests" /></div>
            <div className="toolbar-stat"><Users size={14} /> {data.guests.length} guests</div>
            <button className={`pricing-publish${canEditCurrent ? "" : " locked-btn"}`} onClick={guarded(startAddGuest)}><Plus size={14} /> Add guest</button>
          </div>
          {guestRecords.length === 0 ? <div className="admin-empty-state"><Users size={28} /><strong>No guests match</strong><span>Try a different search, or add a guest.</span><button className={`pricing-publish${canEditCurrent ? "" : " locked-btn"}`} onClick={guarded(startAddGuest)}><Plus size={14} /> Add guest</button></div>
          : <div className="admin-table-wrap"><div className="table-heading"><h2>Guest directory ({guestRecords.length})</h2></div><table><thead><tr><th>Guest</th><th>Contact</th><th>City</th><th>Stays</th><th>Lifetime value</th><th>Actions</th></tr></thead><tbody>{guestRecords.map(guest => <tr key={guest.id}>
            <td><strong>{guest.name}</strong></td>
            <td>{guest.email}<span>{guest.phone || "—"}</span></td>
            <td>{guest.city || "—"}</td>
            <td>{guest.stays}</td>
            <td>{formatMoney(guest.spend)}</td>
            <td className="row-actions"><button className="admin-link" onClick={() => setSelectedGuest(guest)}>History</button><button className={`admin-link${canEditCurrent ? "" : " locked-btn"}`} onClick={guarded(() => { setGuestDraft({ id: guest.id, name: guest.name, email: guest.email, phone: guest.phone, city: guest.city }); setGuestDraftNew(false); })}><Pencil size={13} /> Edit</button><button className={`admin-link danger${canEditCurrent ? "" : " locked-btn"}`} onClick={guarded(() => setConfirmGuestId(guest.id))}><Trash2 size={13} /> Delete</button></td>
          </tr>)}</tbody></table></div>}
          {savedNote && <p className="pricing-note ok"><Check size={14} /> {savedNote}</p>}
        </>}

        {data && tab === "Payments" && <>
          <section className="kpi-overview pay-summary">
            <SummaryCard icon={<Wallet size={18} />} value={formatMoney(paymentSummary.collected)} label="Collected" tone="green" />
            <SummaryCard icon={<Clock3 size={18} />} value={formatMoney(paymentSummary.pending)} label={`Pending (${paymentSummary.pendingCount})`} tone="amber" />
            <SummaryCard icon={<XCircle size={18} />} value={String(paymentSummary.failed)} label="Failed / refunded" tone="red" />
            <SummaryCard icon={<CreditCard size={18} />} value={String(paymentSummary.total)} label="Transactions" tone="violet" />
          </section>
          <DataTable title="Payment ledger" empty="No payment records found for this period."><table><thead><tr><th>Reservation</th><th>Amount</th><th>Payment status</th><th>Paid at</th></tr></thead><tbody>{paymentsInRange.map(row => <tr key={row.id}><td>{row.reservation_reference}</td><td>{formatMoney(row.amount_inr)} {row.currency}</td><td><Status value={row.status} /></td><td>{row.paid_at ? new Date(row.paid_at).toLocaleString("en-IN", { timeZone: "Asia/Kolkata" }) : "—"}</td></tr>)}</tbody></table></DataTable>
        </>}

        {data && tab === "Reports" && <>
          <section className="revenue-summary" aria-label="Total revenue">
            <div className="rev-head"><div><span className="admin-kicker">FINANCE</span><h2>Total revenue{activeProperty ? ` · ${activeProperty.area}` : " · all properties"}</h2></div><small>Collected payments + recorded booking payments</small></div>
            <div className="rev-grid">
              <SummaryCard icon={<CircleDollarSign size={18} />} value={formatMoney(revenueBuckets.today)} label="Today" tone="green" />
              <SummaryCard icon={<CircleDollarSign size={18} />} value={formatMoney(revenueBuckets.week)} label="This week" tone="teal" />
              <SummaryCard icon={<CircleDollarSign size={18} />} value={formatMoney(revenueBuckets.month)} label="This month" tone="indigo" />
              <SummaryCard icon={<CircleDollarSign size={18} />} value={formatMoney(revenueBuckets.year)} label="This year" tone="violet" />
              <SummaryCard icon={<Wallet size={18} />} value={formatMoney(revenueBuckets.all)} label="All time" tone="amber" />
            </div>
          </section>
          <section className="kpi-overview">
            <SummaryCard icon={<ClipboardList size={18} />} value={String(rangeBookings.length)} label="Bookings" tone="violet" />
            <SummaryCard icon={<CircleDollarSign size={18} />} value={formatMoney(revenue)} label="Revenue collected" tone="green" />
            <SummaryCard icon={<TrendingUp size={18} />} value={`${reports.conversion}%`} label="Confirmed rate" tone="indigo" />
            <SummaryCard icon={<Wallet size={18} />} value={formatMoney(reports.avgBooking)} label="Avg. booking value" tone="teal" />
          </section>
          <section className="report-grid">
            <article className="report-panel"><div className="panel-heading"><div><span className="panel-overline">GUEST MOVEMENT</span><h2>Arrivals &amp; departures</h2><p>Last seven days</p></div><div className="chart-key"><span><i className="blue-key" />Arrivals</span><span><i className="green-key" />Departures</span></div></div><div className="bar-chart">{weekDays.map(day => <div className="chart-column" key={day.date}><div className="bar-pair"><i className="arrival-bar" title={`${day.arrivals} check-ins`} style={{ height: `${Math.max(3, day.arrivals / maxActivity * 100)}%` }} /><i className="departure-bar" title={`${day.departures} check-outs`} style={{ height: `${Math.max(3, day.departures / maxActivity * 100)}%` }} /></div><span>{day.label}</span></div>)}</div></article>
            <article className="report-panel"><div className="panel-heading"><div><span className="panel-overline">PIPELINE</span><h2>Bookings by status</h2><p>Selected period</p></div></div><div className="bar-rows">{reports.statusCounts.length ? reports.statusCounts.map(([status, count]) => <div className="bar-row" key={status}><span className="bar-row-label"><Status value={status} /></span><div className="bar-row-track"><span style={{ width: `${Math.round(count / rangeBookings.length * 100)}%` }} /></div><strong>{count}</strong></div>) : <p className="empty-inline">No bookings in this period.</p>}</div></article>
            <article className="report-panel"><div className="panel-heading"><div><span className="panel-overline">DEMAND</span><h2>Top room types</h2><p>By bookings</p></div></div><div className="bar-rows">{reports.roomTypes.length ? reports.roomTypes.map(([name, count]) => <div className="bar-row" key={name}><span className="bar-row-label plain">{name}</span><div className="bar-row-track"><span className="violet" style={{ width: `${Math.round(count / (reports.roomTypes[0]?.[1] || 1) * 100)}%` }} /></div><strong>{count}</strong></div>) : <p className="empty-inline">No bookings in this period.</p>}</div></article>
            <article className="report-panel"><div className="panel-heading"><div><span className="panel-overline">ENQUIRIES</span><h2>By type</h2><p>Selected period</p></div></div><div className="bar-rows">{reports.enquiryKinds.length ? reports.enquiryKinds.map(([kind, count]) => <div className="bar-row" key={kind}><span className="bar-row-label plain">{kind}</span><div className="bar-row-track"><span className="amber" style={{ width: `${Math.round(count / (reports.enquiryKinds[0]?.[1] || 1) * 100)}%` }} /></div><strong>{count}</strong></div>) : <p className="empty-inline">No enquiries in this period.</p>}</div></article>
          </section>
          <div className="toolbar end"><button className="ghost-button" onClick={exportBookingsCsv}><Download size={14} /> Export bookings CSV</button></div>
        </>}

        {tab === "Settings" && <section className="settings-wrap">
          <article className="settings-card"><h2><SettingsIcon size={16} /> Preferences</h2><p>Personalise this dashboard. Settings are saved to this browser.</p>
            <div className="setting-row"><div><strong>Compact density</strong><small>Tighten spacing to fit more on screen.</small></div><label className="switch"><input type="checkbox" checked={compact} onChange={event => { setCompact(event.target.checked); savePreferences({ compact: event.target.checked }); }} /><span /></label></div>
            <div className="setting-row"><div><strong>Default period</strong><small>Date range applied when you open the dashboard.</small></div><select value={period === "Custom" ? "Today" : period} onChange={event => { const value = event.target.value as Exclude<Period, "Custom">; choosePeriod(value); savePreferences({ period: value }); }}>{(["Today", "This week", "This month", "This year"] as const).map(value => <option key={value} value={value}>{value}</option>)}</select></div>
            {savedNote && <p className="settings-note"><Check size={13} /> {savedNote}</p>}
          </article>
          <article className="settings-card"><h2><User size={16} /> Account</h2><p>Your sign-in details and password.</p>
            <div className="account-row"><span>Username</span><strong>{currentUser?.username ?? (preview ? "preview" : "—")}</strong></div>
            <div className="account-row"><span>Role</span><strong className="role-cap">{currentUser ? (currentUser.isSuper ? "Super admin" : currentUser.role) : "Hotel administrator"}</strong></div>
            <div className="account-row"><span>Properties</span><strong>{totalProperties}</strong></div>
            {currentUser ? <>
              <div className="account-row"><span>Your password</span><strong className="pw-reveal">{revealedPassword !== null ? (revealedPassword || "— not available —") : "••••••••"}<button type="button" className="admin-link" onClick={() => void revealMyPassword()}>{revealedPassword !== null ? "Hide" : "Show"}</button></strong></div>
              {currentUser.isSuper
                ? <p className="pw-note">The super admin password is set in <code>.env.local</code> (SUPERADMIN_PASSWORD). Edit it there and restart to change it.</p>
                : <div className="pw-form">
                    <strong className="pw-form-title">Change password</strong>
                    <input type="password" placeholder="Current password" value={pwCurrent} onChange={event => setPwCurrent(event.target.value)} autoComplete="current-password" />
                    <input type="password" placeholder="New password" value={pwNext} onChange={event => setPwNext(event.target.value)} autoComplete="new-password" />
                    <input type="password" placeholder="Confirm new password" value={pwConfirm} onChange={event => setPwConfirm(event.target.value)} autoComplete="new-password" />
                    <button type="button" className="pricing-publish" onClick={() => void changeMyPassword()} disabled={pwBusy}>{pwBusy ? "Saving…" : "Update password"}</button>
                    {pwErr && <small className="pw-err">{pwErr}</small>}
                    {pwMsg && <small className="pw-ok"><Check size={12} /> {pwMsg}</small>}
                  </div>}
            </> : <p className="pw-note">Sign in to view or change your password.</p>}
            <button className="ghost-button danger" onClick={() => preview ? window.location.assign("/admin/login") : void signOut()}><LogOut size={14} /> {preview ? "Return to sign in" : "Sign out"}</button>
          </article>
          {preview && <article className="settings-card"><h2><RefreshCw size={16} /> Data</h2><p>Edits you make across the dashboard are saved to this browser so they survive a refresh. Reset restores the default records.</p>
            <div className="account-row"><span>Dataset</span><strong>Hari&apos;s Court operations</strong></div>
            <button className="ghost-button" onClick={resetTestData}><RotateCcw size={14} /> Reset data</button>
          </article>}
        </section>}

        {data && tab === "Enquiries" && <>
          <div className="toolbar">
            <div className="search-field"><Search size={15} /><input type="search" value={enquirySearch} onChange={event => setEnquirySearch(event.target.value)} placeholder="Search name, email, phone or type" aria-label="Search enquiries" /></div>
            <div className="filter-chips" role="group" aria-label="Filter by status">
              <button className={enquiryStatusFilter === "all" ? "selected" : ""} onClick={() => setEnquiryStatusFilter("all")}>all</button>
              {ENQUIRY_STATUSES.map(status => <button key={status} className={enquiryStatusFilter === status ? "selected" : ""} onClick={() => setEnquiryStatusFilter(status)}>{status.replace("_", " ")}</button>)}
            </div>
          </div>
          {filteredEnquiries.length === 0 ? <div className="admin-empty-state"><Mail size={28} /><strong>No enquiries match</strong><span>Try a different search, status or period.</span></div>
          : <div className="admin-table-wrap"><div className="table-heading"><h2>Customer enquiries ({filteredEnquiries.length})</h2></div><table><thead><tr><th>Contact</th><th>Type</th><th>Assigned</th><th>Status</th><th>Actions</th></tr></thead><tbody>{filteredEnquiries.map(row => <tr key={row.id}>
            <td><strong>{row.name}</strong><span>{row.email} · {row.phone}</span></td>
            <td>{row.kind}</td>
            <td><select aria-label={`Assign ${row.name}`} value={row.assigned ?? ""} disabled={!canEditCurrent} onChange={event => void update("enquiry", row.id, { assigned: event.target.value })}><option value="">Unassigned</option>{STAFF_NAMES.map(name => <option key={name} value={name}>{name}</option>)}</select></td>
            <td><select aria-label={`Update ${row.name} enquiry`} value={row.status} disabled={!canEditCurrent} onChange={event => void update("enquiry", row.id, { status: event.target.value })}>{ENQUIRY_STATUSES.map(status => <option key={status} value={status}>{status.replace("_", " ")}</option>)}</select></td>
            <td className="row-actions"><button className="admin-link" onClick={() => setSelectedEnquiry(row)}>View</button><button className={`admin-link danger${canEditCurrent ? "" : " locked-btn"}`} onClick={guarded(() => setConfirmEnquiryId(row.id))}><Trash2 size={13} /> Delete</button></td>
          </tr>)}</tbody></table></div>}
          {savedNote && <p className="pricing-note ok"><Check size={14} /> {savedNote}</p>}
        </>}
      </div>
    </section>

    {selectedBooking && (() => {
      const charges = selectedBooking.charges ?? [];
      const payments = selectedBooking.payments ?? [];
      const due = selectedBooking.total_amount_inr + charges.reduce((sum, item) => sum + item.amount, 0);
      const paid = payments.reduce((sum, item) => sum + item.amount, 0);
      const balance = due - paid;
      return <div className="booking-modal" role="dialog" aria-modal="true" aria-label="Booking details" onClick={() => setSelectedBooking(null)}>
      <div className="booking-dialog" onClick={event => event.stopPropagation()}>
        <header className="booking-dialog-head"><div><span className="admin-kicker">RESERVATION</span><h2>{selectedBooking.reference}</h2></div><button className="dialog-close" onClick={() => setSelectedBooking(null)} aria-label="Close details"><X size={18} /></button></header>
        <div className="booking-dialog-status"><Status value={selectedBooking.status} /></div>
        <label className="booking-status-edit">
          <span>Update status</span>
          <select value={selectedBooking.status} disabled={!canEditCurrent} onChange={event => { const status = event.target.value; setSelectedBooking(current => (current ? { ...current, status } : current)); }}>
            <option value="pending_payment">Pending payment</option>
            <option value="confirmed">Payment completed / Confirmed</option>
            <option value="checked_in">Checked in</option>
            <option value="checked_out">Checked out</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </label>
        <div className="folio">
          <div className="folio-head"><span>Charges</span><strong>{formatMoney(due)} due</strong></div>
          <ul className="folio-list">
            <li><span>{selectedBooking.room_types?.name ?? "Room"} · stay</span><em>{formatMoney(selectedBooking.total_amount_inr)}</em></li>
            {charges.map(item => <li key={item.id}><span>{item.label}</span>{item.image && (
              <a href={item.image} target="_blank" rel="noreferrer" className="folio-thumb" title="View receipt">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={item.image} alt={`${item.label} receipt`} />
              </a>
            )}<em>{formatMoney(item.amount)}</em><button type="button" className={`folio-remove${canEditCurrent ? "" : " locked-btn"}`} onClick={guarded(() => removeBookingCharge(item.id))} aria-label={`Remove ${item.label}`}><X size={12} /></button></li>)}
          </ul>
          <div className="folio-add">
            <input value={chargeLabel} onChange={event => setChargeLabel(event.target.value)} placeholder="Extra charge (e.g. Extra night)" aria-label="Charge label" disabled={!canEditCurrent} />
            <input type="number" min={0} value={chargeAmount} onChange={event => setChargeAmount(event.target.value)} placeholder="₹" aria-label="Charge amount" disabled={!canEditCurrent} />
            <button type="button" className={`folio-btn${canEditCurrent ? "" : " locked-btn"}`} onClick={guarded(addBookingCharge)}>Add</button>
          </div>
          <div className="folio-attach">
            <label className="folio-attach-btn"><Paperclip size={12} /> {chargeUploading ? "Uploading…" : chargeImage ? "Receipt attached" : "Attach receipt (optional)"}<input type="file" accept="image/png,image/jpeg,image/webp" hidden disabled={!canEditCurrent} onChange={event => { const picked = event.target.files?.[0]; if (picked) void uploadChargeImage(picked); event.target.value = ""; }} /></label>
            {chargeImage && (
              <a href={chargeImage} target="_blank" rel="noreferrer" className="folio-thumb" title="View receipt">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={chargeImage} alt="Receipt preview" />
              </a>
            )}
            {chargeImage && <button type="button" className="folio-link-remove" onClick={() => setChargeImage("")}>Remove</button>}
          </div>
        </div>
        <div className="folio">
          <div className="folio-head"><span>Payments</span><strong>{formatMoney(paid)} paid</strong></div>
          <ul className="folio-list">
            {payments.length === 0 ? <li className="folio-empty">No payments recorded yet.</li> : payments.map(item => <li key={item.id}><span>{item.note || "Payment"}<small>{new Date(item.at).toLocaleDateString("en-IN", { day: "2-digit", month: "short", timeZone: "Asia/Kolkata" })}</small></span><em>{formatMoney(item.amount)}</em><button type="button" className={`folio-remove${canEditCurrent ? "" : " locked-btn"}`} onClick={guarded(() => removeBookingPayment(item.id))} aria-label="Remove payment"><X size={12} /></button></li>)}
          </ul>
          <div className="folio-add">
            <input type="number" min={0} value={payAmount} onChange={event => setPayAmount(event.target.value)} placeholder="Amount ₹" aria-label="Payment amount" disabled={!canEditCurrent} />
            <input value={payNote} onChange={event => setPayNote(event.target.value)} placeholder="Note (e.g. Cash, UPI)" aria-label="Payment note" disabled={!canEditCurrent} />
            <button type="button" className={`folio-btn${canEditCurrent ? "" : " locked-btn"}`} onClick={guarded(addBookingPayment)}>Add</button>
          </div>
        </div>
        <div className={`folio-balance ${balance > 0 ? "is-due" : "is-clear"}`}>
          <span>{balance > 0 ? "Remaining to pay" : balance < 0 ? "Overpaid" : "Balance"}</span>
          <strong>{balance === 0 ? "Fully paid" : formatMoney(Math.abs(balance))}</strong>
        </div>
        <div className="booking-dialog-grid">
          <div><span>Guest</span><strong>{selectedBooking.guest_name}</strong></div>
          <div><span>Guests</span><strong>{selectedBooking.guests ?? "\u2014"}</strong></div>
          <div><span>Email</span><strong>{selectedBooking.guest_email || "\u2014"}</strong></div>
          <div><span>Phone</span><strong>{selectedBooking.guest_phone || "\u2014"}</strong></div>
          <div><span>Room type</span><strong>{selectedBooking.room_types?.name ?? "\u2014"}</strong></div>
          <div><span>Property</span><strong>{selectedBooking.room_types?.property_name ?? "\u2014"}</strong></div>
          <div><span>Check-in</span><strong>{selectedBooking.check_in}</strong></div>
          <div><span>Check-out</span><strong>{selectedBooking.check_out}</strong></div>
          <div><span>Amount due</span><strong>{formatMoney(due)}</strong></div>
          <div><span>Paid</span><strong>{formatMoney(paid)}</strong></div>
          <div><span>Balance</span><strong>{formatMoney(Math.max(0, balance))}</strong></div>
          <div><span>Booked at</span><strong>{new Date(selectedBooking.created_at).toLocaleString("en-IN", { timeZone: "Asia/Kolkata" })}</strong></div>
        </div>
        {selectedBooking.special_requests && <div className="booking-dialog-requests"><span>Special requests</span><p>{selectedBooking.special_requests}</p></div>}
        <footer className="booking-dialog-actions">
          <button className={`po-manage${canEditCurrent ? "" : " locked-btn"}`} onClick={guarded(saveBookingFolio)}>Save</button>
        </footer>
      </div>
    </div>; })()}

    {confirmCheckout && (() => {
      const charges = confirmCheckout.charges ?? [];
      const payments = confirmCheckout.payments ?? [];
      const due = confirmCheckout.total_amount_inr + charges.reduce((sum, item) => sum + item.amount, 0);
      const paid = payments.length ? payments.reduce((sum, item) => sum + item.amount, 0) : (confirmCheckout.amount_paid ?? 0);
      const balance = due - paid;
      return <div className="booking-modal" role="dialog" aria-modal="true" aria-label="Confirm check-out" onClick={() => setConfirmCheckout(null)}>
        <div className="booking-dialog confirm-dialog" onClick={event => event.stopPropagation()}>
          <h2>Check out {confirmCheckout.guest_name}?</h2>
          <p>{confirmCheckout.reference} · {confirmCheckout.room_types?.name ?? "Room"}{balance > 0 ? `. Outstanding balance of ${formatMoney(balance)} is still due \u2014 collect it before checking out.` : ". The folio is fully settled."}</p>
          <footer className="booking-dialog-actions">
            <button className="po-manage" onClick={() => { void update("reservation", confirmCheckout.reference, { status: "checked_out" }); setConfirmCheckout(null); }}>Check out guest</button>
            <button className="ghost-button" onClick={() => setConfirmCheckout(null)}>Cancel</button>
          </footer>
        </div>
      </div>; })()}

    {roomDraft && <div className="booking-modal" role="dialog" aria-modal="true" aria-label={roomDraftNew ? "Add room type" : "Edit room type"} onClick={() => setRoomDraft(null)}>
      <div className="booking-dialog" onClick={event => event.stopPropagation()}>
        <header className="booking-dialog-head"><div><span className="admin-kicker">{roomDraftNew ? "NEW ROOM TYPE" : "EDIT ROOM TYPE"}</span><h2>Room type</h2></div><button className="dialog-close" onClick={() => setRoomDraft(null)} aria-label="Close"><X size={18} /></button></header>
        <div className="offer-form">
          <label className="offer-field wide"><span>Room name</span><input value={roomDraft.name} onChange={event => setRoomDraft({ ...roomDraft, name: event.target.value })} placeholder="Superior Room" /></label>
          <label className="offer-field wide"><span>Property</span><select value={roomDraft.property_name} onChange={event => setRoomDraft({ ...roomDraft, property_name: event.target.value })}>{(properties.length ? properties.map(item => item.location) : [roomDraft.property_name]).map(location => <option key={location} value={location}>{location}</option>)}</select></label>
          <label className="offer-field"><span>Rate / night (₹)</span><input type="number" min={0} step={100} value={roomDraft.rate_inr} onChange={event => setRoomDraft({ ...roomDraft, rate_inr: Math.max(0, Math.round(Number(event.target.value) || 0)) })} /></label>
          <label className="offer-field"><span>Inventory</span><input type="number" min={0} value={roomDraft.inventory} onChange={event => setRoomDraft({ ...roomDraft, inventory: Math.max(0, Math.round(Number(event.target.value) || 0)) })} /></label>
          <label className="offer-field toggle-field"><span>On sale</span><label className="switch"><input type="checkbox" checked={roomDraft.active} onChange={event => setRoomDraft({ ...roomDraft, active: event.target.checked })} /><span /></label></label>
        </div>
        <footer className="booking-dialog-actions">
          <button className="pricing-publish" onClick={saveRoomDraft} disabled={!roomDraft.name.trim()}>{roomDraftNew ? "Add room type" : "Save changes"}</button>
          <button className="ghost-button" onClick={() => setRoomDraft(null)}>Cancel</button>
          {!roomDraft.name.trim() && <small>A room name is required.</small>}
        </footer>
      </div>
    </div>}

    {(() => { const target = data?.rooms.find(room => room.id === confirmRoomId); if (!target) return null; const blocked = data ? roomHasBookings(data, target.name, target.property_name) : false; return <div className="booking-modal" role="dialog" aria-modal="true" aria-label="Confirm delete" onClick={() => setConfirmRoomId(null)}>
      <div className="booking-dialog confirm-dialog" onClick={event => event.stopPropagation()}>
        <h2>Delete room type?</h2>
        {blocked ? <p>“{target.name}” at {target.property_name} has active bookings and cannot be deleted. Cancel those bookings first, or set it off sale instead.</p> : <p>“{target.name}” at {target.property_name} will be removed from the inventory.</p>}
        <footer className="booking-dialog-actions">
          {!blocked && <button className="ghost-button danger" onClick={() => deleteRoom(target)}><Trash2 size={14} /> Delete</button>}
          <button className="ghost-button" onClick={() => setConfirmRoomId(null)}>{blocked ? "Close" : "Cancel"}</button>
        </footer>
      </div>
    </div>; })()}

    {selectedEnquiry && <div className="booking-modal" role="dialog" aria-modal="true" aria-label="Enquiry details" onClick={() => setSelectedEnquiry(null)}>
      <div className="booking-dialog" onClick={event => event.stopPropagation()}>
        <header className="booking-dialog-head"><div><span className="admin-kicker">ENQUIRY</span><h2>{selectedEnquiry.name}</h2></div><button className="dialog-close" onClick={() => setSelectedEnquiry(null)} aria-label="Close"><X size={18} /></button></header>
        <div className="booking-dialog-grid">
          <div><span>Email</span><strong>{selectedEnquiry.email}</strong></div>
          <div><span>Phone</span><strong>{selectedEnquiry.phone}</strong></div>
          <div><span>Type</span><strong>{selectedEnquiry.kind}</strong></div>
          <div><span>Received</span><strong>{new Date(selectedEnquiry.created_at).toLocaleString("en-IN", { timeZone: "Asia/Kolkata" })}</strong></div>
        </div>
        <div className="booking-dialog-requests"><span>Message</span><p>{selectedEnquiry.message}</p></div>
        <div className="offer-form" style={{ marginTop: 14 }}>
          <label className="offer-field"><span>Status</span><select value={selectedEnquiry.status} onChange={event => { void update("enquiry", selectedEnquiry.id, { status: event.target.value }); setSelectedEnquiry({ ...selectedEnquiry, status: event.target.value }); }}>{ENQUIRY_STATUSES.map(status => <option key={status} value={status}>{status.replace("_", " ")}</option>)}</select></label>
          <label className="offer-field"><span>Assigned to</span><select value={selectedEnquiry.assigned ?? ""} onChange={event => { void update("enquiry", selectedEnquiry.id, { assigned: event.target.value }); setSelectedEnquiry({ ...selectedEnquiry, assigned: event.target.value }); }}><option value="">Unassigned</option>{STAFF_NAMES.map(name => <option key={name} value={name}>{name}</option>)}</select></label>
          <label className="offer-field wide"><span>Internal notes</span><textarea rows={3} value={selectedEnquiry.notes ?? ""} onChange={event => { void update("enquiry", selectedEnquiry.id, { notes: event.target.value }); setSelectedEnquiry({ ...selectedEnquiry, notes: event.target.value }); }} placeholder="Add a follow-up note for the team…" /></label>
        </div>
        <footer className="booking-dialog-actions">
          <button className="ghost-button danger" onClick={() => setConfirmEnquiryId(selectedEnquiry.id)}><Trash2 size={14} /> Delete enquiry</button>
        </footer>
      </div>
    </div>}

    {confirmEnquiryId && <div className="booking-modal" role="dialog" aria-modal="true" aria-label="Confirm delete" onClick={() => setConfirmEnquiryId(null)}>
      <div className="booking-dialog confirm-dialog" onClick={event => event.stopPropagation()}>
        <h2>Delete enquiry?</h2>
        <p>This enquiry will be permanently removed from the list.</p>
        <footer className="booking-dialog-actions">
          <button className="ghost-button danger" onClick={() => deleteEnquiry(confirmEnquiryId)}><Trash2 size={14} /> Delete</button>
          <button className="ghost-button" onClick={() => setConfirmEnquiryId(null)}>Cancel</button>
        </footer>
      </div>
    </div>}

    {guestDraft && <div className="booking-modal" role="dialog" aria-modal="true" aria-label={guestDraftNew ? "Add guest" : "Edit guest"} onClick={() => setGuestDraft(null)}>
      <div className="booking-dialog" onClick={event => event.stopPropagation()}>
        <header className="booking-dialog-head"><div><span className="admin-kicker">{guestDraftNew ? "NEW GUEST" : "EDIT GUEST"}</span><h2>Guest record</h2></div><button className="dialog-close" onClick={() => setGuestDraft(null)} aria-label="Close"><X size={18} /></button></header>
        <div className="offer-form">
          <label className="offer-field wide"><span>Full name</span><input value={guestDraft.name} onChange={event => setGuestDraft({ ...guestDraft, name: event.target.value })} placeholder="Riya Mehta" /></label>
          <label className="offer-field wide"><span>Email</span><input type="email" value={guestDraft.email} onChange={event => setGuestDraft({ ...guestDraft, email: event.target.value })} placeholder="guest@example.com" /></label>
          <label className="offer-field"><span>Phone</span><input value={guestDraft.phone} onChange={event => setGuestDraft({ ...guestDraft, phone: event.target.value })} placeholder="+91 98xxx xxxxx" /></label>
          <label className="offer-field"><span>City</span><input value={guestDraft.city} onChange={event => setGuestDraft({ ...guestDraft, city: event.target.value })} placeholder="Gurugram" /></label>
        </div>
        <footer className="booking-dialog-actions">
          <button className="pricing-publish" onClick={saveGuestDraft} disabled={!guestDraft.name.trim() || !isEmailValid(guestDraft.email)}>{guestDraftNew ? "Add guest" : "Save changes"}</button>
          <button className="ghost-button" onClick={() => setGuestDraft(null)}>Cancel</button>
          {(!guestDraft.name.trim() || !isEmailValid(guestDraft.email)) && <small>A name and a valid email are required.</small>}
        </footer>
      </div>
    </div>}

    {selectedGuest && <div className="booking-modal" role="dialog" aria-modal="true" aria-label="Guest history" onClick={() => setSelectedGuest(null)}>
      <div className="booking-dialog" onClick={event => event.stopPropagation()}>
        <header className="booking-dialog-head"><div><span className="admin-kicker">GUEST</span><h2>{selectedGuest.name}</h2></div><button className="dialog-close" onClick={() => setSelectedGuest(null)} aria-label="Close"><X size={18} /></button></header>
        <div className="booking-dialog-grid">
          <div><span>Email</span><strong>{selectedGuest.email}</strong></div>
          <div><span>Phone</span><strong>{selectedGuest.phone || "—"}</strong></div>
          <div><span>City</span><strong>{selectedGuest.city || "—"}</strong></div>
          <div><span>Lifetime value</span><strong>{formatMoney(guestStats.get(selectedGuest.email.toLowerCase())?.spend ?? 0)}</strong></div>
        </div>
        <div className="booking-dialog-requests"><span>Booking history</span>
          {(data?.reservations.filter(row => row.guest_email.toLowerCase() === selectedGuest.email.toLowerCase()) ?? []).length === 0
            ? <p>No bookings yet for this guest.</p>
            : <div className="guest-history">{data?.reservations.filter(row => row.guest_email.toLowerCase() === selectedGuest.email.toLowerCase()).map(row => <div className="guest-history-row" key={row.reference}><strong>{row.reference}</strong><span>{row.room_types?.name} · {row.room_types?.property_name}</span><span>{row.check_in} – {row.check_out}</span><em>{formatMoney(row.total_amount_inr)}</em><Status value={row.status} /></div>)}</div>}
        </div>
      </div>
    </div>}

    {(() => { const target = data?.guests.find(guest => guest.id === confirmGuestId); if (!target) return null; return <div className="booking-modal" role="dialog" aria-modal="true" aria-label="Confirm remove" onClick={() => setConfirmGuestId(null)}>
      <div className="booking-dialog confirm-dialog" onClick={event => event.stopPropagation()}>
        <h2>Remove guest?</h2>
        <p>“{target.name}” will be removed from the guest directory. Existing bookings are not affected.</p>
        <footer className="booking-dialog-actions">
          <button className="ghost-button danger" onClick={() => deleteGuest(target.id)}><Trash2 size={14} /> Remove</button>
          <button className="ghost-button" onClick={() => setConfirmGuestId(null)}>Cancel</button>
        </footer>
      </div>
    </div>; })()}

    {bookingDraft && data && (() => {
      const roomsHere = data.rooms.filter(room => room.property_name === bookingDraft.property);
      const room = roomsHere.find(item => item.name === bookingDraft.roomName);
      const validDates = bookingDraft.checkOut > bookingDraft.checkIn;
      const nights = validDates ? Math.max(1, Math.round((Date.parse(`${bookingDraft.checkOut}T00:00:00Z`) - Date.parse(`${bookingDraft.checkIn}T00:00:00Z`)) / 86400000)) : 0;
      const bookedOnDates = room ? data.reservations.filter(r => ["confirmed", "pending_payment", "checked_in"].includes(r.status) && r.room_types?.name === room.name && r.room_types?.property_name === room.property_name && r.check_in < bookingDraft.checkOut && r.check_out > bookingDraft.checkIn).length : 0;
      const available = room ? room.inventory - bookedOnDates : 0;
      const canSave = Boolean(room) && validDates && bookingDraft.guestName.trim() !== "" && isEmailValid(bookingDraft.guestEmail) && available > 0;
      return <div className="booking-modal" role="dialog" aria-modal="true" aria-label="Create booking" onClick={() => setBookingDraft(null)}>
        <div className="booking-dialog" onClick={event => event.stopPropagation()}>
          <header className="booking-dialog-head"><div><span className="admin-kicker">NEW BOOKING</span><h2>Create booking</h2></div><button className="dialog-close" onClick={() => setBookingDraft(null)} aria-label="Close"><X size={18} /></button></header>
          <div className="offer-form">
            <label className="offer-field"><span>Property</span><select value={bookingDraft.property} onChange={event => setBookingDraft({ ...bookingDraft, property: event.target.value, roomName: "" })}>{properties.map(item => <option key={item.slug} value={item.location}>{item.area}, {item.city}</option>)}</select></label>
            <label className="offer-field"><span>Room type</span><select value={bookingDraft.roomName} onChange={event => setBookingDraft({ ...bookingDraft, roomName: event.target.value })}><option value="">Select a room…</option>{roomsHere.map(item => <option key={item.id} value={item.name}>{item.name} · {formatMoney(item.rate_inr)}</option>)}</select></label>
            <label className="offer-field"><span>Check-in</span><input type="date" value={bookingDraft.checkIn} onChange={event => setBookingDraft({ ...bookingDraft, checkIn: event.target.value })} /></label>
            <label className="offer-field"><span>Check-out</span><input type="date" value={bookingDraft.checkOut} onChange={event => setBookingDraft({ ...bookingDraft, checkOut: event.target.value })} /></label>
            <label className="offer-field"><span>Guests</span><input type="number" min={1} max={12} value={bookingDraft.guests} onChange={event => setBookingDraft({ ...bookingDraft, guests: Math.max(1, Math.round(Number(event.target.value) || 1)) })} /></label>
            <label className="offer-field"><span>Guest name</span><input value={bookingDraft.guestName} onChange={event => setBookingDraft({ ...bookingDraft, guestName: event.target.value })} placeholder="Guest full name" /></label>
            <label className="offer-field"><span>Guest email</span><input type="email" value={bookingDraft.guestEmail} onChange={event => setBookingDraft({ ...bookingDraft, guestEmail: event.target.value })} placeholder="guest@example.com" /></label>
            <label className="offer-field"><span>Guest phone</span><input value={bookingDraft.guestPhone} onChange={event => setBookingDraft({ ...bookingDraft, guestPhone: event.target.value })} placeholder="+91 98xxx xxxxx" /></label>
            <label className="offer-field"><span>Status</span><select value={bookingDraft.status} onChange={event => setBookingDraft({ ...bookingDraft, status: event.target.value })}><option value="pending_payment">Pending payment</option><option value="confirmed">Payment completed / Confirmed</option><option value="checked_in">Checked in</option><option value="checked_out">Checked out</option><option value="cancelled">Cancelled</option></select></label>
            <label className="offer-field"><span>Amount paid (₹)</span><input type="number" min={0} max={room ? room.rate_inr * nights : undefined} value={bookingDraft.amountPaid} onChange={event => setBookingDraft({ ...bookingDraft, amountPaid: Math.max(0, Math.round(Number(event.target.value) || 0)) })} placeholder="0" /></label>
          </div>
          <div className="booking-summary-line">
            {!validDates ? <span className="booking-warn">Check-out must be after check-in.</span>
              : room ? <span className={available > 0 ? "" : "booking-warn"}>{available > 0 ? `${available} of ${room.inventory} rooms available · ${nights} night${nights === 1 ? "" : "s"} · ${formatMoney(room.rate_inr * nights)}` : "No rooms available for these dates."}</span>
              : <span>Select a room to see availability and price.</span>}
          </div>
          <footer className="booking-dialog-actions">
            <button className="pricing-publish" onClick={createBooking} disabled={!canSave}>Create booking</button>
            <button className="ghost-button" onClick={() => setBookingDraft(null)}>Cancel</button>
          </footer>
        </div>
      </div>;
    })()}

    <style jsx global>{`
      body { background: #f3f5f9; }
      .admin-app { min-height: 100vh; display: grid; grid-template-columns: 218px minmax(0,1fr); color: #222936; font-family: var(--sans); }
      .admin-sidebar { position: sticky; top: 0; display: flex; height: 100vh; flex-direction: column; padding: 20px 14px 15px; border-right: 1px solid #e7eaf0; background: #fff; }
      .admin-brand { display: flex; min-height: 45px; align-items: center; gap: 10px; padding: 0 6px; color: #1f5dd1; font-size: 13px; font-weight: 700; letter-spacing: .04em; } .admin-brand-logo { flex-direction: column; align-items: flex-start; gap: 0; padding: 4px 6px; text-decoration: none; }
      .admin-brand-mark { display: grid; width: 38px; height: 38px; place-items: center; border-radius: 9px; background: #edf3ff; color: #2864e8; font-size: 22px; }
      .admin-brand small { display: block; margin-top: 3px; color: #9098a7; font-size: 8px; letter-spacing: .13em; }
      .admin-clock { display: grid; gap: 4px; margin: 19px -14px 12px; padding: 14px 20px; border-top: 1px solid #f0f1f4; border-bottom: 1px solid #f0f1f4; }
      .admin-clock span, .admin-nav > p, .admin-kicker { color: #8b95a7; font-size: 9px; font-weight: 700; letter-spacing: .12em; }
      .admin-clock strong { color: #2864e8; font-size: 16px; font-variant-numeric: tabular-nums; }
      .admin-clock small { color: #777f8e; font-size: 10px; }
      .admin-nav { display: grid; flex: 1 1 auto; min-height: 0; gap: 3px; overflow-y: auto; }
      .admin-nav > p { margin: 14px 7px 5px; }
      .admin-nav-item { display: flex; min-height: 36px; align-items: center; gap: 10px; padding: 0 9px; border: 0; border-radius: 6px; background: transparent; color: #525c6e; font-size: 11px; text-align: left; }
      .admin-nav-item:hover { background: #f4f7fc; color: #2864e8; }
      .admin-nav-item.active { background: #eaf1ff; color: #205ed4; font-weight: 700; }
      .admin-connection { display: grid; grid-template-columns: 16px 1fr; gap: 2px 7px; margin-top: 20px; padding: 12px 10px; border: 1px solid #e7edf3; border-radius: 8px; background: #fbfcfe; }
      .connection-dot { grid-row: span 2; color: #13ae7e; font-size: 16px; }
      .admin-connection strong { font-size: 10px; }
      .admin-connection small { color: #858d9b; font-size: 9px; }
      .admin-connection.disconnected .connection-dot { color: #e45757; }
      .admin-workspace { min-width: 0; }
      .admin-topbar { position: sticky; top: 0; z-index: 4; display: flex; min-height: 63px; align-items: center; justify-content: space-between; gap: 20px; padding: 0 26px; border-bottom: 1px solid #e8ebf1; background: #ffffffed; backdrop-filter: blur(12px); }
      .topbar-label, .topbar-tools { display: flex; align-items: center; }
      .topbar-label { gap: 11px; color: #788295; font-size: 10px; font-weight: 700; }
      .topbar-divider { color: #c9ced8; }
      .topbar-tools { gap: 17px; }
      .topbar-date { color: #8b95a7; font-size: 10px; }
      .admin-icon-button { position: relative; display: grid; width: 34px; height: 34px; place-items: center; border: 1px solid #edf0f4; border-radius: 50%; background: white; color: #5e6878; }
      .admin-icon-button i { position: absolute; top: -3px; right: -3px; display: grid; min-width: 15px; height: 15px; place-items: center; border-radius: 10px; background: #e45252; color: white; font-size: 8px; font-style: normal; }
      .admin-profile { display: flex; align-items: center; gap: 8px; }
      .profile-avatar { display: grid; width: 31px; height: 31px; place-items: center; border: 1px solid #e6ebf1; border-radius: 50%; background: #f1f5fb; color: #2864e8; font-size: 9px; font-weight: 700; }
      .admin-profile strong, .admin-profile small { display: block; }
      .admin-profile strong { font-size: 10px; }
      .admin-profile small { margin-top: 3px; color: #8c95a4; font-size: 9px; }
      .admin-content { width: 100%; max-width: none; margin: 0; padding: 25px 26px 32px; }
      .admin-title-row { display: flex; align-items: center; justify-content: space-between; margin-bottom: 18px; }
      .admin-title-row h1 { margin: 5px 0 3px; color: #202633; font-family: var(--sans); font-size: 23px; font-weight: 700; }
      .admin-title-row p { margin: 0; color: #8a93a2; font-size: 10px; }
      .refresh-button { display: grid; width: 34px; height: 34px; place-items: center; border: 1px solid #e5e9f0; border-radius: 6px; background: white; color: #616c7d; }
      .preview-banner { display: flex; align-items: center; gap: 8px; margin-bottom: 14px; padding: 9px 12px; border: 1px solid #f1dfad; border-radius: 6px; background: #fff9e9; color: #87651d; font-size: 10px; font-weight: 700; }
      .preview-banner span { color: #8e8060; font-weight: 400; }
      .period-bar { display: flex; min-height: 52px; align-items: center; justify-content: space-between; gap: 14px; margin-bottom: 19px; padding: 8px 12px; border: 1px solid #e8ebf1; border-radius: 8px; background: white; box-shadow: 0 2px 7px #29364d06; }
      .period-bar > label { display: flex; align-items: center; gap: 9px; color: #788295; }
      .period-bar > label > span:first-of-type { color: #596476; font-size: 9px; font-weight: 700; }
      .period-bar input { width: 116px; height: 31px; padding: 0 7px; border: 1px solid #edf0f4; border-radius: 5px; color: #687386; font-size: 9px; }
      .range-separator { color: #9aa2af; font-size: 9px; }
      .period-presets { display: flex; gap: 5px; }
      .period-presets button { padding: 8px 10px; border: 1px solid transparent; border-radius: 5px; background: transparent; color: #6e788a; font-size: 9px; white-space: nowrap; }
      .period-presets button:hover, .period-presets button.selected { border-color: #e2eaff; background: #f1f5ff; color: #2864e8; }
      .overview-block { margin-bottom: 14px; }
      .block-heading { display: flex; align-items: center; justify-content: space-between; margin-bottom: 9px; }
      .block-heading h2 { margin: 0; color: #788295; font-size: 9px; font-weight: 700; letter-spacing: .1em; text-transform: uppercase; }
      .block-heading span { color: #9aa2af; font-size: 9px; }
      .metric-grid, .summary-grid { display: grid; grid-template-columns: repeat(4, minmax(0,1fr)); gap: 12px; }
      .metric-card { display: flex; min-height: 100px; align-items: center; gap: 12px; padding: 15px; border-radius: 8px; color: white; box-shadow: 0 5px 12px #1c335010; }
      .metric-blue { background: linear-gradient(125deg,#2563eb,#1453cf); }
      .metric-cyan { background: linear-gradient(125deg,#12acd2,#0793bf); }
      .metric-green { background: linear-gradient(125deg,#12b981,#079b72); }
      .metric-orange { background: linear-gradient(125deg,#f4a11d,#e98709); }
      .metric-icon { display: grid; flex: 0 0 37px; width: 37px; height: 37px; place-items: center; border: 1px solid #ffffff32; border-radius: 8px; background: #ffffff18; }
      .metric-value { font-size: 24px; font-weight: 700; line-height: 1; font-variant-numeric: tabular-nums; }
      .metric-label { margin-top: 7px; font-size: 10px; font-weight: 700; }
      .metric-note { margin-top: 4px; color: #ffffffc4; font-size: 8px; }
      .summary-grid { margin-bottom: 12px; }
      .summary-card { position: relative; display: flex; min-height: 72px; align-items: center; gap: 10px; padding: 12px 13px; overflow: hidden; border: 1px solid #e9ecf2; border-radius: 8px; background: white; box-shadow: 0 2px 7px #29364d05; }
      .summary-card::before { position: absolute; top: 0; bottom: 0; left: 0; width: 3px; background: var(--tone); content: ""; }
      .summary-icon { display: grid; flex: 0 0 32px; width: 32px; height: 32px; place-items: center; border-radius: 8px; background: color-mix(in srgb, var(--tone) 10%, white); color: var(--tone); }
      .summary-value { color: #222936; font-size: 19px; font-weight: 700; line-height: 1; }
      .summary-label { margin-top: 5px; color: #8a93a2; font-size: 8px; }
      .tone-blue { --tone: #2864e8; } .tone-green { --tone: #16ad7e; } .tone-amber { --tone: #ec9a1c; } .tone-red { --tone: #e15159; } .tone-violet { --tone: #7764d8; }
      .room-summary { margin-top: 0; }
      .analytics-grid { display: grid; grid-template-columns: 1fr 1.16fr 1.05fr; gap: 12px; margin-top: 14px; }
      .analytics-panel { min-width: 0; min-height: 190px; padding: 15px; border: 1px solid #e8ebf1; border-radius: 8px; background: white; box-shadow: 0 2px 8px #29364d05; }
      .panel-heading { display: flex; min-height: 34px; align-items: flex-start; justify-content: space-between; gap: 7px; }
      .panel-heading h2 { margin: 0; color: #303847; font-size: 11px; font-weight: 700; }
      .panel-heading p { margin: 4px 0 0; color: #969eab; font-size: 8px; }
      .small-select { display: flex; align-items: center; gap: 6px; padding: 5px 7px; border: 1px solid #edf0f4; border-radius: 5px; color: #8790a0; font-size: 8px; }
      .occupancy-content { display: flex; align-items: center; justify-content: center; gap: clamp(12px,2vw,25px); padding-top: 14px; }
      .occupancy-donut { display: grid; flex: 0 0 108px; width: 108px; height: 108px; place-items: center; border-radius: 50%; }
      .occupancy-donut > div { display: grid; width: 78px; height: 78px; align-content: center; justify-items: center; border-radius: 50%; background: white; }
      .occupancy-donut strong { color: #263247; font-size: 18px; }
      .occupancy-donut span { margin-top: 3px; color: #8a93a2; font-size: 8px; }
      .occupancy-legend { display: grid; gap: 10px; }
      .legend-row { display: grid; grid-template-columns: 8px 1fr auto; align-items: center; gap: 7px; color: #687386; font-size: 8px; }
      .legend-row strong { color: #344052; font-size: 9px; }
      .legend-dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; }
      .legend-blue { background: #2864e8; } .legend-green, .available-dot { background: #17b989; } .legend-gray { background: #c8ced8; } .reserved-dot { background: #2864e8; } .offline-dot { background: #e15159; }
      .chart-key { display: flex; gap: 10px; color: #818b9a; font-size: 8px; white-space: nowrap; }
      .chart-key span { display: inline-flex; align-items: center; gap: 4px; }
      .chart-key i { width: 6px; height: 6px; border-radius: 50%; }
      .blue-key, .arrival-bar { background: #3672e9; } .green-key, .departure-bar { background: #16b987; }
      .bar-chart { display: grid; height: 118px; grid-template-columns: repeat(7,1fr); gap: 8px; align-items: end; margin-top: 13px; padding: 0 3px; border-bottom: 1px solid #e8ebf1; background: repeating-linear-gradient(to bottom, transparent 0, transparent 28px, #f0f2f6 29px, transparent 30px); }
      .chart-column { display: grid; height: 100%; grid-template-rows: 1fr 15px; justify-items: center; color: #8790a0; font-size: 8px; }
      .bar-pair { display: flex; width: 100%; height: 100%; align-items: end; justify-content: center; gap: 3px; }
      .bar-pair i { width: 7px; min-height: 3px; border-radius: 2px 2px 0 0; }
      .activity-list { display: grid; margin-top: 7px; }
      .activity-row { display: grid; min-height: 34px; grid-template-columns: 25px minmax(0,1fr) auto; align-items: center; gap: 7px; border-top: 1px solid #f0f2f6; }
      .activity-icon { display: grid; width: 22px; height: 22px; place-items: center; border-radius: 6px; }
      .activity-booking { background: #eaf1ff; color: #2864e8; } .activity-payment { background: #e9f8f2; color: #13a775; } .activity-enquiry { background: #fff3df; color: #df9419; }
      .activity-copy { min-width: 0; }
      .activity-copy strong, .activity-copy small { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      .activity-copy strong { color: #394354; font-size: 8px; }
      .activity-copy small { margin-top: 3px; color: #929aaa; font-size: 7px; }
      .activity-row time { color: #8992a0; font-size: 7px; white-space: nowrap; }
      .text-action { display: inline-flex; align-items: center; gap: 4px; border: 0; background: transparent; color: #2864e8; font-size: 8px; }
      .admin-table-wrap { overflow-x: auto; border: 1px solid #e8ebf1; border-radius: 8px; background: white; }
      .table-heading { display: flex; align-items: center; justify-content: space-between; padding: 16px; border-bottom: 1px solid #edf0f4; }
      .table-heading h2 { margin: 0; font-size: 13px; }
      table { width: 100%; border-collapse: collapse; font-size: 11px; text-align: left; }
      th { padding: 12px 14px; background: #fafbfc; color: #7f8998; font-size: 8px; letter-spacing: .1em; text-transform: uppercase; white-space: nowrap; }
      td { max-width: 300px; padding: 13px 14px; border-top: 1px solid #f0f2f6; color: #566174; vertical-align: middle; }
      td strong, td span { display: block; } td strong { color: #313b4b; } td span { margin-top: 4px; color: #8e97a5; font-size: 9px; }
      .status { display: inline-block; width: fit-content; padding: 5px 7px; border-radius: 4px; background: #eef0f4; color: #606a7a; font-size: 8px; text-transform: capitalize; white-space: nowrap; }
      .status-confirmed, .status-checked_in, .status-checked_out, .status-paid, .status-resolved, .status-converted { background: #e6f5ef; color: #24805f; }
      .status-pending_payment, .status-created, .status-new, .status-contacted, .status-in_progress { background: #fff4de; color: #996c16; }
      .status-cancelled, .status-failed, .status-closed { background: #fce9e8; color: #b34f4a; }
      .admin-action { border: 0; background: transparent; color: #c4584e; font-size: 10px; text-decoration: underline; }
      .admin-action:disabled { color: #aab0ba; }
      .admin-number { width: 86px; padding: 7px; border: 1px solid #e7eaf0; border-radius: 4px; background: white; }
      .admin-table-wrap select { padding: 7px; border: 1px solid #e7eaf0; border-radius: 4px; background: #fff; }
      .enquiry-message { min-width: 220px; color: #687386; line-height: 1.5; }
      .admin-empty, .admin-error { padding: 18px; border-radius: 6px; color: #818b9a; font-size: 11px; }
      .admin-error { background: #fce9e8; color: #9f413d; }
      .empty-inline { color: #929aaa; font-size: 9px; }
      @media(max-width:1100px) { .admin-app { grid-template-columns: 190px minmax(0,1fr); } .admin-content { padding-right: 16px; padding-left: 16px; } .analytics-grid { grid-template-columns: 1fr 1.15fr; } .activity-panel { grid-column: 1 / -1; } }
      @media(min-width:761px) and (max-width:1100px) { .period-bar { flex-wrap: wrap; } .period-presets { flex-wrap: wrap; justify-content: flex-end; } }
      @media(max-width:760px) { .admin-app { display: block; } .admin-sidebar { position: static; height: auto; padding: 10px 13px; border-right: 0; border-bottom: 1px solid #e7eaf0; } .admin-brand { min-height: 38px; } .admin-clock, .admin-nav > p, .admin-connection { display: none; } .admin-nav { display: flex; gap: 4px; margin-top: 8px; overflow-x: auto; } .admin-nav-item { flex: 0 0 auto; min-height: 34px; padding: 0 9px; } .admin-topbar { min-height: 52px; padding: 0 14px; } .topbar-date { display: none; } .admin-content { padding: 18px 13px 26px; } .period-bar { align-items: flex-start; flex-direction: column; padding: 10px; } .period-bar > label { flex-wrap: wrap; } .period-presets { width: 100%; overflow-x: auto; } .period-presets button { flex: 0 0 auto; } .metric-grid, .summary-grid { grid-template-columns: repeat(2,minmax(0,1fr)); gap: 8px; } .metric-card { min-height: 88px; gap: 8px; padding: 10px; } .metric-icon { flex-basis: 31px; width: 31px; height: 31px; } .metric-value { font-size: 20px; } .analytics-grid { grid-template-columns: 1fr; } .activity-panel { grid-column: auto; } .room-summary { margin-bottom: 8px; } }
      @media(max-width:420px) { .admin-profile span:last-child { display: none; } .topbar-tools { gap: 9px; } .period-bar input { width: 106px; } .summary-card { gap: 7px; padding: 10px 9px; } .summary-icon { flex-basis: 28px; width: 28px; height: 28px; } .summary-value { font-size: 17px; } .metric-note { font-size: 7px; } }
      .admin-app { background: #f7f4ff; color: #29253a; }
      .admin-sidebar { border-color: #ebe5f6; }
      .admin-brand { color: #7029ce; }
      .admin-brand-mark, .profile-avatar { background: #f0e7ff; color: #762bce; border-color: #e9def8; }
      .admin-clock strong { color: #7029ce; }
      .admin-nav-item:hover { background: #f7f2ff; color: #7029ce; }
      .admin-nav-item.active { background: #f0e7ff; color: #7029ce; }
      .admin-connection { border-color: #ece6f5; background: #fdfcff; }
      .admin-topbar { border-color: #ece7f4; }
      .refresh-button { color: #73579c; border-color: #e9e2f2; }
      .period-bar, .summary-card, .analytics-panel, .admin-table-wrap { border-color: #ece7f4; }
      .period-presets button:hover, .period-presets button.selected { border-color: #e9dcfb; background: #f2eaff; color: #7029ce; }
      .metric-blue { background: linear-gradient(125deg,#8b42df,#6824c7); }
      .metric-card { box-shadow: 0 5px 12px #39225f18; }
      .tone-blue { --tone: #762bce; }
      .tone-violet { --tone: #8a45df; }
      .legend-blue, .reserved-dot { background: #762bce; }
      .blue-key, .arrival-bar { background: #8540d7; }
      .activity-booking { background: #f0e7ff; color: #762bce; }
      .text-action { color: #7029ce; }
      .kpi-overview { display: grid; grid-template-columns: repeat(4, minmax(0,1fr)); gap: 12px; margin: 5px 0 16px; }
      .revenue-summary { margin: 5px 0 18px; padding: 16px 18px; border: 1px solid #ece7f4; border-radius: 12px; background: linear-gradient(135deg,#faf7ff,#fff); box-shadow: 0 2px 8px #39225f06; }
      .rev-head { display: flex; align-items: baseline; justify-content: space-between; gap: 12px; margin-bottom: 12px; }
      .rev-head h2 { margin: 3px 0 0; color: #302a3c; font-family: var(--serif); font-size: 23px; font-weight: 400; }
      .rev-head small { color: #948fa0; font-size: 10px; }
      .rev-grid { display: grid; grid-template-columns: repeat(5, minmax(0,1fr)); gap: 12px; }
      @media(max-width:1100px) { .rev-grid { grid-template-columns: repeat(3, minmax(0,1fr)); } }
      @media(max-width:600px) { .rev-grid { grid-template-columns: repeat(2, minmax(0,1fr)); } }
      .tone-indigo { --tone: #5b53d6; } .tone-teal { --tone: #0f9d8a; } .tone-rose { --tone: #d6498b; }
      .property-overview { margin: 18px 0; }
      .po-heading { display: flex; align-items: end; justify-content: space-between; gap: 12px; margin-bottom: 11px; }
      .po-heading > div > span { color: #8b6ab6; font-size: 8px; font-weight: 700; letter-spacing: .14em; }
      .po-heading h2 { margin: 4px 0 0; color: #302a3c; font-family: var(--serif); font-size: 25px; font-weight: 400; }
      .po-heading > small { color: #9691a0; font-size: 9px; }
      .po-grid { display: grid; grid-template-columns: repeat(4, minmax(0,1fr)); gap: 13px; }
      .po-card { display: flex; flex-direction: column; overflow: hidden; border: 1px solid #e9e1f2; border-radius: 11px; background: #fff; box-shadow: 0 3px 10px #39225f08; transition: transform .25s ease, box-shadow .25s ease; }
      .po-card:hover { transform: translateY(-3px); box-shadow: 0 12px 24px #39225f18; }
      .po-media { position: relative; aspect-ratio: 16 / 10; overflow: hidden; background: #efeaf6; }
      .po-media img { width: 100%; height: 100%; object-fit: cover; }
      .po-status { position: absolute; top: 9px; left: 9px; padding: 4px 8px; border-radius: 20px; background: #ffffffe8; color: #1f8a5f; font-size: 8px; font-weight: 700; letter-spacing: .05em; text-transform: uppercase; }
      .po-body { display: flex; flex: 1; flex-direction: column; gap: 4px; padding: 13px 14px 14px; }
      .po-body h3 { margin: 0; color: #302a3c; font-size: 14px; font-weight: 700; }
      .po-body > small { display: inline-flex; align-items: center; gap: 4px; color: #8b8595; font-size: 9px; }
      .po-stats { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin: 9px 0 12px; }
      .po-stats > div { display: grid; gap: 3px; padding: 8px 10px; border: 1px solid #f0ecf5; border-radius: 7px; background: #fbfaff; }
      .po-stats strong { color: #433952; font-size: 14px; }
      .po-stats span { color: #948fa0; font-size: 8px; }
      .po-actions { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: auto; }
      .po-manage, .po-view { display: grid; place-items: center; min-height: 34px; border-radius: 7px; font-size: 10px; font-weight: 700; text-align: center; }
      .po-manage { border: 0; background: linear-gradient(120deg,#8540d7,#6b2fc0); color: #fff; }
      .po-manage:hover { background: linear-gradient(120deg,#7a37ce,#5f28b0); }
      .po-view { border: 1px solid #e3d7f4; background: #fff; color: #6f36ae; text-decoration: none; }
      .po-view:hover { background: #f7f2ff; }
      .admin-sidebar-head { position: relative; display: flex; align-items: center; justify-content: center; gap: 8px; padding: 4px 0 12px; margin-bottom: 4px; border-bottom: 1px solid #ece6f5; }
      .nav-collapse-toggle, .nav-close { display: grid; flex: 0 0 auto; place-items: center; width: 30px; height: 30px; border: 1px solid #ece6f5; border-radius: 7px; background: #fff; color: #73579c; }
      .nav-collapse-toggle { position: absolute; top: 2px; right: 0; }
      .admin-brand-logo .brand-lockup-img { height: 46px; }
      .admin-brand-logo small { text-align: center; }
      .nav-collapse-toggle:hover, .nav-close:hover { background: #f7f2ff; }
      .nav-close, .nav-hamburger, .nav-overlay { display: none; }
      .nav-hamburger { flex: 0 0 auto; place-items: center; width: 34px; height: 34px; margin-right: 2px; border: 1px solid #ece6f5; border-radius: 8px; background: #fff; color: #5e6878; }
      .admin-app.nav-collapsed { grid-template-columns: 76px minmax(0,1fr); }
      .admin-sidebar.is-collapsed { padding-right: 8px; padding-left: 8px; }
      .admin-sidebar.is-collapsed .admin-sidebar-head { flex-direction: column; gap: 8px; padding-bottom: 10px; }
      .admin-sidebar.is-collapsed .nav-collapse-toggle { position: static; }
      .admin-sidebar.is-collapsed .admin-brand-logo { align-items: center; padding: 4px 0; }
      .admin-sidebar.is-collapsed .admin-brand-logo .brand-lockup-img { height: 30px; }
      .admin-sidebar.is-collapsed .admin-brand small { display: none; }
      .admin-sidebar.is-collapsed .admin-clock { display: none; }
      .admin-sidebar.is-collapsed .admin-nav > p, .admin-sidebar.is-collapsed .admin-nav-group > p { display: none; }
      .admin-sidebar.is-collapsed .admin-nav-group { gap: 4px; }
      .admin-sidebar.is-collapsed .admin-nav-item { justify-content: center; gap: 0; padding: 0; font-size: 0; }
      .admin-sidebar.is-collapsed .admin-nav-item svg { font-size: 16px; }
      .admin-sidebar.is-collapsed .admin-connection { grid-template-columns: 1fr; justify-items: center; }
      .admin-sidebar.is-collapsed .admin-connection strong, .admin-sidebar.is-collapsed .admin-connection small { display: none; }
      @media(max-width:1100px) { .kpi-overview { grid-template-columns: repeat(2,minmax(0,1fr)); } .po-grid { grid-template-columns: repeat(2,minmax(0,1fr)); } }
      @media(min-width:761px) { .po-body h3 { font-size: clamp(14px, calc(9px + .4vw), 20px); } .po-stats strong { font-size: clamp(14px, calc(9px + .4vw), 20px); } .po-manage, .po-view { font-size: clamp(10px, calc(6px + .35vw), 14px); min-height: clamp(34px, calc(28px + .4vw), 42px); } }
      @media(max-width:520px) { .po-grid { grid-template-columns: 1fr; } }
      .admin-nav-group { display: grid; gap: 3px; }
      .admin-nav-group > p { margin: 14px 7px 5px; color: #8b95a7; font-size: 9px; font-weight: 700; letter-spacing: .12em; }
      .admin-nav-group:first-child > p { margin-top: 4px; }
      .admin-brand-logo { align-items: center; }
      .property-switch { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 14px; padding: 8px 12px; border: 1px solid #ece7f4; border-radius: 8px; background: #fff; box-shadow: 0 2px 7px #39225f06; }
      .property-switch > label { display: flex; align-items: center; gap: 9px; color: #788295; }
      .property-switch > label > span { color: #596476; font-size: 9px; font-weight: 700; letter-spacing: .08em; }
      .property-switch select { min-width: 200px; height: 34px; padding: 0 10px; border: 1px solid #e7dff3; border-radius: 7px; background: #fff; color: #4a4360; font-size: 11px; }
      .property-switch-note { color: #7029ce; font-size: 10px; font-weight: 600; }
      .location-metrics { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; padding: 14px 0 12px; border-bottom: 1px solid #f0ecf5; }
      .location-metrics > div { display: grid; gap: 4px; }
      .location-metrics span { color: #908b9b; font-size: 9px; }
      .location-metrics strong { color: #382b50; font-size: 15px; }
      .pricing-wrap { display: grid; gap: 14px; }
      .pricing-bar { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 12px; padding: 12px 14px; border: 1px solid #ece7f4; border-radius: 10px; background: #fff; box-shadow: 0 2px 7px #39225f06; }
      .pricing-status strong { display: block; color: #302a3c; font-size: 12px; }
      .pricing-status small { color: #948fa0; font-size: 9px; }
      .pricing-actions { display: flex; flex-wrap: wrap; gap: 8px; }
      .pricing-publish { display: inline-flex; align-items: center; gap: 7px; padding: 9px 16px; border: 0; border-radius: 9px; background: linear-gradient(120deg,#8540d7,#6b2fc0); color: #fff; font-size: 11px; font-weight: 700; }
      .pricing-publish:hover { background: linear-gradient(120deg,#7a37ce,#5f28b0); }
      .pricing-publish:disabled, .pricing-actions .ghost-button:disabled { opacity: .5; cursor: not-allowed; }
      .pricing-note { display: inline-flex; align-items: center; gap: 6px; margin: 0; padding: 9px 12px; border-radius: 8px; font-size: 10px; }
      .pricing-note.ok { background: #e7f7ef; color: #1f8a5f; }
      .pricing-hint { margin: 0; color: #8d8899; font-size: 10px; line-height: 1.6; }
      .pricing-hint code { padding: 1px 5px; border-radius: 4px; background: #f0ebf8; color: #6f36ae; font-size: 9px; }
      .pricing-group-head { display: flex; align-items: baseline; gap: 10px; margin: 6px 0 8px; }
      .pricing-group-head h3 { margin: 0; color: #302a3c; font-size: 14px; font-weight: 700; }
      .pricing-group-head small { color: #948fa0; font-size: 9px; }
      .pricing-empty { color: #948fa0; font-size: 10px; text-align: center; }
      .pricing-wrap select { padding: 7px; border: 1px solid #e7eaf0; border-radius: 4px; background: #fff; }
      .offers-wrap { display: grid; gap: 14px; }
      .admin-link.danger { color: #c04b55; }
      .admin-link { display: inline-flex; align-items: center; gap: 5px; }
      .admin-empty-state { display: grid; justify-items: center; gap: 8px; padding: 46px 20px; border: 1px dashed #e0d7ef; border-radius: 12px; background: #fcfbff; color: #8d8899; text-align: center; }
      .admin-empty-state svg { color: #b79be0; }
      .admin-empty-state strong { color: #39334a; font-size: 14px; }
      .admin-empty-state span { font-size: 10px; }
      .admin-empty-state .pricing-publish { margin-top: 6px; }
      .offer-form { display: grid; grid-template-columns: 1fr 1fr; gap: 12px 14px; }
      .offer-field { display: grid; gap: 5px; }
      .offer-field.wide { grid-column: 1 / -1; }
      .offer-field > span { color: #7a7389; font-size: 9px; font-weight: 700; letter-spacing: .04em; text-transform: uppercase; }
      .offer-field input, .offer-field textarea, .offer-field select { padding: 9px 10px; border: 1px solid #e7dff3; border-radius: 8px; background: #fff; color: #332b45; font-size: 12px; font-family: inherit; }
      .offer-field textarea { resize: vertical; }
      .offer-field.toggle-field { align-content: start; }
      .confirm-dialog { width: min(420px, 100%); }
      .confirm-dialog h2 { margin: 0 0 8px; color: #302a3c; font-family: var(--serif); font-size: 22px; font-weight: 400; }
      .confirm-dialog p { margin: 0; color: #6a6479; font-size: 12px; line-height: 1.6; }
      @media(max-width:600px) { .offer-form { grid-template-columns: 1fr; } }
      .guest-history { display: grid; gap: 7px; margin-top: 6px; }
      .guest-history-row { display: grid; grid-template-columns: auto 1fr auto; gap: 3px 10px; align-items: baseline; padding: 9px 11px; border: 1px solid #efeaf6; border-radius: 8px; background: #fff; }
      .guest-history-row strong { color: #302a3c; font-size: 11px; }
      .guest-history-row span { color: #8d8899; font-size: 10px; }
      .guest-history-row em { color: #433952; font-size: 11px; font-style: normal; font-weight: 600; }
      .guest-history-row .status { grid-column: 3; }
      .booking-summary-line { margin: 12px 0 0; padding: 10px 12px; border-radius: 8px; background: #f7f4fc; color: #4a4360; font-size: 11px; }
      .booking-summary-line .booking-warn { color: #c04b55; font-weight: 600; }
      .role-badge { display: inline-block; padding: 4px 9px; border-radius: 20px; font-size: 9px; font-weight: 700; letter-spacing: .02em; text-transform: capitalize; }
      .role-badge.role-admin { background: #efe7fb; color: #6f36ae; }
      .role-badge.role-manager { background: #e4eefc; color: #2d6ad1; }
      .role-badge.role-editor { background: #e7f7ef; color: #1f8a5f; }
      .role-badge.role-viewer { background: #f0ecf4; color: #726b80; }
      .seo-wrap { display: grid; gap: 14px; }
      .seo-list { display: grid; gap: 13px; }
      .seo-card { padding: 16px 18px; border: 1px solid #ece7f4; border-radius: 11px; background: #fff; box-shadow: 0 2px 8px #39225f05; display: grid; gap: 11px; }
      .seo-card-head { display: flex; align-items: baseline; gap: 10px; }
      .seo-card-head h3 { margin: 0; color: #302a3c; font-size: 14px; font-weight: 700; }
      .seo-card-head code { padding: 2px 7px; border-radius: 5px; background: #f3eefa; color: #6f36ae; font-size: 10px; }
      .seo-card .offer-field > span { display: flex; align-items: center; justify-content: space-between; }
      .seo-card .offer-field em { font-style: normal; color: #9a94a6; font-size: 9px; }
      .seo-card .offer-field em.over { color: #c04b55; }
      .seo-preview { padding: 11px 13px; border: 1px solid #eee9f5; border-radius: 9px; background: #fbfaff; display: grid; gap: 3px; }
      .seo-preview strong { color: #1a3bb3; font-size: 14px; font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      .seo-url { color: #1f8a5f; font-size: 10px; }
      .seo-preview small { color: #5c5570; font-size: 11px; line-height: 1.5; }
      .notif-list { display: grid; gap: 8px; }
      .notif-row { display: grid; grid-template-columns: 34px minmax(0,1fr) auto auto; align-items: center; gap: 12px; padding: 12px 14px; border: 1px solid #ece7f4; border-radius: 10px; background: #fff; }
      .notif-row.unread { border-color: #e0d2f5; background: #faf7ff; }
      .notif-row.unread .notif-copy strong::after { content: ""; display: inline-block; width: 6px; height: 6px; margin-left: 7px; border-radius: 50%; background: #8540d7; vertical-align: middle; }
      .notif-icon { display: grid; width: 34px; height: 34px; place-items: center; border-radius: 9px; }
      .notif-booking { background: #f0e7ff; color: #762bce; }
      .notif-payment { background: #e7f7ef; color: #1f8a5f; }
      .notif-enquiry { background: #fff2df; color: #d78b19; }
      .notif-system { background: #eef1f6; color: #566274; }
      .notif-copy { min-width: 0; }
      .notif-copy strong { display: block; color: #39334a; font-size: 12px; }
      .notif-copy small { display: block; margin-top: 2px; overflow: hidden; color: #8d8899; font-size: 10px; text-overflow: ellipsis; white-space: nowrap; }
      .notif-row time { color: #9a94a6; font-size: 9px; white-space: nowrap; }
      .notif-actions { display: flex; align-items: center; gap: 10px; }
      @media(max-width:600px) { .notif-row { grid-template-columns: 30px minmax(0,1fr) auto; } .notif-row time { display: none; } }
      @media(max-width:480px) {
        .booking-dialog { padding: 18px 16px 18px; }
        .booking-dialog-head h2 { font-size: 22px; }
        .offers-wrap .toolbar .pricing-publish, .seo-wrap .toolbar .pricing-publish { flex: 1 1 100%; justify-content: center; }
        .pricing-bar, .pricing-actions { width: 100%; }
        .pricing-actions .ghost-button, .pricing-actions .pricing-publish { flex: 1 1 auto; justify-content: center; }
      }
      .toolbar { display: flex; flex-wrap: wrap; align-items: center; gap: 10px; margin-bottom: 14px; }
      .toolbar.end { justify-content: flex-end; }
      .search-field { display: flex; flex: 1 1 260px; min-width: 200px; height: 40px; align-items: center; gap: 8px; padding: 0 12px; border: 1px solid #e7dff3; border-radius: 9px; background: #fff; color: #8b7caa; }
      .search-field input { flex: 1; min-width: 0; border: 0; background: transparent; color: #332b45; font-size: 12px; outline: none; }
      .filter-chips { display: flex; flex-wrap: wrap; gap: 6px; }
      .filter-chips button { padding: 8px 12px; border: 1px solid #ece7f4; border-radius: 20px; background: #fff; color: #6e788a; font-size: 10px; text-transform: capitalize; }
      .filter-chips button:hover { border-color: #e0d2f5; color: #7029ce; }
      .filter-chips button.selected { border-color: transparent; background: linear-gradient(120deg,#8540d7,#6b2fc0); color: #fff; }
      .ghost-button { display: inline-flex; align-items: center; gap: 7px; padding: 9px 14px; border: 1px solid #e3d7f4; border-radius: 9px; background: #fff; color: #6f36ae; font-size: 11px; font-weight: 700; }
      .ghost-button:hover { background: #f7f2ff; }
      .ghost-button.danger { border-color: #f1d4d8; color: #c04b55; }
      .ghost-button.danger:hover { background: #fdf3f4; }
      .toolbar-stat { display: inline-flex; align-items: center; gap: 7px; margin-left: auto; color: #857f92; font-size: 10px; }
      .row-actions { display: flex; align-items: center; gap: 12px; }
      .admin-link { border: 0; background: transparent; color: #7029ce; font-size: 11px; font-weight: 700; }
      .switch { position: relative; display: inline-block; width: 38px; height: 21px; }
      .switch input { position: absolute; width: 0; height: 0; opacity: 0; }
      .switch span { position: absolute; inset: 0; border-radius: 20px; background: #d9d1e8; transition: background .2s ease; cursor: pointer; }
      .switch span::before { position: absolute; top: 2px; left: 2px; width: 17px; height: 17px; border-radius: 50%; background: #fff; box-shadow: 0 1px 3px #2a184d44; transition: transform .2s ease; content: ""; }
      .switch input:checked + span { background: linear-gradient(120deg,#8540d7,#6b2fc0); }
      .switch input:checked + span::before { transform: translateX(17px); }
      .switch input:disabled + span { opacity: .55; cursor: not-allowed; }
      .calendar-wrap { padding: 18px; border: 1px solid #ece7f4; border-radius: 12px; background: #fff; box-shadow: 0 2px 8px #39225f06; }
      .calendar-head { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 14px; }
      .calendar-nav { display: flex; align-items: center; gap: 12px; }
      .calendar-nav button { display: grid; width: 32px; height: 32px; place-items: center; border: 1px solid #ece6f5; border-radius: 8px; background: #fff; color: #73579c; }
      .calendar-nav button:hover { background: #f7f2ff; }
      .calendar-nav strong { min-width: 150px; color: #302a3c; font-size: 15px; text-align: center; }
      .calendar-legend { display: flex; flex-wrap: wrap; gap: 12px; color: #857f92; font-size: 9px; }
      .calendar-legend span { display: inline-flex; align-items: center; gap: 5px; }
      .calendar-legend i { width: 10px; height: 10px; border-radius: 3px; }
      .cal-open, .cal-cell.cal-open { background: #e7f7ef; }
      .cal-partial, .cal-cell.cal-partial { background: #fff2d9; }
      .cal-full, .cal-cell.cal-full { background: #fbe4e6; }
      .cal-past, .cal-cell.cal-past { background: #f4f2f8; }
      .calendar-grid-head { display: grid; grid-template-columns: repeat(7,1fr); gap: 6px; margin-bottom: 6px; }
      .calendar-grid-head span { color: #9a93aa; font-size: 9px; font-weight: 700; letter-spacing: .06em; text-align: center; }
      .calendar-grid { display: grid; grid-template-columns: repeat(7,1fr); gap: 6px; }
      .cal-cell { display: grid; min-height: 60px; align-content: start; gap: 2px; padding: 7px 8px; border: 1px solid #efeaf6; border-radius: 8px; text-align: left; }
      .cal-cell.cal-pad { border: 0; background: transparent; }
      .cal-cell strong { color: #302a3c; font-size: 13px; }
      .cal-cell small { color: #6b647a; font-size: 9px; }
      .cal-cell.cal-full strong, .cal-cell.cal-full small { color: #9a3b45; }
      .cal-cell.cal-open strong { color: #1f7a56; }
      button.cal-cell:hover { border-color: #c9aef0; box-shadow: 0 4px 12px #39225f14; }
      button.cal-cell.cal-past { cursor: default; }
      .calendar-note { margin: 14px 0 0; color: #948fa0; font-size: 9px; }
      .report-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 13px; margin-top: 14px; }
      .report-panel { min-width: 0; padding: 17px 19px; border: 1px solid #ece7f4; border-radius: 10px; background: #fff; box-shadow: 0 2px 8px #39225f05; }
      .report-panel .panel-heading h2 { margin-top: 4px; font-family: var(--serif); font-size: 19px; font-weight: 400; }
      .bar-rows { display: grid; gap: 11px; margin-top: 14px; }
      .bar-row { display: grid; grid-template-columns: 120px 1fr 30px; align-items: center; gap: 10px; }
      .bar-row-label { font-size: 9px; }
      .bar-row-label.plain { overflow: hidden; color: #5c5570; text-overflow: ellipsis; white-space: nowrap; text-transform: capitalize; }
      .bar-row-track { height: 8px; overflow: hidden; border-radius: 6px; background: #efeaf6; }
      .bar-row-track span { display: block; height: 100%; border-radius: inherit; background: linear-gradient(90deg,#9860dc,#6e37b8); }
      .bar-row-track span.amber { background: linear-gradient(90deg,#f1b94a,#e2922a); }
      .bar-row strong { color: #433952; font-size: 12px; text-align: right; }
      .settings-wrap { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
      .settings-card { padding: 20px 22px; border: 1px solid #ece7f4; border-radius: 12px; background: #fff; box-shadow: 0 2px 8px #39225f05; }
      .settings-card h2 { display: inline-flex; align-items: center; gap: 8px; margin: 0; color: #302a3c; font-size: 15px; }
      .settings-card > p { margin: 6px 0 16px; color: #8d8899; font-size: 10px; }
      .setting-row { display: flex; align-items: center; justify-content: space-between; gap: 14px; padding: 13px 0; border-top: 1px solid #f0ecf6; }
      .setting-row strong { display: block; color: #39334a; font-size: 12px; }
      .setting-row small { display: block; margin-top: 3px; color: #948fa0; font-size: 9px; }
      .setting-row select { padding: 8px 10px; border: 1px solid #e7dff3; border-radius: 8px; background: #fff; color: #4a4360; font-size: 11px; }
      .settings-note { display: inline-flex; align-items: center; gap: 6px; margin: 14px 0 0; color: #1f8a5f; font-size: 10px; }
      .account-row { display: flex; align-items: center; justify-content: space-between; padding: 11px 0; border-top: 1px solid #f0ecf6; }
      .account-row span { color: #8d8899; font-size: 10px; }
      .account-row strong { color: #39334a; font-size: 12px; }
      .role-cap { text-transform: capitalize; }
      .pw-reveal { display: inline-flex; align-items: center; gap: 10px; font-family: var(--mono, monospace); font-variant-numeric: tabular-nums; }
      .pw-reveal .admin-link { font-family: var(--sans); font-size: 10px; }
      .pw-note { margin: 12px 0 0; padding: 10px 12px; border-radius: 8px; background: #f6f1fc; color: #6a6479; font-size: 10px; line-height: 1.6; }
      .pw-note code { padding: 1px 5px; border-radius: 4px; background: #efe6fb; color: #6f36ae; }
      .pw-form { display: grid; gap: 8px; margin: 14px 0 4px; padding-top: 14px; border-top: 1px solid #f0ecf6; }
      .pw-form-title { color: #39334a; font-size: 12px; }
      .pw-form input { padding: 9px 11px; border: 1px solid #e3d7f4; border-radius: 8px; background: #fff; color: #39334a; font-size: 12px; }
      .pw-form .pricing-publish { justify-self: start; }
      .pw-err { color: #c0392b; font-size: 11px; }
      .pw-ok { display: inline-flex; align-items: center; gap: 5px; color: #1f8a5f; font-size: 11px; }
      .settings-card .ghost-button { margin-top: 16px; }
      .booking-modal { position: fixed; inset: 0; z-index: 80; display: grid; place-items: center; padding: 20px; background: #1b123a66; backdrop-filter: blur(3px); }
      .booking-dialog { width: min(560px, 100%); max-height: 88vh; padding: 22px 24px 24px; overflow-y: auto; border-radius: 14px; background: #fff; box-shadow: 0 24px 60px #2a184d44; }
      .booking-dialog-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; }
      .booking-dialog-head h2 { margin: 3px 0 0; color: #302a3c; font-family: var(--serif); font-size: 26px; font-weight: 400; }
      .dialog-close { display: grid; flex: 0 0 auto; width: 32px; height: 32px; place-items: center; border: 1px solid #ece6f5; border-radius: 8px; background: #fff; color: #73579c; }
      .dialog-close:hover { background: #f7f2ff; }
      .booking-dialog-status { margin: 10px 0 16px; }
      .booking-status-edit { display: grid; gap: 5px; margin: 0 0 16px; }
      .booking-status-edit span { color: #948fa0; font-size: 9px; letter-spacing: .04em; text-transform: uppercase; }
      .booking-status-edit select, .booking-status-edit input { padding: 9px 11px; border: 1px solid #e3d7f4; border-radius: 8px; background: #fff; color: #39334a; font-size: 13px; font-family: var(--sans); cursor: pointer; }
      .folio { margin: 0 0 14px; border: 1px solid #ece4f8; border-radius: 10px; padding: 11px 12px; background: #faf7ff; }
      .folio-head { display: flex; justify-content: space-between; align-items: baseline; margin: 0 0 8px; }
      .folio-head span { font-size: 11px; letter-spacing: .06em; text-transform: uppercase; color: #8a81a4; font-weight: 700; }
      .folio-head strong { font-size: 13px; color: #4a2f86; }
      .folio-list { list-style: none; margin: 0 0 9px; padding: 0; display: grid; gap: 5px; }
      .folio-list li { display: flex; align-items: center; gap: 8px; font-size: 13px; color: #39334a; }
      .folio-list li span { flex: 1; display: flex; flex-direction: column; }
      .folio-list li span small { color: #948aac; font-size: 11px; }
      .folio-list li em { font-style: normal; font-weight: 600; }
      .folio-empty { color: #948aac; font-size: 12px; }
      .folio-remove { display: grid; place-items: center; width: 20px; height: 20px; border: none; border-radius: 6px; background: #f0e8fb; color: #7a4fc0; cursor: pointer; }
      .folio-remove:hover { background: #e4d6f7; }
      .folio-add { display: grid; grid-template-columns: 1fr 100px auto; gap: 6px; }
      .folio-add input { padding: 8px 10px; border: 1px solid #e3d7f4; border-radius: 8px; background: #fff; color: #39334a; font-size: 13px; font-family: var(--sans); }
      .folio-btn { padding: 8px 14px; border: none; border-radius: 8px; background: #7a4fc0; color: #fff; font-size: 13px; font-weight: 600; cursor: pointer; }
      .folio-btn:hover { background: #683fad; }
      .folio-attach { display: flex; align-items: center; gap: 8px; margin-top: 8px; }
      .folio-attach-btn { display: inline-flex; align-items: center; gap: 5px; padding: 6px 10px; border: 1px dashed #c9b8ea; border-radius: 8px; background: #fff; color: #7a4fc0; font-size: 12px; font-weight: 600; cursor: pointer; }
      .folio-attach-btn:hover { background: #f4eefc; }
      .folio-link-remove { border: none; background: none; color: #b64a4a; font-size: 12px; cursor: pointer; padding: 0; }
      .folio-thumb { display: inline-flex; width: 28px; height: 28px; border-radius: 6px; overflow: hidden; border: 1px solid #e3d7f4; flex: none; }
      .folio-thumb img { width: 100%; height: 100%; object-fit: cover; }
      .folio-balance { display: flex; justify-content: space-between; align-items: center; margin: 0 0 16px; padding: 11px 14px; border-radius: 10px; }
      .folio-balance span { font-size: 12px; letter-spacing: .05em; text-transform: uppercase; font-weight: 700; }
      .folio-balance strong { font-size: 18px; }
      .folio-balance.is-due { background: #fdecec; color: #c0392b; }
      .folio-balance.is-clear { background: #e7f7ef; color: #13a775; }
      .hc-toast { position: fixed; top: 18px; right: 18px; z-index: 4000; display: flex; align-items: center; gap: 10px; max-width: 380px; padding: 13px 14px; border-radius: 12px; background: #fff; box-shadow: 0 14px 40px rgba(40, 20, 70, .22); border: 1px solid #efe7fb; animation: hc-toast-in .22s ease; }
      .hc-toast-error { border-left: 4px solid #e1483a; }
      .hc-toast-ok { border-left: 4px solid #13a775; }
      .hc-toast-icon { display: grid; place-items: center; color: #e1483a; flex: none; }
      .hc-toast-ok .hc-toast-icon { color: #13a775; }
      .hc-toast-text { font-size: 13px; line-height: 1.5; color: #39334a; }
      .hc-toast-close { margin-left: auto; border: none; background: none; color: #948aac; cursor: pointer; padding: 2px; flex: none; }
      @keyframes hc-toast-in { from { opacity: 0; transform: translateY(-8px); } to { opacity: 1; transform: translateY(0); } }
      .pricing-publish:disabled, .admin-action:disabled, .admin-link:disabled, .po-manage:disabled, .folio-btn:disabled, .folio-remove:disabled { opacity: .4; cursor: not-allowed; pointer-events: none; }
      .admin-number:disabled, .folio-add input:disabled, .booking-status-edit select:disabled, .row-actions select:disabled, .switch input:disabled + span { opacity: .5; cursor: not-allowed; }
      .locked-btn { opacity: .45; cursor: not-allowed; }
      .avail-badge { display: inline-grid; place-items: center; min-width: 30px; padding: 3px 9px; border-radius: 999px; font-size: 12px; font-weight: 700; }
      .avail-booked { background: #efe9fb; color: #6f36ae; }
      .avail-open { background: #e7f7ef; color: #13a775; }
      .avail-none { background: #fdecec; color: #c0392b; }
      .booking-dialog-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 13px 16px; }
      .booking-dialog-grid span { display: block; color: #948fa0; font-size: 9px; letter-spacing: .04em; text-transform: uppercase; }
      .booking-dialog-grid strong { display: block; margin-top: 3px; color: #39334a; font-size: 13px; font-weight: 600; word-break: break-word; }
      .booking-dialog-requests { margin-top: 16px; padding: 12px 14px; border-radius: 9px; background: #f7f4fc; }
      .booking-dialog-requests span { color: #8b6ab6; font-size: 9px; letter-spacing: .06em; text-transform: uppercase; }
      .booking-dialog-requests p { margin: 5px 0 0; color: #4a4360; font-size: 11px; line-height: 1.6; }
      .booking-dialog-actions { display: flex; align-items: center; gap: 12px; margin-top: 20px; }
      .booking-dialog-actions .po-manage { min-height: 40px; padding: 0 20px; }
      .booking-dialog-actions small { color: #948fa0; font-size: 9px; }
      .admin-app.is-compact .admin-content { padding-top: 16px; padding-bottom: 20px; }
      .admin-app.is-compact .summary-card { min-height: 60px; }
      .admin-app.is-compact .kpi-overview, .admin-app.is-compact .report-grid, .admin-app.is-compact .settings-wrap { gap: 8px; }
      .admin-app.is-compact td { padding-top: 9px; padding-bottom: 9px; }
      @media(min-width:761px) and (max-width:1100px) { .report-grid { grid-template-columns: 1fr 1fr; } }
      @media(max-width:760px) {
        .report-grid, .settings-wrap { grid-template-columns: 1fr; }
        .booking-dialog-grid { grid-template-columns: 1fr; }
        .toolbar-stat { width: 100%; margin-left: 0; }
        .bar-row { grid-template-columns: 90px 1fr 26px; }
        .calendar-nav strong { min-width: 110px; font-size: 13px; }
        .cal-cell { min-height: 48px; padding: 5px; }
        .cal-cell small { font-size: 8px; }
        .calendar-legend { font-size: 8px; }
      }
      .table-heading { border-color: #f0ecf6; }
      .property-pulse { display: grid; grid-template-columns: minmax(0,1.1fr) minmax(300px,.9fr); overflow: hidden; margin: 5px 0 14px; border-radius: 12px; background: #30214f; color: #fff; box-shadow: 0 12px 26px #4b2d7722; }
      .pulse-main { display: flex; min-height: 210px; align-items: center; justify-content: space-between; gap: 20px; padding: 25px 30px; background: radial-gradient(ellipse at 85% 20%, #7349a955, transparent 48%), linear-gradient(120deg,#30214f,#49306c); }
      .pulse-copy { max-width: 340px; }
      .pulse-eyebrow { display: inline-flex; align-items: center; gap: 6px; color: #cdb8f2; font-size: 8px; font-weight: 700; letter-spacing: .13em; }
      .pulse-copy h2 { margin: 15px 0 8px; font-family: var(--serif); font-size: 37px; font-weight: 400; line-height: .92; }
      .pulse-copy p { max-width: 260px; margin: 0; color: #d8cfe6; font-size: 10px; line-height: 1.7; }
      .pulse-link { display: inline-flex; align-items: center; gap: 7px; margin-top: 16px; padding: 0 0 5px; border: 0; border-bottom: 1px solid #bda0e9; background: transparent; color: #e7dafa; font-size: 9px; }
      .pulse-gauge { display: grid; flex: 0 0 126px; width: 126px; height: 126px; place-items: center; border-radius: 50%; }
      .pulse-gauge > div { display: grid; width: 102px; height: 102px; align-content: center; justify-items: center; border: 1px solid #ffffff22; border-radius: 50%; background: #342250; }
      .pulse-gauge strong { font-size: 30px; font-weight: 600; line-height: 1; }
      .pulse-gauge strong small { margin-left: 1px; font-size: 13px; }
      .pulse-gauge span { margin-top: 6px; color: #d6cbe6; font-size: 8px; text-transform: uppercase; letter-spacing: .08em; }
      .pulse-stats { display: grid; grid-template-columns: 1fr 1fr; align-content: center; gap: 0; padding: 12px 21px; background: #fff; color: #29253a; }
      .pulse-stats > div { display: grid; gap: 6px; min-height: 74px; align-content: center; padding: 10px 13px; border-bottom: 1px solid #eee9f5; }
      .pulse-stats > div:nth-child(odd) { border-right: 1px solid #eee9f5; }
      .pulse-stats > div:nth-last-child(-n+2) { border-bottom: 0; }
      .pulse-stats span { color: #858092; font-size: 8px; }
      .pulse-stats strong { color: #382b50; font-size: 21px; font-weight: 600; }
      .pulse-stats strong small { color: #8e899b; font-size: 8px; font-weight: 400; }
      .locations-overview { margin: 18px 0; }
      .locations-heading { display: flex; align-items: end; justify-content: space-between; gap: 12px; margin-bottom: 10px; }
      .locations-heading > div > span { color: #8b6ab6; font-size: 8px; font-weight: 700; letter-spacing: .14em; }
      .locations-heading h2 { margin: 4px 0 0; color: #302a3c; font-family: var(--serif); font-size: 25px; font-weight: 400; }
      .locations-heading > small { color: #9691a0; font-size: 8px; }
      .location-cards { display: grid; grid-template-columns: repeat(2,minmax(0,1fr)); gap: 13px; }
      .location-card { min-width: 0; padding: 16px 17px 0; border: 1px solid #e9e1f2; border-radius: 9px; background: #fff; box-shadow: 0 3px 10px #39225f08; }
      .location-card-head { display: flex; align-items: center; gap: 10px; padding-bottom: 13px; border-bottom: 1px solid #f0ecf5; }
      .location-marker { display: grid; flex: 0 0 35px; width: 35px; height: 35px; place-items: center; border-radius: 9px; background: #f1eaff; color: #762bce; }
      .location-card-head > div { min-width: 0; }
      .location-card-head small { color: #8b6ab6; font-size: 8px; }
      .location-card-head h3 { margin: 3px 0 0; overflow: hidden; color: #302a3c; font-size: 12px; font-weight: 700; text-overflow: ellipsis; white-space: nowrap; }
      .location-action { display: grid; flex: 0 0 28px; width: 28px; height: 28px; place-items: center; margin-left: auto; border: 1px solid #eee8f6; border-radius: 6px; background: #fff; color: #76569e; }
      .location-action:hover { border-color: #dfcff3; background: #f7f2ff; }
      .location-occupancy { padding: 13px 0 12px; }
      .location-progress-label, .location-room-counts { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
      .location-progress-label { color: #858092; font-size: 8px; }
      .location-progress-label strong { color: #6f36ae; font-size: 10px; }
      .location-progress { height: 5px; margin: 7px 0 9px; overflow: hidden; border-radius: 5px; background: #eee9f5; }
      .location-progress span { display: block; height: 100%; border-radius: inherit; background: linear-gradient(90deg,#9860dc,#6e37b8); }
      .location-room-counts { color: #8d8997; font-size: 7px; }
      .location-room-counts strong { color: #433952; font-size: 9px; }
      .location-movements { display: grid; grid-template-columns: 1fr 1fr; border-top: 1px solid #f0ecf5; }
      .location-movements > div { display: grid; grid-template-columns: 18px 1fr auto; align-items: center; gap: 5px; min-height: 39px; color: #7e788b; font-size: 8px; }
      .location-movements > div:first-child { padding-right: 10px; border-right: 1px solid #f0ecf5; color: #762bce; }
      .location-movements > div:last-child { padding-left: 12px; color: #159c70; }
      .location-movements strong { color: #3d374a; font-size: 11px; }
      .location-period-stats { display: grid; grid-template-columns: 1fr 1fr; margin: 0 -17px; padding: 10px 17px; border-top: 1px solid #f0ecf5; background: #fcfbfe; }
      .location-period-stats > div { display: grid; gap: 4px; }
      .location-period-stats > div + div { padding-left: 12px; border-left: 1px solid #eee8f5; }
      .location-period-stats span { color: #908b9b; font-size: 7px; }
      .location-period-stats strong { color: #382b50; font-size: 12px; }
      .front-desk { margin: 14px 0; padding: 18px 20px 12px; border: 1px solid #ebe5f4; border-radius: 10px; background: #fff; }
      .desk-heading { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-bottom: 10px; }
      .desk-eyebrow, .ribbon-title > span, .panel-overline { color: #8b6ab6; font-size: 8px; font-weight: 700; letter-spacing: .14em; }
      .desk-heading h2 { margin: 4px 0 3px; color: #302a3c; font-family: var(--serif); font-size: 25px; font-weight: 400; }
      .desk-heading p { margin: 0; color: #92909c; font-size: 9px; }
      .desk-date { display: inline-flex; align-items: center; gap: 6px; padding: 7px 9px; border-radius: 5px; background: #f6f1fc; color: #74569a; font-size: 8px; }
      .desk-flow { display: grid; width: 100%; grid-template-columns: repeat(3,minmax(0,1fr)); align-items: stretch; gap: 12px; }
      .desk-movement { display: grid; min-width: 0; min-height: 82px; grid-template-columns: 34px minmax(0,1fr) auto 16px; align-items: center; gap: 10px; padding: 13px 14px; border: 1px solid #eee8f5; border-radius: 8px; background: #fcfbfe; text-align: left; }
      .desk-movement:hover { border-color: #dfcff3; background: #f8f4ff; }
      .movement-icon { display: grid; flex: 0 0 34px; width: 34px; height: 34px; place-items: center; border-radius: 9px; }
      .arrival-icon { background: #f0e7ff; color: #762bce; }
      .departure-icon { background: #e8f7f1; color: #159c70; }
      .pending-icon { background: #fff2df; color: #d78b19; }
      .desk-movement > span:nth-child(2) { display: grid; grid-template-columns: minmax(0,1fr) auto; gap: 3px 10px; min-width: 0; }
      .desk-movement small, .desk-movement em { grid-column: 1; }
      .desk-movement strong { grid-column: 2; grid-row: 1 / span 2; align-self: center; }
      .desk-movement small { color: #918b9f; font-size: 7px; font-weight: 700; letter-spacing: .08em; }
      .desk-movement strong { color: #2e2938; font-size: 20px; line-height: 1; }
      .desk-movement em { color: #8f8a99; font-size: 8px; font-style: normal; }
      .movement-arrow { color: #b6aec2; }
      .desk-divider { display: none; }
      .kpi-ribbon { display: grid; grid-template-columns: 110px repeat(4,minmax(0,1fr)); align-items: stretch; gap: 0; margin: 15px 0; padding: 5px 0; border-top: 1px solid #e8e0f1; border-bottom: 1px solid #e8e0f1; }
      .ribbon-title { display: grid; align-content: center; gap: 5px; padding: 8px 12px 8px 3px; }
      .ribbon-title small { color: #9791a2; font-size: 8px; }
      .kpi-ribbon .summary-card { min-height: 60px; padding: 9px 12px; border: 0; border-left: 1px solid #ece7f4; border-radius: 0; box-shadow: none; }
      .kpi-ribbon .summary-card::before { display: none; }
      .kpi-ribbon .summary-icon { flex-basis: 29px; width: 29px; height: 29px; }
      .kpi-ribbon .summary-value { font-size: 16px; }
      .kpi-ribbon .summary-label { font-size: 8px; }
      .redesign-analytics { grid-template-columns: minmax(0,1.2fr) minmax(300px,.8fr); gap: 14px; }
      .redesign-analytics .analytics-panel { min-height: 190px; padding: 17px 19px; }
      .redesign-analytics .panel-heading { min-height: 45px; align-items: center; }
      .redesign-analytics .panel-heading h2 { margin-top: 4px; font-family: var(--serif); font-size: 20px; font-weight: 400; }
      .redesign-analytics .panel-heading p { font-size: 8px; }
      .redesign-analytics .bar-chart { height: 120px; }
      @media(max-width:1100px) { .property-pulse { grid-template-columns: 1fr; } .pulse-main { min-height: 175px; } .pulse-stats { grid-template-columns: repeat(4,1fr); } .pulse-stats > div { border-right: 1px solid #eee9f5; border-bottom: 0; } .pulse-stats > div:last-child { border-right: 0; } .kpi-ribbon { grid-template-columns: repeat(4,minmax(0,1fr)); } .ribbon-title { grid-column: 1 / -1; } .kpi-ribbon .summary-card:first-of-type { border-left: 0; } .redesign-analytics { grid-template-columns: 1fr; } .redesign-analytics .activity-panel { grid-column: auto; } }
      @media(max-width:760px) { .pulse-main { padding: 22px; } .pulse-copy h2 { font-size: 32px; } .pulse-gauge { flex-basis: 105px; width: 105px; height: 105px; } .pulse-gauge > div { width: 85px; height: 85px; } .pulse-gauge strong { font-size: 25px; } .pulse-stats { grid-template-columns: 1fr 1fr; padding: 8px; } .pulse-stats > div { border-bottom: 1px solid #eee9f5; } .pulse-stats > div:nth-child(2) { border-right: 0; } .pulse-stats > div:nth-last-child(-n+2) { border-bottom: 0; } .location-cards { grid-template-columns: 1fr; } .locations-heading { align-items: flex-start; flex-direction: column; } .desk-flow { grid-template-columns: 1fr; } .desk-divider { width: 100%; height: 1px; } .desk-movement { padding: 10px 4px; } .kpi-ribbon { grid-template-columns: 1fr 1fr; } .ribbon-title { grid-column: 1 / -1; } .kpi-ribbon .summary-card:nth-of-type(odd) { border-left: 0; } .redesign-analytics { grid-template-columns: 1fr; } }
      @media(min-width:761px) {
        .admin-content { padding: 28px 24px 38px; }
        .admin-title-row h1 { font-size: 29px; }
        .admin-title-row p { font-size: 13px; }
        .admin-kicker, .admin-clock span, .admin-nav > p { font-size: 10px; }
        .admin-nav-item { min-height: 39px; font-size: 13px; }
        .topbar-label, .topbar-date { font-size: 11px; }
        .admin-profile strong { font-size: 12px; }
        .admin-profile small { font-size: 10px; }
        .preview-banner { font-size: 12px; }
        .period-bar > label > span:first-of-type, .range-separator { font-size: 11px; }
        .period-bar input { height: 35px; font-size: 11px; }
        .period-presets button { font-size: 11px; }
        .pulse-eyebrow, .locations-heading > div > span, .desk-eyebrow, .ribbon-title > span, .panel-overline { font-size: 10px; }
        .pulse-copy h2 { font-size: 44px; }
        .pulse-copy p { font-size: 13px; }
        .pulse-link { font-size: 11px; }
        .pulse-gauge strong { font-size: 34px; }
        .pulse-gauge span, .pulse-stats span { font-size: 10px; }
        .pulse-stats strong { font-size: 24px; }
        .pulse-stats strong small { font-size: 10px; }
        .locations-heading h2, .desk-heading h2 { font-size: 29px; }
        .locations-heading > small, .desk-heading p { font-size: 11px; }
        .location-card-head small { font-size: 10px; }
        .location-card-head h3 { font-size: 15px; }
        .location-progress-label { font-size: 12px; }
        .location-progress-label strong { font-size: 14px; }
        .location-room-counts { font-size: 10px; }
        .location-room-counts strong { font-size: 12px; }
        .location-movements > div { font-size: 11px; }
        .location-movements strong { font-size: 15px; }
        .location-period-stats span { font-size: 10px; }
        .location-period-stats strong { font-size: 17px; }
        .desk-date { font-size: 10px; }
        .desk-movement small { font-size: 10px; }
        .desk-movement strong { font-size: 25px; }
        .desk-movement em { font-size: 11px; }
        .ribbon-title small { font-size: 10px; }
        .kpi-ribbon .summary-value { font-size: 23px; }
        .kpi-ribbon .summary-label { font-size: 11px; }
        .redesign-analytics .panel-heading h2 { font-size: 23px; }
        .redesign-analytics .panel-heading p { font-size: 10px; }
        .chart-key, .chart-column { font-size: 10px; }
        .activity-row { min-height: 41px; }
        .activity-copy strong { font-size: 10px; }
        .activity-copy small, .activity-row time { font-size: 9px; }
        .text-action { font-size: 10px; }
        table { font-size: 12px; }
        th { font-size: 10px; }
        td span { font-size: 10px; }
        .status { font-size: 10px; }
      }
      @media(min-width:1101px) {
        .admin-brand { font-size: 14px; }
        .admin-brand small { font-size: 9px; }
        .admin-clock span, .admin-nav > p, .admin-kicker { font-size: 10px; }
        .admin-clock strong { font-size: 19px; }
        .admin-clock small { font-size: 11px; }
        .admin-nav-item { min-height: 40px; font-size: 13px; }
        .admin-topbar { min-height: 68px; }
        .topbar-label { font-size: 12px; }
        .topbar-date { font-size: 12px; }
        .admin-profile strong { font-size: 12px; }
        .admin-profile small { font-size: 10px; }
        .admin-content { padding: 30px 24px 40px; }
        .admin-title-row h1 { font-size: 30px; }
        .admin-title-row p { font-size: 13px; }
        .preview-banner { font-size: 12px; padding: 11px 14px; }
        .period-bar { min-height: 60px; }
        .period-bar > label > span:first-of-type, .range-separator { font-size: 11px; }
        .period-bar input { width: 138px; height: 36px; font-size: 11px; }
        .period-presets button { padding: 9px 12px; font-size: 11px; }
        .pulse-main { min-height: 245px; padding: 30px 36px; }
        .pulse-eyebrow { font-size: 10px; }
        .pulse-copy h2 { font-size: 46px; }
        .pulse-copy p { max-width: 330px; font-size: 13px; }
        .pulse-link { font-size: 11px; }
        .pulse-gauge { flex-basis: 150px; width: 150px; height: 150px; }
        .pulse-gauge > div { width: 122px; height: 122px; }
        .pulse-gauge strong { font-size: 36px; }
        .pulse-gauge strong small { font-size: 16px; }
        .pulse-gauge span { font-size: 10px; }
        .pulse-stats span { font-size: 10px; }
        .pulse-stats strong { font-size: 25px; }
        .pulse-stats strong small { font-size: 10px; }
        .locations-heading > div > span, .desk-eyebrow, .ribbon-title > span, .panel-overline { font-size: 10px; }
        .locations-heading h2 { font-size: 30px; }
        .locations-heading > small { font-size: 10px; }
        .location-card { padding: 20px 21px 0; }
        .location-card-head small { font-size: 10px; }
        .location-card-head h3 { font-size: 15px; }
        .location-marker { flex-basis: 40px; width: 40px; height: 40px; }
        .location-progress-label { font-size: 13px; }
        .location-progress-label strong { font-size: 15px; }
        .location-room-counts { font-size: 11px; }
        .location-room-counts strong { font-size: 13px; }
        .location-movements > div { font-size: 12px; }
        .location-movements strong { font-size: 16px; }
        .location-period-stats { margin-right: -21px; margin-left: -21px; padding-right: 21px; padding-left: 21px; }
        .location-period-stats span { font-size: 11px; }
        .location-period-stats strong { font-size: 18px; }
        .front-desk { padding: 22px 25px 16px; }
        .desk-heading h2 { font-size: 30px; }
        .desk-heading p { font-size: 11px; }
        .desk-date { font-size: 10px; }
        .desk-movement small { font-size: 11px; }
        .desk-movement strong { font-size: 27px; }
        .desk-movement em { font-size: 12px; }
        .ribbon-title small { font-size: 10px; }
        .kpi-ribbon .summary-card { min-height: 70px; }
        .kpi-ribbon .summary-value { font-size: 23px; }
        .kpi-ribbon .summary-label { font-size: 12px; }
        .redesign-analytics .panel-heading h2 { font-size: 24px; }
        .redesign-analytics .panel-heading p { font-size: 10px; }
        .chart-key { font-size: 12px; }
        .chart-column { font-size: 12px; }
        .activity-row { min-height: 46px; }
        .activity-icon { width: 30px; height: 30px; }
        .activity-copy strong { font-size: 12px; }
        .activity-copy small, .activity-row time { font-size: 11px; }
        .text-action { font-size: 12px; }
        table { font-size: 14px; }
        th { font-size: 11px; padding: 16px 18px; }
        td { padding: 16px 17px; }
        td span { font-size: 12px; }
        .status { font-size: 11px; }
      }
      @media(max-width:900px) {
        .desk-flow { grid-template-columns: 1fr; gap: 0; }
        .desk-flow { gap: 8px; }
        .desk-movement { min-height: 68px; gap: 14px; padding: 10px 12px; }
        .desk-movement > span:nth-child(2) { grid-template-columns: minmax(150px,1fr) auto; align-items: center; column-gap: 14px; width: 100%; }
        .desk-movement small { grid-column: 1; font-size: 10px; }
        .desk-movement em { grid-column: 1; grid-row: 2; font-size: 10px; }
        .desk-movement strong { grid-column: 2; grid-row: 1 / span 2; font-size: 23px; }
        .movement-arrow { margin-left: 0; }
      }
      @media(min-width:761px) and (max-width:900px) {
        .kpi-ribbon { grid-template-columns: repeat(2,minmax(0,1fr)); }
      }
      .performance-section { margin: 17px 0 18px; }
      .performance-heading { display: flex; align-items: end; justify-content: space-between; gap: 16px; margin-bottom: 10px; }
      .performance-heading > div > span { color: #8b6ab6; font-size: 9px; font-weight: 700; letter-spacing: .14em; }
      .performance-heading h2 { margin: 4px 0 0; color: #302a3c; font-family: var(--serif); font-size: 25px; font-weight: 400; }
      .performance-heading > small { color: #858092; font-size: 10px; }
      .kpi-ribbon { grid-template-columns: repeat(4,minmax(0,1fr)); gap: 12px; margin: 0; padding: 0; border: 0; }
      .kpi-ribbon .summary-card { min-height: 76px; padding: 12px 14px; border: 1px solid #ece7f4; border-radius: 8px; box-shadow: 0 2px 7px #39225f07; }
      .kpi-ribbon .summary-card:first-of-type { border-left: 1px solid #ece7f4; }
      @media(min-width:761px) and (max-width:900px) { .kpi-ribbon { grid-template-columns: repeat(2,minmax(0,1fr)); } }
      @media(max-width:760px) {
        .performance-heading { align-items: flex-start; flex-direction: column; gap: 5px; }
        .performance-heading h2 { font-size: 22px; }
        .kpi-ribbon { grid-template-columns: repeat(2,minmax(0,1fr)); gap: 8px; }
        .kpi-ribbon .summary-card { padding: 10px; }
      }
      @media(min-width:761px) {
        .admin-title-row h1 { font-size: clamp(29px, calc(20px + 1vw), 44px); }
        .admin-title-row p { font-size: clamp(13px, calc(8px + .42vw), 18px); }
        .admin-kicker, .admin-clock span, .admin-nav > p { font-size: clamp(10px, calc(6px + .42vw), 15px); }
        .admin-nav-item { font-size: clamp(13px, calc(6px + .5vw), 18px); }
        .admin-clock strong { font-size: clamp(19px, calc(10px + .65vw), 29px); }
        .admin-clock small, .topbar-label, .topbar-date { font-size: clamp(10px, calc(6px + .42vw), 16px); }
        .admin-profile strong { font-size: clamp(12px, calc(7px + .38vw), 17px); }
        .admin-profile small { font-size: clamp(10px, calc(6px + .32vw), 14px); }
        .preview-banner { font-size: clamp(12px, calc(7px + .4vw), 17px); }
        .period-bar > label > span:first-of-type, .range-separator { font-size: clamp(11px, calc(7px + .35vw), 15px); }
        .period-bar input { font-size: clamp(11px, calc(7px + .35vw), 15px); }
        .period-presets button { font-size: clamp(11px, calc(7px + .35vw), 15px); }
        .pulse-eyebrow, .locations-heading > div > span, .desk-eyebrow, .performance-heading > div > span, .panel-overline { font-size: clamp(10px, calc(6px + .35vw), 14px); }
        .pulse-copy h2 { font-size: clamp(44px, calc(24px + 1.25vw), 64px); }
        .pulse-copy p, .location-progress-label { font-size: clamp(13px, calc(7px + .4vw), 18px); }
        .pulse-link { font-size: clamp(11px, calc(6px + .35vw), 16px); }
        .pulse-gauge strong { font-size: clamp(34px, calc(18px + 1vw), 50px); }
        .pulse-gauge span, .pulse-stats span, .location-room-counts, .location-movements > div, .location-period-stats span, .desk-date, .ribbon-title small { font-size: clamp(10px, calc(6px + .38vw), 16px); }
        .pulse-stats strong, .location-period-stats strong, .location-progress-label strong { font-size: clamp(15px, calc(8px + .65vw), 26px); }
        .locations-heading h2, .desk-heading h2, .performance-heading h2 { font-size: clamp(29px, calc(18px + .9vw), 44px); }
        .locations-heading > small, .desk-heading p { font-size: clamp(11px, calc(6px + .4vw), 16px); }
        .location-card-head small { font-size: clamp(10px, calc(6px + .35vw), 15px); }
        .location-card-head h3 { font-size: clamp(15px, calc(8px + .55vw), 24px); }
        .location-room-counts strong, .location-movements strong { font-size: clamp(13px, calc(7px + .55vw), 22px); }
        .desk-movement small { font-size: clamp(10px, calc(6px + .42vw), 17px); }
        .desk-movement strong { font-size: clamp(25px, calc(14px + .9vw), 42px); }
        .desk-movement em { font-size: clamp(11px, calc(6px + .42vw), 17px); }
        .kpi-ribbon .summary-value { font-size: clamp(23px, calc(12px + 1vw), 38px); }
        .kpi-ribbon .summary-label { font-size: clamp(11px, calc(6px + .45vw), 18px); }
        .redesign-analytics .panel-heading h2 { font-size: clamp(23px, calc(14px + .8vw), 38px); }
        .redesign-analytics .panel-heading p, .chart-key, .chart-column { font-size: clamp(10px, calc(6px + .42vw), 17px); }
        .activity-copy strong { font-size: clamp(10px, calc(6px + .42vw), 17px); }
        .activity-copy small, .activity-row time { font-size: clamp(9px, calc(5px + .38vw), 15px); }
        .text-action { font-size: clamp(10px, calc(6px + .4vw), 16px); }
      }
      @media(max-width:760px) {
        .admin-title-row h1 { font-size: 26px; }
        .admin-title-row p { font-size: 12px; }
        .admin-nav-item { font-size: 12px; }
        .admin-kicker, .desk-eyebrow, .locations-heading > div > span, .performance-heading > div > span, .panel-overline { font-size: 10px; }
        .location-card-head small { font-size: 10px; }
        .location-card-head h3 { font-size: 15px; }
        .location-progress-label { font-size: 12px; }
        .location-progress-label strong { font-size: 13px; }
        .location-room-counts { font-size: 9px; }
        .location-room-counts strong { font-size: 11px; }
        .location-movements > div { font-size: 10px; }
        .location-movements strong, .location-period-stats strong { font-size: 14px; }
        .location-period-stats span { font-size: 10px; }
        .desk-heading h2, .locations-heading h2, .performance-heading h2 { font-size: 24px; }
        .desk-heading p, .locations-heading > small, .performance-heading > small { font-size: 11px; }
        .desk-movement small { font-size: 11px; }
        .desk-movement strong { font-size: 24px; }
        .desk-movement em { font-size: 11px; }
        .kpi-ribbon .summary-value { font-size: 20px; }
        .kpi-ribbon .summary-label { font-size: 11px; }
        .redesign-analytics .panel-heading h2 { font-size: 22px; }
        .redesign-analytics .panel-heading p, .chart-key, .chart-column { font-size: 10px; }
        .activity-copy strong { font-size: 10px; }
        .activity-copy small, .activity-row time { font-size: 9px; }
      }
      @media(max-width:420px) {
        .location-room-counts { font-size: 8px; }
        .location-room-counts strong { font-size: 10px; }
        .kpi-ribbon { grid-template-columns: repeat(2,minmax(0,1fr)); gap: 7px; }
        .kpi-ribbon .summary-card { gap: 7px; padding: 8px; }
        .kpi-ribbon .summary-icon { flex-basis: 26px; width: 26px; height: 26px; }
        .kpi-ribbon .summary-value { font-size: 18px; }
        .kpi-ribbon .summary-label { font-size: 10px; }
      }
      @media(max-width:760px) {
        .nav-hamburger { display: grid; }
        .nav-close { display: grid; }
        .nav-collapse-toggle { display: none; }
        .admin-app.nav-collapsed { grid-template-columns: none; }
        .admin-sidebar { position: fixed; top: 0; left: 0; z-index: 60; width: 272px; max-width: 82vw; height: 100vh; padding: 16px 15px; border-right: 1px solid #ebe5f6; border-bottom: 0; background: #fff; transform: translateX(-100%); transition: transform .26s ease; overflow-y: auto; }
        .admin-sidebar.is-open { transform: translateX(0); box-shadow: 0 10px 40px #2a184d33; }
        .admin-sidebar .admin-clock, .admin-sidebar .admin-connection { display: grid; }
        .admin-sidebar .admin-nav { display: grid; gap: 3px; margin-top: 12px; overflow: visible; }
        .admin-sidebar .admin-nav > p { display: block; }
        .admin-sidebar .admin-nav-item { flex: none; width: 100%; min-height: 42px; padding: 0 11px; font-size: 13px; }
        .nav-overlay { display: block; position: fixed; inset: 0; z-index: 55; background: #1b123a66; opacity: 0; pointer-events: none; transition: opacity .25s ease; }
        .nav-overlay.is-visible { opacity: 1; pointer-events: auto; }
      }
    `}</style>
  </main>;
}


function SummaryCard({ icon, value, label, tone }: { icon: React.ReactNode; value: string; label: string; tone: string }) {
  return <article className={`summary-card tone-${tone}`}><span className="summary-icon">{icon}</span><div><div className="summary-value">{value}</div><div className="summary-label">{label}</div></div></article>;
}

function Status({ value }: { value: string }) {
  return <span className={`status status-${value}`}>{value.replaceAll("_", " ")}</span>;
}

function DataTable({ title, empty, children }: { title: string; empty: string; children: React.ReactNode }) {
  const table = children as React.ReactElement<{ children?: React.ReactNode }>;
  const sections = Array.isArray(table.props.children) ? table.props.children : [table.props.children];
  const body = sections[1] as React.ReactElement<{ children?: React.ReactNode }> | undefined;
  const rows = body?.props.children;
  const hasRows = Array.isArray(rows) ? rows.length > 0 : Boolean(rows);
  return <section className="admin-table-wrap"><div className="table-heading"><h2>{title}</h2><span className="small-select">Current period <CalendarDays size={12} /></span></div>{children}{!hasRows && <p className="admin-empty">{empty}</p>}</section>;
}