"use client";

import { useMemo, useState } from "react";
import { History, Search } from "lucide-react";
import { TESTING_LOGIN_HISTORY } from "@/lib/testing/dummy-data";

function formatAt(iso: string) {
  return new Date(iso).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", hour12: true });
}

export default function LoginHistory() {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<"all" | "success" | "failed">("all");

  const visible = useMemo(() => {
    const query = search.trim().toLowerCase();
    return TESTING_LOGIN_HISTORY.filter(event => {
      if (status !== "all" && event.status !== status) return false;
      if (!query) return true;
      return `${event.user} ${event.email} ${event.ip} ${event.location}`.toLowerCase().includes(query);
    });
  }, [search, status]);

  return (
    <section className="offers-wrap">
      <div className="toolbar">
        <div className="search-field"><Search size={15} /><input type="search" value={search} onChange={event => setSearch(event.target.value)} placeholder="Search user, email, IP or location" aria-label="Search login history" /></div>
        <div className="filter-chips" role="group" aria-label="Filter by result">
          {(["all", "success", "failed"] as const).map(value => <button key={value} className={status === value ? "selected" : ""} onClick={() => setStatus(value)}>{value}</button>)}
        </div>
      </div>

      {visible.length === 0 ? (
        <div className="admin-empty-state"><History size={28} /><strong>No sign-in records match</strong><span>Try a different search or filter.</span></div>
      ) : (
        <div className="admin-table-wrap">
          <table>
            <thead><tr><th>When</th><th>User</th><th>IP address</th><th>Device</th><th>Location</th><th>Result</th></tr></thead>
            <tbody>
              {visible.map(event => (
                <tr key={event.id}>
                  <td>{formatAt(event.at)}</td>
                  <td><strong>{event.user}</strong><span>{event.email}</span></td>
                  <td>{event.ip}</td>
                  <td>{event.device}</td>
                  <td>{event.location}</td>
                  <td><span className={`status status-${event.status === "success" ? "confirmed" : "failed"}`}>{event.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <p className="pricing-hint">Sign-in records are read-only. Live capture begins once authentication is connected.</p>
    </section>
  );
}
