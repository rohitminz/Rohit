"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { ArrowRight, BedDouble, CalendarDays, ChevronRight, Clock, MapPin, Maximize, Users } from "lucide-react";
import { formatStayDate, inr, stayNights, TAX_RATE } from "@/lib/room-details";
import { todayInIndia } from "@/lib/booking-dates";
import GuestsPicker, { RoomParty, totalAdultsOf, totalChildrenOf } from "@/components/GuestsPicker";

type ContentRoom = {
  id: string;
  name: string;
  description: string;
  guests: number;
  bed: string;
  sqft: number;
  amenities: string[];
  images: string[];
  rate: number;
  priceStatus: string;
};
type ContentProperty = {
  slug: string;
  backendKey: string;
  name: string;
  area: string;
  city: string;
  location: string;
  contactAddress: string;
  cardImage: string;
  rooms: ContentRoom[];
};

export default function SearchResults() {
  const params = useSearchParams();
  // The `property` query parameter is the property SLUG (stable identifier), or "all".
  const propertySlug = params.get("property") ?? "all";
  const checkIn = params.get("checkIn") ?? "";
  const checkOut = params.get("checkOut") ?? "";
  const roomsCount = Math.max(1, Number(params.get("rooms")) || 1);
  const adults = Math.max(1, Number(params.get("adults")) || 2);
  const children = Math.max(0, Number(params.get("children")) || 0);

  const [properties, setProperties] = useState<ContentProperty[]>([]);
  const [contactPhone, setContactPhone] = useState("+91 124 410 2200");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const router = useRouter();
  const [editOpen, setEditOpen] = useState(false);
  const [editProperty, setEditProperty] = useState(propertySlug);
  const [editCheckIn, setEditCheckIn] = useState(checkIn);
  const [editCheckOut, setEditCheckOut] = useState(checkOut);
  const [editRooms, setEditRooms] = useState<RoomParty[]>([{ adults: 2, children: 0 }]);
  const [editError, setEditError] = useState("");
  const [minDate, setMinDate] = useState("");

  const datesValid = /^\d{4}-\d{2}-\d{2}$/.test(checkIn) && /^\d{4}-\d{2}-\d{2}$/.test(checkOut) && checkOut > checkIn;
  const nights = datesValid ? stayNights(checkIn, checkOut) : 1;

  // Rooms come from the content layer by property slug, so each property shows only its own rooms.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      setError("");
      try {
        const response = await fetch("/api/content", { cache: "no-store" });
        const data = await response.json();
        if (cancelled) return;
        setProperties((data.properties as ContentProperty[]) ?? []);
        if (data.settings?.contactPhone) setContactPhone(data.settings.contactPhone);
      } catch {
        if (!cancelled) setError("We couldn't load room information just now. Please try again.");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    setMinDate(todayInIndia());
    setEditProperty(propertySlug);
    setEditCheckIn(checkIn);
    setEditCheckOut(checkOut);
    setEditRooms(distributeRooms(roomsCount, adults, children));
  }, [propertySlug, checkIn, checkOut, roomsCount, adults, children]);

  // Resolve the selected property by SLUG — never fall back to a different property.
  const selected = useMemo(
    () => (propertySlug === "all" ? null : properties.find((item) => item.slug === propertySlug) ?? null),
    [properties, propertySlug],
  );
  const invalidProperty = !loading && !error && propertySlug !== "all" && properties.length > 0 && !selected;
  const groups = propertySlug === "all" ? properties : selected ? [selected] : [];

  function updateSearch(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setEditError("");
    if (!editCheckIn || !editCheckOut || editCheckOut <= editCheckIn) {
      setEditError("Check out must be after check in.");
      return;
    }
    const nextAdults = totalAdultsOf(editRooms);
    const nextChildren = totalChildrenOf(editRooms);
    if (nextAdults + nextChildren > 6) {
      setEditError(`For more than 6 guests, please call ${contactPhone} for a group booking.`);
      return;
    }
    const next = new URLSearchParams({
      property: editProperty,
      checkIn: editCheckIn,
      checkOut: editCheckOut,
      rooms: String(editRooms.length),
      adults: String(nextAdults),
      children: String(nextChildren),
    });
    setEditOpen(false);
    router.replace(`/availability?${next}`);
  }

  if (!datesValid) {
    return (
      <section>
        <p className="empty-note">
          Please choose your stay dates first. <Link href="/#booking" className="view-link">Go to booking <ArrowRight size={13} /></Link>
        </p>
      </section>
    );
  }

  const headingLine = selected
    ? `${selected.name} ${selected.area}${selected.contactAddress ? ` · ${selected.contactAddress}` : ` · ${selected.location}`}`
    : "All Hari's Court locations";

  return (
    <section>
      <nav className="crumb" aria-label="Breadcrumb">
        <Link href="/">Home</Link> <ChevronRight size={12} /> <span>Search Results</span>
      </nav>

      <div className="page-head">
        <div>
          <h1>Available Rooms</h1>
          <p className="prop-line">
            <MapPin size={16} />
            {invalidProperty ? "Select a location to see rooms" : headingLine}
          </p>
        </div>
        <button type="button" className="modify-btn" onClick={() => setEditOpen((open) => !open)} aria-expanded={editOpen}>
          Modify Search
        </button>
      </div>

      {editOpen ? (
        <form className="summary-strip search-edit" onSubmit={updateSearch}>
          <div className="booking-field">
            <label htmlFor="edit-property">Location</label>
            <div className="booking-picker">
              <MapPin size={18} />
              <select id="edit-property" value={editProperty} onChange={(event) => setEditProperty(event.target.value)}>
                <option value="all">All Locations</option>
                {properties.map((item) => (
                  <option key={item.slug} value={item.slug}>
                    {item.location}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="booking-field">
            <label htmlFor="edit-check-in">Check In</label>
            <div className="booking-picker">
              <CalendarDays size={18} />
              <input id="edit-check-in" type="date" required min={minDate || undefined} value={editCheckIn} onChange={(event) => setEditCheckIn(event.target.value)} />
            </div>
          </div>
          <div className="booking-field">
            <label htmlFor="edit-check-out">Check Out</label>
            <div className="booking-picker">
              <CalendarDays size={18} />
              <input id="edit-check-out" type="date" required min={editCheckIn || minDate || undefined} value={editCheckOut} onChange={(event) => setEditCheckOut(event.target.value)} />
            </div>
          </div>
          <div className="booking-field">
            <label id="edit-guests-label">Guests</label>
            <GuestsPicker value={editRooms} onChange={setEditRooms} labelledBy="edit-guests-label" />
          </div>
          <button type="submit" className="luxe-check-button search-update-btn">Update Search</button>
          {editError && <p className="demo-note search-edit-error" role="alert">{editError}</p>}
        </form>
      ) : (
        <div className="summary-strip">
          <div className="summary-item">
            <CalendarDays size={20} />
            <div><small>Check-in</small><strong>{formatStayDate(checkIn)}</strong></div>
          </div>
          <div className="summary-item">
            <CalendarDays size={20} />
            <div><small>Check-out</small><strong>{formatStayDate(checkOut)}</strong></div>
          </div>
          <div className="summary-item">
            <Clock size={20} />
            <div><small>Nights</small><strong>{nights} Night{nights > 1 ? "s" : ""}</strong></div>
          </div>
          <div className="summary-item">
            <Users size={20} />
            <div><small>Guests</small><strong>{adults} Adult{adults > 1 ? "s" : ""}, {children} Child{children === 1 ? "" : "ren"}</strong></div>
          </div>
        </div>
      )}

      <p className="demo-note">Showing room types and starting rates for your dates. Final availability and the exact rate are confirmed during booking.</p>
      {error && <p className="demo-note" role="alert">{error}</p>}
      {loading && <p className="empty-note">Loading rooms…</p>}

      {invalidProperty && (
        <p className="empty-note" role="alert">
          We couldn&apos;t find the selected property. Please <Link href="/#booking" className="view-link">choose a location</Link> and search again.
        </p>
      )}

      {!loading && !error && !invalidProperty && groups.length === 0 && (
        <p className="empty-note">No rooms are available for these dates. Please try different dates via <Link href="/#booking" className="view-link">Modify Search</Link>.</p>
      )}

      {!loading && groups.map((property) => (
        <div key={property.slug}>
          {propertySlug === "all" && <h2 className="group-title">{property.name} {property.area}</h2>}
          {property.rooms.length === 0 ? (
            <p className="empty-note">No rooms have been configured for this property yet.</p>
          ) : (
            property.rooms.map((room) => {
              const onRequest = room.priceStatus === "on-request" || room.rate <= 0;
              const roomTotal = room.rate * nights;
              const taxes = Math.round(roomTotal * TAX_RATE);
              const photo = room.images[0];
              const href = `/rooms/${room.id}?${new URLSearchParams({
                property: property.backendKey,
                propertySlug: property.slug,
                checkIn,
                checkOut,
                adults: String(adults),
                children: String(children),
                rooms: String(roomsCount),
                rate: String(room.rate),
                name: room.name,
              })}`;
              return (
                <article className="result-card" key={room.id}>
                  <div
                    className="result-photo"
                    style={photo ? { backgroundImage: `url(${photo})` } : { background: "repeating-linear-gradient(135deg, #eef1f5, #eef1f5 12px, #e7ebf1 12px, #e7ebf1 24px)" }}
                    role="img"
                    aria-label={photo ? room.name : `${room.name} — photo coming soon`}
                  />
                  <div className="result-info">
                    <h2>{room.name}</h2>
                    <div className="spec-row">
                      <span><Users size={15} /> {room.guests} Guest{room.guests === 1 ? "" : "s"}</span>
                      {room.bed && <span><BedDouble size={15} /> {room.bed}</span>}
                      {room.sqft > 0 && <span><Maximize size={15} /> {room.sqft} sq. ft.</span>}
                    </div>
                    <p>{room.description || "Room details will be shared at booking."}</p>
                    {room.amenities.length > 0 && (
                      <div className="amen-row">
                        {room.amenities.slice(0, 4).map((amenity) => (
                          <span key={amenity}>{amenity}</span>
                        ))}
                        {room.amenities.length > 4 && <span>+{room.amenities.length - 4} More</span>}
                      </div>
                    )}
                    <Link href={href} className="view-link">View Room Details <ArrowRight size={13} /></Link>
                  </div>
                  <div className="result-price">
                    {onRequest ? (
                      <>
                        <span className="rate">Rate on request</span>
                        <Link href={href} className="select-room-btn">Enquire</Link>
                      </>
                    ) : (
                      <>
                        <span className="rate">{inr(room.rate)}</span>
                        <span className="per">per night</span>
                        <span className="total">
                          Total for {nights} night{nights > 1 ? "s" : ""}
                          <strong>{inr(roomTotal)}</strong>
                        </span>
                        <span className="per">+ taxes &amp; fees {inr(taxes)}</span>
                        <Link href={href} className="select-room-btn">Select Room</Link>
                      </>
                    )}
                  </div>
                </article>
              );
            })
          )}
        </div>
      ))}
    </section>
  );
}

function distributeRooms(count: number, adults: number, children: number): RoomParty[] {
  const rooms: RoomParty[] = [];
  let adultsLeft = adults;
  let childrenLeft = children;
  for (let i = 0; i < count; i++) {
    const remainingSlots = count - 1 - i;
    const roomAdults = Math.min(4, Math.max(1, adultsLeft - remainingSlots));
    const roomChildren = Math.min(4, Math.max(0, childrenLeft - remainingSlots * 4));
    rooms.push({ adults: roomAdults, children: roomChildren });
    adultsLeft -= roomAdults;
    childrenLeft -= roomChildren;
  }
  return rooms;
}
