import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Phone, Quote } from "lucide-react";
import AmenityIcon from "@/components/AmenityIcon";
import EnquiryForm from "@/components/EnquiryForm";
import HomeHero from "@/components/HomeHero";
import HomeLocation from "@/components/HomeLocation";
import HomeRooms from "@/components/HomeRooms";
import Reveal from "@/components/Reveal";
import { SelectedPropertyProvider } from "@/components/SelectedProperty";
import SiteFooter from "@/components/SiteFooter";
import SiteHeader from "@/components/SiteHeader";
import { getSite, seoFor, wantsPreview } from "@/lib/content/service";

export const dynamic = "force-dynamic";

type SearchParams = Promise<{ preview?: string }>;

export async function generateMetadata({ searchParams }: { searchParams: SearchParams }): Promise<Metadata> {
  const site = await getSite({ preview: await wantsPreview((await searchParams).preview) });
  const seo = seoFor(site, "home", { title: site.settings.siteName, description: site.home.heroSubtitle });
  return { title: seo.title, description: seo.description, openGraph: { title: seo.title, description: seo.description, images: seo.ogImage ? [seo.ogImage] : undefined } };
}

export default async function Home({ searchParams }: { searchParams: SearchParams }) {
  const site = await getSite({ preview: await wantsPreview((await searchParams).preview) });
  const { home, settings, properties } = site;
  const offers = home.offers.filter((offer) => offer.enabled);
  const phoneHref = `tel:${settings.contactPhone.replace(/[^\d+]/g, "")}`;

  return (
    <main className="hc-page hc-page--hero">
      <SiteHeader bookLabel={site.settings.bookCtaLabel} />
      {site.isPreview && <p className="hc-preview-banner">Previewing the unpublished draft</p>}
      <SelectedPropertyProvider properties={properties} initialSlug="mg-road">
        <HomeHero home={home} maxGuests={settings.maxOnlineGuests} phone={settings.contactPhone} availabilityLabel={settings.availabilityCtaLabel} exploreLabel={settings.exploreCtaLabel} />

        <section className="hc-amenities" aria-label="Hotel highlights">
          <div className="hc-amenities-inner">
            {site.amenities.map((amenity) => (
              <Reveal key={amenity.id} className="hc-amenity">
                <span className="hc-amenity-icon"><AmenityIcon name={amenity.icon} /></span>
                <div>
                  <h3>{amenity.title}</h3>
                  <p>{amenity.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        <section className="hc-section hc-about" id="about" aria-labelledby="about-title">
          <Reveal className="hc-about-media">
            {home.aboutImage && (
              <div className="hc-about-photo hc-about-photo-main">
                <Image src={home.aboutImage} alt="Hari's Court" fill sizes="(max-width: 900px) 90vw, 520px" />
              </div>
            )}
            {home.aboutImageSecondary && (
              <div className="hc-about-photo hc-about-photo-side">
                <Image src={home.aboutImageSecondary} alt="" fill sizes="(max-width: 900px) 50vw, 280px" />
              </div>
            )}
          </Reveal>
          <Reveal className="hc-about-copy" delay={120}>
            <p className="hc-eyebrow">{home.aboutEyebrow}</p>
            <h2 id="about-title">{home.aboutHeading}</h2>
            {home.aboutParagraphs.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
            <Link href="#locations" className="hc-btn hc-btn-outline">
              Discover our locations <ArrowRight size={16} />
            </Link>
          </Reveal>
        </section>

        <section className="hc-section hc-section-tint" id="rooms" aria-labelledby="rooms-title">
          <Reveal className="hc-section-head">
            <p className="hc-eyebrow">Rooms &amp; Suites</p>
            <h2 id="rooms-title">{home.roomsHeading}</h2>
            <p>{home.roomsIntro}</p>
          </Reveal>
          <HomeRooms availabilityLabel={settings.availabilityCtaLabel} />
        </section>

        <section className="hc-section hc-banquets" id="banquets" aria-labelledby="banquets-title">
          {home.banquetImage && (
            <Reveal className="hc-banquet-media">
              <Image src={home.banquetImage} alt="Banquet and event space at Hari's Court" fill sizes="(max-width: 900px) 100vw, 640px" />
            </Reveal>
          )}
          <Reveal className="hc-banquet-copy" delay={120}>
            <p className="hc-eyebrow">{home.banquetEyebrow}</p>
            <h2 id="banquets-title">{home.banquetHeading}</h2>
            <p>{home.banquetText}</p>
            <ul className="hc-event-list">
              {home.eventTypes.map((event) => (
                <li key={event.title}>
                  <strong>{event.title}</strong>
                  <span>{event.text}</span>
                </li>
              ))}
            </ul>
            <a href={phoneHref} className="hc-btn hc-btn-outline">
              <Phone size={16} /> Call {settings.contactPhone}
            </a>
          </Reveal>
          <Reveal className="hc-banquet-form" delay={80}>
            <h3>Event enquiry</h3>
            <EnquiryForm defaultKind="event" />
          </Reveal>
        </section>

        {offers.length > 0 && (
          <section className="hc-section" id="offers" aria-labelledby="offers-title">
            <Reveal className="hc-section-head">
              <p className="hc-eyebrow">Offers</p>
              <h2 id="offers-title">{home.offersHeading}</h2>
              {home.offersIntro && <p>{home.offersIntro}</p>}
            </Reveal>
            <div className="hc-offers">
              {offers.map((offer, index) => (
                <Reveal key={offer.id} delay={index * 90} className="hc-offer">
                  <h3>{offer.title}</h3>
                  <p>{offer.text}</p>
                  {offer.cta && (
                    <Link href={offer.href || "#banquets"} className="hc-link-arrow">
                      {offer.cta} <ArrowRight size={16} />
                    </Link>
                  )}
                </Reveal>
              ))}
            </div>
          </section>
        )}

        <section className="hc-section hc-section-tint" aria-labelledby="testimonials-title">
          <Reveal className="hc-section-head">
            <p className="hc-eyebrow">Guest Stories</p>
            <h2 id="testimonials-title">{home.testimonialsHeading}</h2>
          </Reveal>
          <div className="hc-testimonials">
            {home.testimonials.map((item, index) => (
              <Reveal key={item.name} delay={index * 90} className="hc-testimonial">
                <Quote size={28} aria-hidden="true" />
                <p>{item.quote}</p>
                <footer>
                  <strong>{item.name}</strong>
                  <span>{item.location}</span>
                </footer>
              </Reveal>
            ))}
          </div>
        </section>

        <section className="hc-section" id="locations" aria-labelledby="locations-title">
          <Reveal className="hc-section-head">
            <p className="hc-eyebrow">Our Locations</p>
            <h2 id="locations-title">{home.locationHeading}</h2>
            <p>{home.locationIntro}</p>
          </Reveal>
          <HomeLocation />
        </section>
      </SelectedPropertyProvider>

      <section className="hc-section hc-faq hc-section-tint" id="faq" aria-labelledby="faq-title">
        <Reveal className="hc-section-head">
          <p className="hc-eyebrow">FAQ</p>
          <h2 id="faq-title">Good to know</h2>
        </Reveal>
        <Reveal className="hc-faq-list">
          {home.faqs.map((item) => (
            <details key={item.question} className="hc-faq-item">
              <summary>{item.question}</summary>
              <p>{item.answer}</p>
            </details>
          ))}
        </Reveal>
      </section>

      <SiteFooter />
    </main>
  );
}
