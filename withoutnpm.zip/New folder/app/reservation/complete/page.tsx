import Link from "next/link";
import { ArrowRight, CircleCheck } from "lucide-react";

export default function ReservationComplete() {
  return <main style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: 24 }}><section style={{ maxWidth: 520, textAlign: "center" }}><CircleCheck size={38} color="var(--gold-dark)" /><p className="eyebrow" style={{ marginTop: 22 }}>Hari&apos;s Court reservations</p><h1 className="serif" style={{ fontSize: 54, lineHeight: 1, margin: "12px 0" }}>Verifying your payment</h1><p style={{ color: "var(--muted)", fontSize: 13, lineHeight: 1.8 }}>Your payment is being verified with our payment provider. Your stay is confirmed only after that verification is complete; we&apos;ll send an email with the final details.</p><Link className="text-link" href="/">Return to Hari&apos;s Court <ArrowRight size={14} /></Link></section></main>;
}