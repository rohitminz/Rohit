import type { Metadata } from "next";
import "./globals.css";
import "./design-system.css";
import "./design-system-cards.css";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "https://hariscourt.in"),
  title: "Hari's Court Hotels & Inns",
  description: "Discover thoughtfully designed stays, exceptional comfort and warm hospitality at Hari's Court.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}